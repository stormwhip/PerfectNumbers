"""Prove each of the nine coprime cofactors mandatory has at least TWO distinct primes, no factorization.
A failed Fermat proves composite, and exclusion of every prime-power exponent k up to bit length proves not prime power.
"""
from pathlib import Path
import sys,math,json
here=Path(__file__).resolve().parent;sys.path.insert(0,str(here));from CohortCRT import block;from All568 import cases

def kth(n,k):
    lo=1;hi=1<<((n.bit_length()+k-1)//k)
    while lo+1<hi:
        m=(lo+hi)//2
        if m**k<=n:lo=m
        else:hi=m
    return lo

def nonpower(C):
    assert pow(2,C-1,C)!=1
    for k in range(2,C.bit_length()):
        if any(k%d==0 for d in range(2,math.isqrt(k)+1)):continue
        q=kth(C,k);assert q**k<C,(k,q)
    return True
if __name__=='__main__':
    for r,f in sorted({(13,568)}|{(r,f) for fx in cases for r,f in fx}):
        assert nonpower(block(r,f));print('at least 2 primes',r,f,flush=True)
