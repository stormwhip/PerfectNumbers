"""Uniform r^f/13^(2b) premium for every possible unknown ordinary factor of four 13^568 fixed-seed blocks.
No probabilistic primality, no factorization assumptions. CRT mod 2n & 13^t, plus composite superset of primality.
"""
import sys,math
from pathlib import Path
from itertools import combinations
FX=((13,568),(468784307,28),(11668673,12),(2599193,22));p=13

def blocks():
    fixed=math.prod(r for r,_ in FX);out=[]
    for u,f in FX:
        n=f+1;assert all(n%j for j in range(2,math.isqrt(n)+1));C=(u**n-1)//(u-1)
        while (d:=math.gcd(C,fixed))>1:C//=d
        assert C>1 and C%n and math.gcd(C,13*2*n)==1
        out.append((C,n))
    assert all(math.gcd(a,b)==1 for (a,n),(b,m) in combinations(out,2));return out

def verify(C,n,K):
    D=2*n
    # Every prime divisor has order n of the seed, so is 1 mod 2n.
    assert all(C%v for v in range(D+1,K+1,D))
    m=1;roots=(3,9);small=[z for z in range(3,701,2) if all(z%i for i in range(2,math.isqrt(z)+1))];assert all(C%z for z in small)
    for t in range(1,569):
        m*=13
        if m>13*C:break
        for x in roots:
            if math.gcd(m,D)==1:z=x+m*((1-x)*pow(m,-1,D)%D);step=m*D
            else:
                # n=13: r|Phi_13(u) automatically 1 mod 13, cannot have order 3 mod 13.
                assert n==13 and x%13 in (3,9);continue
            cap=min(m*K,C);N=(cap-z)//step+1
            if N<=0:continue
            assert z>=1;v=bytearray(b'\1')*N
            for q in small:
                if step%q==0:continue
                k=-z*pow(step,-1,q)%q
                if k<N:v[k::q]=bytes((N-1-k)//q+1)
            vals=[z+step*k for k in range(N) if v[k]]
            for j in range(0,len(vals),64):assert math.gcd(C,math.prod(vals[j:j+64]))==1,(n,t,z,j)
        roots=tuple(pow(x,13,m*13) for x in roots)
    print(dict(index=n,K=K,premium=K*K,certified=True),flush=True)
if __name__=='__main__':
    ks=list(map(int,sys.argv[1:])) or [5000000,5000000,5000000,5000000]
    for (C,n),K in zip(blocks(),ks):verify(C,n,K)
