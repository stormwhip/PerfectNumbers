"""Use two representatives per composite nonpower block. Explicit double-entry accounting; four branches, conditional q outside fixed sigma values.
"""
from pathlib import Path
import sys,math
here=Path(__file__).resolve().parent;sys.path.insert(0,str(here));from Combo568 import *

def run(fx):
    cs,fs,V,D,M,ex=data(fx);V*=math.prod(u*u for u in ex);M*=math.prod(ex)
    vals=[max(G,R*R//(1 if pow(c,3,13)!=1 else 169)) for c in cs];V*=math.prod(vals)*G**4
    s=0
    while V*(2*13**s-1)>B*D*13**(2*s):s+=1
    y=13**s;Q=2*y-1;slimit=0
    while M*R**4*(2*13**(slimit+1)-1)<=B:slimit+=1
    if s>slimit:print('empty',fx,s,slimit);return
    def bmin(loss):
        b=0
        while 2*V*Q*Q>3*B*D*y*y*loss*13**b:b+=1
        return b
    b=bmin(max(vals+[u*u for u in ex]));assert b>5
    b=bmin(G) # source deep, cannot be shallow. If r uses a generic required factor its full premium replaces only the 18-digit price.
    h=b-3;roots=[pow(a,13**(h-1),13**h) for a in (3,9)];rmin=min(roots);print('source bmin',b,'depth',h,'rlog',len(str(rmin))-1,'s',s,slimit)
    assert M*Q*R**3*rmin>B,(fx,'room for one extra r') # every other block's nonsquare extra unaffected
    # r already in block, f=c. For f!=2 and 3|f+1 => f>=8; cost r^6*(r²/13^(2b)) >= r^6*K²/13^6.
    cap=B*D*G*13**(2*slimit)//(V*(2*13**slimit-1));assert rmin**6*K*K>cap*13**6
    # Hence f=2 and j=0. For each box adjust depth.
    out=[]
    for C,(_,g) in zip(cs,fs):
        if g+1==13:continue
        if C%13 in (1,3,9) and pow(C,3,169)==1:raise ValueError('unpaid shallow')
        lo=K*13**b+1;hi=math.isqrt(C);parts=[]
        while lo<=hi:
            end=min(hi,lo*10**5);j=b
            while lo*lo>cap*13**(2*j):j+=1
            parts.append((lo,end,j));lo=end+1
        out.append((C,g+1,parts))
    return out
if __name__=='__main__':
    for f in cases:
        a=run(f);print([(n,len(ps),ps[0][2] if ps else None) for C,n,ps in a] if a is not None else None)
