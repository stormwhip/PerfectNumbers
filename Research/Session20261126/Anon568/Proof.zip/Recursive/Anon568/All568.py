"""Four previously missed high-Euler subdomains on (13,568). No ledger credit for full exponent.
Check masses & nontriv subgroup CRT prices by exact integers, not root labels. Hash-free re-evaluation.
"""
from pathlib import Path
import sys,math,json
from functools import cache
here=Path(__file__).resolve().parent;sys.path.insert(0,str(here));from Quad568 import verify
K=2000000;P=13;E=568;U=2771;D=1;B=10**2400
cases=[[(468784307,16),(5244488101,18),(2599193,22)],[(468784307,16),(5244488101,22),(2599193,22)],[(468784307,28),(11668673,12),(2599193,22)],[(468784307,30),(7921493,12),(2599193,22)]]
@cache
def check(C,n):verify(C,n,K);return True

def high(fx):
    fx=[(13,E)]+fx;X=math.prod(r for r,f in fx);vnum=13**(3*E);vden=U*D;C=[];extra=[]
    for r,f in fx:
        n=f+1;assert all(n%d for d in range(2,math.isqrt(n)+1))
        S=(r**n-1)//(r-1);b=0
        while S%13==0:S//=13;b+=1
        if r!=13:vnum*=r**f;vden*=13**(2*b)
        while (g:=math.gcd(S,X))>1:S//=g
        if r==5244488101 and f==18:
            z=258926453;assert all(z%i for i in range(2,math.isqrt(z)+1)) and S%z==0 and S%(z*z)!=0
            assert pow(z,12,13)==1 and all(pow(z,o,13)!=1 for o in (1,2,3,4,6));S//=z;extra.append(z)
        assert S>1 and S%n and math.gcd(S,13*2*n)==1;C.append((S,n))
    pool=[S for S,n in C]+extra;assert all(math.gcd(v,w)==1 for i,v in enumerate(pool) for w in pool[:i]) and all(math.gcd(v,X)==1 for v in pool)
    for S,n in C:assert check(S,n)
    # Distinct ordinary representatives; discard all price of at most one anonymous block (or extra prime) as Euler. Known high Euler q=extra actually gives positive ratio q^5 because its order mod13 is 12 (v13=0).
    G=K*K;prem=G**(len(C)-1)*math.prod(z*z for z in extra)
    if extra:prem=min(prem,G**len(C)*min(z**5 for z in extra))
    assert vnum*prem>B*vden,(fx,len(str(vnum*prem//vden))-1)
    return dict(fixed=fx,blocks=[[n,len(str(c)),G] for c,n in C],extra=extra,threshold_floor=len(str(vnum*prem//vden))-1,uncredited_Euler_blocks=1)
if __name__=='__main__':
    for fx in cases:print(json.dumps(high(fx)),flush=True)
