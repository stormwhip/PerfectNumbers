"""Common Euler-one q-in-main-block staircase with dual suppression of large q. Integer all-s guard, no solver.
 For each q decade bin [lo,hi], exclude low s by bound V*q/p^(2s)>B, then arith progression q=2p^s-1 (mod4p^s) extends
 to q=2p^h-1 mod4p^h for every s>=h (actual coefficient odd); CRT with q=1 mod1138.
"""
import sys,math
from pathlib import Path
here=Path(__file__).resolve().parent;sys.path.insert(0,str(here));from Combo568 import *

def work():
    vals=[];A=None;smin=569
    for fx in cases:
        cs,fs,V,D,M,extra=data(fx);C=cs[0]
        assert A is None or A==C;A=C
        for j,u in enumerate(cs):
            # If q in C0, its exact exponent one gives C0/q integer and its odd-prime support nonempty.
            # For s>=2 use C0/q ==-C0 mod169. At s=0,1 omit shallow for C0 and retain exactly 1 generic premium.
            if j:
                V*=G*(R*R//(1 if pow(u,3,13)!=1 else 169))
        V*=math.prod(r*r for r in extra)
        assert all(V*G*(2*13**s-1)>B*D*13**(2*s) for s in (0,1))
        assert pow(-C,3,169)!=1
        V*=max(G,R*R//(1 if pow(-C,3,13)!=1 else 169))
        s=0
        while V*(2*13**s-1)>B*D*13**(2*s):s+=1
        smin=min(smin,s);vals.append((V,D));print('profile lower s',s,flush=True)
    assert smin>=89
    # Use weakest V/D for common superset (test product):
    from fractions import Fraction
    v=min(Fraction(V,D) for V,D in vals);V=v.numerator;D=v.denominator
    n=569;Y=13**smin;T=4*n*Y;u=2*Y-1;z=u+4*Y*((1-u)*pow(4*Y,-1,n)%n);lo=z
    # Also bound q from C/q ≡C/z mod T. Retain it even after adjusting h per interval.
    maxq=A//(A*pow(z,-1,T)%T);out=[]
    while lo<=maxq:
        hi=min(maxq,lo*10**4);s=smin
        while V*lo>B*D*13**(2*s):s+=1
        Y=13**s;T=4*n*Y;u=2*Y-1;z=u+4*Y*((1-u)*pow(4*Y,-1,n)%n)
        boxhi=min(hi,A//(A*pow(z,-1,T)%T))
        if lo+(z-lo)%T<=boxhi:out.append((lo,boxhi,s,z,T))
        lo=hi+1
    return A,out
if __name__=='__main__':
    C,rows=work();print('boxes',len(rows),[(len(str(l))-1,len(str(h))-1,s) for l,h,s,z,T in rows],flush=True)
