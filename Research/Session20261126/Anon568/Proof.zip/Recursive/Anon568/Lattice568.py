"""Pure-integer verifier for three compact f=568 lattice families. The analytic engine must return genuinely necessary bounds for every legal location."""
from pathlib import Path
import gzip,json,math,sys

def _load(p):
 old=sys.get_int_max_str_digits();sys.set_int_max_str_digits(30000)
 try:return json.loads(gzip.decompress(Path(p).read_bytes()))
 finally:sys.set_int_max_str_digits(old)

def check_root(C,windows,folder,R):
 sys.path.insert(0,str(R/'NightMerge'));import LatticeLeaf as L
 lists=_load(folder/'EulerStairCommon568.json.gz');assert len(lists)==len(windows);o=0
 for (lo,hi,s,z,T),ws in zip(windows,lists):
  assert 0<z<T and math.gcd(C,T)==1 and z%569==1 and z%(4*13**s)==2*13**s-1;cur=lo
  for l,u,w in ws:
   assert l==cur and l<=u<=hi and L.verify(C,1,z,T,l,u,w);cur=u+1;o+=1
  assert cur==hi+1
 return o

def check_small(ix,blocks,folder,R):
 sys.path.insert(0,str(R/'NightMerge'));import LatticeLeaf as L
 o=0
 for i,C,n,raw in blocks:
  if i==0:continue
  assert 1<=i<=3;band={s:(lo,hi,z,t) for s,lo,hi,z,t in raw};ds=_load(folder/f'Intern13x568-{ix}-{i}.json.gz');seen=[]
  for ss,ws in ds:
   assert ss==sorted(ss) and ss and all(s in band for s in ss);z,T=band[ss[0]][2:];assert math.gcd(C,T)==1
   for s in ss:
    zz,M=band[s][2:];assert zz%T==z and M%T==0
   cur=max(z,min(band[s][0] for s in ss));hi=min(C//(C*pow(z,-1,T)%T),max(band[s][1] for s in ss));
   for l,h,w in ws:
    assert cur==l and l<=h<=hi and L.verify(C,1,z,T,l,h,w);cur=h+1;o+=1
   assert cur>hi;seen+=ss
  assert seen==list(band)
 return o

def check_squares(ix,blocks,folder,R):
 sys.path.insert(0,str(R/'NightMerge'));import LatticeLeaf as L
 d=_load(folder/f'DoubleSquare568-{ix}.json.gz');blocks=blocks or [];assert len(d)==len(blocks);c=0
 for (C,n,bands),(nn,rows) in zip(blocks,d):
  assert n==nn and all(n%i for i in range(2,math.isqrt(n)+1)) and C%n and len(rows)==len(bands)
  for (lo,hi,h),rr in zip(bands,rows):
   assert rr[:3]==[lo,hi,h] and len(rr[3])==2;Y=13**h;T=2*n*Y;assert math.gcd(C,T)==1
   for a,ws in zip((3,9),rr[3]):
    x=pow(a,13**(h-1),Y);z=1+2*n*((x-1)*pow(2*n,-1,Y)%Y);assert pow(z,3,Y)==1;cur=lo
    for l,u,w in ws:
     assert cur==l and l<=u<=hi and L.verify(C,2,z,T,l,u,w);cur=u+1;c+=1
    assert cur==hi+1
 return c
