"""Fast exact p-adic ratio CRT over k=0..N_t via one polynomial shared across all t and residues, varying modulus block.
Also certifies pure roughness r>K via t=0 progression. Emits explicit factor if any test non-coprime.
"""
import sys,math,json
from pathlib import Path
here=Path(__file__).resolve().parent;sys.path.insert(0,str(here/'vendor'));from flint import fmpz_mod_poly_ctx,ctx
ctx.threads=1
# No discovery-time imports from neighboring scripts.

def test(C,n,K):
    p=13;D=2*n;assert math.gcd(C,p*D)==1
    starts=[(pow(D,-1,C),K//D)];m=1;roots=(3,9)
    for t in range(1,569):
        m*=13
        for x in roots:
            if n==13:continue
            z=x+m*((1-x)*pow(m,-1,D)%D);step=D*m;cap=min(C,K*m);N=(cap-z)//step+1
            if N>0:starts.append((z*pow(step,-1,C)%C,N))
        roots=tuple(pow(x,13,13*m) for x in roots)
    # pure roughness indices 1+D*j for j=1..K//D; using j=0..K//D inclusive unifies count
    starts[0]=(pow(D,-1,C),K//D+1)
    total=sum(N for _,N in starts);b=min(131072,1<<(math.isqrt(total).bit_length()-1));alg=fmpz_mod_poly_ctx(C)
    def prod(a,h):
        if h==1:return alg([a,1])
        v=h//2;return prod(a,v)*prod(a+v,h-v)
    pp=prod(0,b);rows=[];v=1
    def flush(rows):
        w=1
        for t in pp.multipoint_evaluate(rows):w=w*int(t)%C
        return w
    for x,N in starts:
        for k in range(0,N,b):
            rows.append((x+k)%C)
            if len(rows)>=8192:v=v*flush(rows)%C;rows=[]
    if rows:v=v*flush(rows)%C
    ret=math.gcd(C,v);print(n,len(str(C)),K,total,b,ret,flush=True);return ret

def block(r,f):
    X=math.prod([13,468784307,5244488101,2599193,11668673,7921493,17,3]);C=(r**(f+1)-1)//(r-1)
    while (g:=math.gcd(C,X))>1:C//=g
    if (r,f)==(5244488101,18):assert C%258926453==0;C//=258926453
    if (r,f)==(11668673,18):assert C%280483283==0 and C%(280483283**2);C//=280483283
    return C
if __name__=='__main__':
    K=int(sys.argv[1]);targets=[tuple(map(int,z.split(':'))) for z in sys.argv[2:]]
    for r,f in targets:assert test(block(r,f),f+1,K)==1
