"""Exact s ranges when external Euler q divides an anonymous C residual. Preserve shallow/negative-character factor in C/q.
6 fixed tuples require varying which M block is paid. Returns q divisor search ranges for first-order lattice checker.
"""
import sys,math
from pathlib import Path
here=Path(__file__).resolve().parent;sys.path.insert(0,str(here));from All568 import cases
B=10**2400;R=10**11

def run(fx):
    fs=[(13,568)]+fx;X=math.prod(r for r,h in fs);V=13**(3*568);den=2771;cs=[];extra=False;oddExp=[]
    for r,h in fs:
        C=(r**(h+1)-1)//(r-1);b=0
        while C%13==0:C//=13;b+=1
        while (g:=math.gcd(C,X))>1:C//=g
        if r!=13:V*=r**h;den*=13**(2*b)
        if (r,h)==(5244488101,18):
            z=258926453;assert C%z==0 and C%(z*z)!=0;C//=z;extra=True
        cs.append(C);oddExp.append(h+1)
    out=[]
    for i,C in enumerate(cs):
        # Euler prime q|C, so q divides exactly one block and q^1||C. If q=known extra prime only s=0, plainly excluded by existing high bound.
        V0=V*(258926453**2 if extra else 1);ranges=[]
        for s in range(569):
            y=13**s;Q=2*y-1;vv=V0
            for j,u in enumerate(cs):
                if i==j and s<2:continue
                if i==j:u=-u # (C/q)^3 equivalent modulo 169 since q≡−1 mod 13²
                if u%13 not in (1,3,9):vv*=R**2
                elif pow(u,3,169)!=1:vv*=R**2//169
                elif i!=j:vv*=10**18
            if vv*Q>B*den*y*y:continue
            n=oddExp[i]
            if n==13 and s>0:continue
            else:
                T=4*y;a=2*y-1;z=a+T*((1-a)*pow(T,-1,n)%n);T*=n
                cf=C*pow(z,-1,T)%T;lo=z;hi=min(C//cf,B*den*y*y//vv)
                if lo<=hi:ranges.append((s,lo,hi,z,T))
        out.append((i,C,n if ranges else oddExp[i],ranges))
    return out
if __name__=='__main__':
    for ix,fx in enumerate(cases):
        zz=run(fx);print(ix,[(i,(rows[0][0],rows[-1][0],len(rows)) if rows else None) for i,C,n,rows in zz],flush=True)
