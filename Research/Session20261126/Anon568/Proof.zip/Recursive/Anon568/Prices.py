"""Production exact input/price verifier for cut's five residual 13^568 leaves and fixed Euler-17. No repo writes.
CLI: python -I -S -B Prices.py all|quick with pinned python-flint under vendor/. Without -S also normal installed flint works.
all = all 11 unique C, R/K full size. quick = the same inputs, per-progressions arithmetic independently checked at K=10000,R=200000 (NOT a full proof).
API verify_prices(fixed): exact fixed prime-power pairs including (13,568), returns tuple of (prime_index,C), asserts all number theory claims. Cache avoids duplicates within process.
"""
import sys,math,time
from pathlib import Path
from functools import cache
H=Path(__file__).resolve().parent;sys.path.insert(0,str(H/'vendor'))
from flint import fmpz_mod_poly_ctx,ctx
ctx.threads=1
P=13;E=568;R=10**11;K=10**9;B=10**2400
profiles=(((468784307,16),(5244488101,18),(2599193,22)),((468784307,16),(5244488101,22),(2599193,22)),((468784307,28),(11668673,12),(2599193,22)),((468784307,30),(7921493,12),(2599193,22)),((468784307,28),(11668673,18),(2599193,22)))
fixed17=((468784307,16),(5244488101,16),(2599193,22),(17,1),(3,2));extra={(5244488101,18):258926453,(11668673,18):280483283}

def prime(x):return x>=2 and all(x%j for j in range(2,math.isqrt(x)+1))
def sigma(r,f):return (r**(f+1)-1)//(r-1)
@cache
def info(fx):
    X=math.prod(r for r,f in fx);cs=[];ex=[]
    for r,f in fx:
        A=sigma(r,f);A//=A&-A
        while (g:=math.gcd(A,X))>1:A//=g
        if (r,f) in extra:
            u=extra[r,f];assert prime(u) and A%u==0 and A%(u*u) and pow(u,3,13)!=1;A//=u;ex.append(u)
        if A==1:continue
        n=f+1;assert prime(n) and A%n and math.gcd(A,2*13*n)==1;cs.append((n,A))
    ds=[A for n,A in cs]+ex;assert len(cs)==4 and all(math.gcd(z,X)==1 for z in ds) and all(math.gcd(v,w)==1 for i,v in enumerate(ds) for w in ds[:i]);return cs,ex

@cache
def nonpower(C):
    assert pow(2,C-1,C)!=1
    for a in range(2,C.bit_length()+1):
        if not prime(a):continue
        x=1;y=1<<((C.bit_length()+a-1)//a)
        while x+1<y:
            m=(x+y)//2
            if m**a<=C:x=m
            else:y=m
        assert x**a!=C and y**a!=C
    return True

def runs(C,n,R,K):
    # An AP is represented by (first,step,length), with first an actual candidate, not the preceding residue.
    d=2*n;out=[(1,d,1+(R-1)//d)]
    x=(3,9);Y=1
    for t in range(1,569):
        Y*=13
        for u in x:
            assert u%13 in (3,9) and pow(u,3,Y)==1
            if n==13:continue
            w=u+Y*((1-u)*pow(Y,-1,d)%d);h=Y*d;cap=min(C,K*Y);N=(cap-w)//h+1
            if N>0:out.append((w,h,N))
        x=tuple(pow(u,13,13*Y) for u in x)
    return out

def product_gcd(C,seq,small=False,report=False):
    Ns=sum(N for _,_,N in seq);b=min(131072,1<<(math.isqrt(Ns).bit_length()-1));F=fmpz_mod_poly_ctx(C)
    def build(a,n):
        if n==1:return F([a,1])
        l=n//2;return build(a,l)*build(a+l,n-l)
    poly=build(0,b);points=[];count=0;v=1;vp=1
    def flush(rows):
        v=1
        for z in poly.multipoint_evaluate(rows):v=v*int(z)%C
        return v
    for first,d,N in seq:
        assert math.gcd(d,C)==1;x=first*pow(d,-1,C)%C
        for k in range(0,N,b):
            points.append((x+k)%C);count+=1
            if len(points)==8192:v=v*flush(points)%C;points=[]
        if small:
            # Repeat exactly the SAME padded product by literal integer multiplication, without polynomial arithmetic.
            for k in range(((N+b-1)//b)*b):vp=vp*(x+k)%C
    if points:v=v*flush(points)%C
    if small:assert vp==v
    if report:print('progressions',len(seq),'candidates',Ns,'block',b,'evaluations',count,flush=True)
    return math.gcd(C,v)

@cache
def certify(C,n,quick=False):
    assert nonpower(C) and math.isqrt(C)**2!=C and pow(C,3,169)!=1
    seq=runs(C,n,200000 if quick else R,10000 if quick else K)
    if quick:
        # Direct integer crosscheck shortened prefix of every AP; full medium set gets the polynomial gcd as well.
        test=[(a,d,min(N,113)) for a,d,N in seq[:31]];assert product_gcd(C,test,True)==1
    assert product_gcd(C,seq,False,True)==1,(n,len(str(C)))
    print('certified',n,len(str(C)),'quick' if quick else 'FULL',flush=True);return True

def verify_prices(fixed,quick=False):
    fx=tuple(sorted(map(tuple,fixed)));allowed={tuple(sorted(((13,568),)+u)) for u in profiles+(fixed17,)};assert __debug__ and fx in allowed
    cs,ex=info(fx)
    for n,C in cs:certify(C,n,quick)
    return tuple(cs)

if __name__=='__main__':
    mode=sys.argv[1] if len(sys.argv)>1 else 'all';assert mode in ('quick','all');t=time.monotonic()
    for prof in profiles+(fixed17,):verify_prices(((13,568),)+prof,mode=='quick')
    print('unique',certify.cache_info().currsize,'elapsed seconds',round(time.monotonic()-t,2),'mode',mode,flush=True)
