"""Whole conditional fixed-state verifier. Inputs lattice certificates+archived checker from the cut release.
verify_leaf(fixed,R,folder,lat): fixed includes (13,568), R is repository Research directory, folder contains lattice receipts,
lat supplies check_root(C,rows,folder,R), check_small(ix,inside_rows,folder,R), check_squares(ix,packs,folder,R).
Never set quick mode on the production price check. No cache of proofs by human-supplied booleans.
"""
import math,sys
from pathlib import Path
from fractions import Fraction
from functools import cache
here=Path(__file__).resolve().parent;sys.path.insert(0,str(here));import Prices,Combo568,ExternalDouble,InternalEuler568,EulerStair
B=10**2400

def canonical(fixed):return tuple(sorted(tuple(x) for x in fixed))

def main_ratio(fx):
    cs,fs,V,D,M,ex=Combo568.data(list(fx));C=cs[0];R=Prices.R;G=Prices.K**2
    for j,u in enumerate(cs):
        if j:V*=G*(R**2//(1 if pow(u,3,13)!=1 else 169))
    V*=math.prod(u*u for u in ex)
    assert all(V*G*(2*13**s-1)>B*D*13**(2*s) for s in (0,1))
    assert pow(-C,3,169)!=1
    V*=max(G,R**2//(1 if pow(-C,3,13)!=1 else 169))
    return C,Fraction(V,D)

@cache
def shared_root(folder,R,lat):
    C,rows=EulerStair.work();res=lat.check_root(C,rows,folder,R);assert res is not False
    return C

def verify_leaf(fixed,R,folder,lat):
    # Caller has established seed primality and exact powers and T's blanket theorem; U,D are checked here.
    R=Path(R).resolve();folder=Path(folder).resolve();sys.path.insert(0,str(R/'TeichmullerValuation'));import VerifyTeichmullerValuation2400 as T
    if not __debug__:raise RuntimeError('assertions required')
    assert T.check_lemmas(13) and T.kappa(13)==2
    pf=T.Profile(13,568);assert pf.U(568)==2771 and pf.D(568)==1
    rset=canonical(fixed);allowed=[canonical(((13,568),)+f) for f in Prices.profiles+(Prices.fixed17,)];assert rset in allowed
    ix=allowed.index(rset);proved=Prices.verify_prices(rset);assert len(proved)==4
    if ix==5:
        # All nontrivial fixed sigma blocks contribute two distinct ordinary primes; 17^1 is fixed Euler. No need for 222822400001 range.
        V=13**(3*568);D=2771;R0=Prices.R;K=Prices.K
        for r,f in rset:
            if r==13:continue
            n=Prices.sigma(r,f);b=0
            while n%13==0:n//=13;b+=1
            V*=r**f;D*=13**(2*b)
        for n,C in proved:V*=K*K*(R0*R0//(1 if pow(C,3,13)!=1 else 169))
        assert V>B*D;return True
    fx=list(Prices.profiles[ix]);cs,fs,V,D,M,ex=Combo568.data(fx);assert set(proved)==set(zip((f+1 for r,f in fs),cs))
    # High Euler: 4 blocks supply >=8 distinct primes; at most one Euler label. Robust bound retaining seven generic G, without any extraneous shallow price.
    # Possible explicit extra label as Euler also harmless below (price ignored entirely).
    assert V*(Prices.K**2)**7>B*D
    windows=Combo568.coverage(fx);window=dict(windows);assert all(window[i] is None for i in range(4,len(cs)+len(ex)))
    # exterior: if window empty already concluded. Otherwise the two-source estimate gives f=c=2; check all its candidate squares.
    if window[None] is not None:
        assert ix<4;packs=ExternalDouble.run(fx);assert packs is not None;res=lat.check_squares(ix,packs,folder,R);assert res is not False
    # interior C0: compare all parameters, notably the fifth missing profile to four matching principal C. No premise from a fifth unverified lattice.
    if window[0] is not None:
        c,v=main_ratio(fx);c0,rr=main_ratio(list(Prices.profiles[0]));assert c==c0 and all(main_ratio(list(f))[0]==c for f in Prices.profiles[:4])
        assert v>=min(main_ratio(list(f))[1] for f in Prices.profiles[:4]);assert shared_root(folder,R,lat)==c
    # All secondary blocks in final two-factor window: use established one-price pre-sieve's enclosing boxes for ix<4; no fifth boxes exist.
    if any(window[i] is not None for i in (1,2,3)):
        assert ix<4;rows=InternalEuler568.run(fx);res=lat.check_small(ix,rows,folder,R);assert res is not False
    return True
