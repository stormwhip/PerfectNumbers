"""Exact strengthened double-factor payment for four root-13 profiles: no conditional full exponent claims.
Needs CohortCRT (K=10^9 for exact stripped blocks), RoughProfiles (R=10^11), Multiplicity568. Use fixed state compare on same immutable blocks.
"""
import sys,math
from pathlib import Path
here=Path(__file__).resolve().parent;sys.path.insert(0,str(here));from CohortCRT import block;from All568 import cases
from Multiplicity568 import nonpower
p=13;B=10**2400;R=10**11;K=10**9;G=K*K

def data(fx):
    fs=[(13,568)]+fx;X=math.prod(r for r,f in fs);power=math.prod(r**f for r,f in fs);V=13**(3*568);den=2771;cs=[];extra=[]
    for r,f in fs:
        C=(r**(f+1)-1)//(r-1);b=0
        while C%13==0:C//=13;b+=1
        if r!=13:V*=r**f;den*=13**(2*b)
        while (g:=math.gcd(X,C))>1:C//=g
        u={(5244488101,18):258926453,(11668673,18):280483283}.get((r,f))
        if u:
            assert all(u%i for i in range(2,math.isqrt(u)+1)) and C%u==0 and C%(u*u);C//=u;extra.append(u)
        assert C==block(r,f) and nonpower(C) and math.isqrt(C)**2!=C and pow(C,3,169)!=1;cs.append(C)
    assert all(math.gcd(a,b)==1 for i,a in enumerate(cs) for b in cs[:i]);assert all(math.gcd(u,X*math.prod(cs))==1 for u in extra)
    M=power*math.prod(cs)*math.prod(extra);assert all(u in (258926453,280483283) and pow(u,3,13)!=1 for u in extra)
    return cs,fs,V,den,M,extra

def coverage(fx):
    cs,fs,V,D,M,ex=data(fx);ret=[]
    allp=cs+ex
    for i in [None]+list(range(len(allp))):
        # fixed Euler q equals a seed only if f odd; all seeds here even. If q|C_i then q^1||C_i and q is prime known to be -1 mod13^s in relevant s>=2 cases.
        left=[]
        for s in range(569):
            y=13**s;Q=2*y-1;v=V
            for j,C in enumerate(cs):
                if i!=j:
                    v*=G*(R*R//(1 if pow(C,3,13)!=1 else 169))
                elif s>=2:
                    # There remains >=1 genuine ordinary factor in C/q. When its cofactor class forces shallow, improve generic price.
                    t=-C;v*=max(G,R*R//(1 if pow(t,3,13)!=1 else 169)) if pow(t,3,169)!=1 else G
                else:v*=G
            v*=math.prod(u*u for j,u in enumerate(ex,len(cs)) if i!=j)
            if v*Q>B*D*y*y:continue
            mass=M*math.prod(u for j,u in enumerate(ex,len(cs)) if i!=j)*R**(len(cs)-int(i is not None and i<len(cs)))
            if i is None:
                if mass*Q>B:continue
            elif i>=len(cs):
                q=allp[i]; assert s==0 or (q+1)%y or (q+1)%(13*y)==0 or q>=Q
                if (q+1)%y or (q+1)%(13*y)==0:continue
            elif s:
                n=fs[i][1]+1
                if n==13:continue
                T=4*y;z=Q;z+=T*((1-z)*pow(T,-1,n)%n);T*=n;C=cs[i];hi=min(C//(C*pow(z,-1,T)%T),B*D*y*y//v)
                if z>hi:continue
            left.append(s)
        ret.append((i,None if not left else (min(left),max(left),len(left))))
    return ret
if __name__=='__main__':
    for fx in cases:print(fx,coverage(fx),flush=True)
