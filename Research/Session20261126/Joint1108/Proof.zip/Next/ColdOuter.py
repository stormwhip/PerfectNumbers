"""Unlike the exploratory FinalOuter CLI this exits nonzero on any missing leaf. Only ordinary (i≠13,16) E3a subdomains are handled here."""
from pathlib import Path
import sys,json
here=Path(__file__).resolve().parent;sys.path.insert(0,str(here));from FinalOuter import *
if __name__=='__main__':
    assert __debug__;setup(int(sys.argv[2]));ls=list(map(int,sys.argv[3:]));assert set(ls)<=set(range(42))-{13,16} and len(ls)==len(set(ls))
    for i in ls:
        v=verify(i);assert type(v)==int and 2122*lo(10)+v>2400*hi(10),(i,v);print(json.dumps(dict(i=i,aux=v,total_floor=(2122*lo(10)+v)//hi(10))),flush=True)
    print('PASS external common checks',ls,flush=True)
