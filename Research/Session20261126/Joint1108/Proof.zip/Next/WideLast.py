"""Forced subgraphs for the two >280-decimal-digit tests. Merely adding a residual prime to finite pool credits NO new cost unless the primal full-inflow rows force it. All promoted nodes satisfy completely verified primality and the independent source exclusion. The auxiliary wide-node pool affects the flow only, not the basic branch forest or certificate partition."""
from pathlib import Path
import sys,json,inspect
here=Path(__file__).resolve().parent;sys.path.insert(0,str(here));import Last,FactorCut as fc,Screen as sc,NextFlow as nf,ExternalHybrid as eh,IntegerCut as ic
from ExternalHybrid import *
from copy import deepcopy

def additions(i):
    common=[739,97,43,733,19381,251,631,443,47,53,61,71,101,103,37,149,26881,239,134369,5113,379,709,10303,310711,6124184400074859890635051,990151,3169,1723,1702313,5839,309277,4745137,679007463289,2972777,385894816539270919,296129722925570310535267183093,3035302031019683008546021109,138364619824953525297520160494079932676629423304297]
    if i==13:common+= [25646167,219241969146019,51071,1627771,34625648231,27606453125912051,29074923651740435041,125214181,34770289,217869037,6038099,3664405207,54165082306241,679867073369280149,527784094371286044110809,22949988790587457954297434682037062215980377180112284260858109,4375997670680275555605273053,2336661313161818672990011193252900057,8823703063775220217144216657,15730951653013960377604884173203168952813,307,127159831,19531]
    return common

def install():
    base=Last.eh.model
    def wide(i):
        Z=(cert['cell10']+cert['cell11'])[i];F=deepcopy(Z['forest']);LP=deepcopy(Z['lp']);fc.patch(i,additions(i));dd=base(i);Z['forest']=F;Z['lp']=LP;return dd
    Last.eh.model=wide

def run(i,aim,search):
    install();text=inspect.getsource(Last.verify).replace("key='z'+str(i)",("key='widezC'+str(i)" if i==13 else "key='widez'+str(i)")).replace("f'last{i}-{aim}.json'","f'widelast{i}-{aim}.json'");ctx=dict(vars(Last));exec(text,ctx);return ctx['verify'](i,aim,search)
if __name__=='__main__':
    assert __debug__;setup(int(sys.argv[2]));print(json.dumps(run(int(sys.argv[3]),int(sys.argv[4]),'search' in sys.argv)),flush=True)
