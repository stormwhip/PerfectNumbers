# Root 3, 1108 — post-1162 work, not a full exponent claim

Read `unpack/PerfectNumbers-HEAD` snapshot 2889e47f and parent `joint-lab` support verifiers. No writes outside this research directory. E3a/E3b source hypotheses and notation as in the 1162 pack. The independent parity branch proves ordinary-source baselines at least 2117 and 2089 log10 respectively for e=1108; these are **premises** for these companion checks. The e=1108 window s≥955 follows from the ordinary K=10^8 multiplicative discount, see `Hull.setup`. `NextFlow` checks the A-support abundance allowance by progression trial through 10^8 at the actual e, not by importing the 1162 facts.

## Finite-forest and joint-flow square-hull weights

Given finite named source columns j=(r,f), let v(j,t) be the exact t-valuation of the retained residual; only ordinary r choices are present. Compute H_t=Σ_r max_f v(j,t). For any realized system of columns the simultaneous demand d_t≤H_t; also d_t≤h=v_t(N) by σ(N)=2N. Hence every occurrence can be priced at

 C_t = min_{h positive even permitted} [h ln t -4 ln3 v3(σ(t^h))]/min(H_t,h).

This can be almost twice the former coefficient when the finite set has only one unit of total demand at t. It NEVER claims v_t(N)≤H_t. All tail choices emit zero explicit demand. Cap H_t is an upper bound on the demands actually charged, not on true valuations from unenumerated parents. For h≥h0, use h0 ln t−4 ln(h0+1) for t=1 mod3, h0 ln t otherwise; monotonicity for h≥2,t≥5. The coefficient denominator is then H_t. Exclude absent bases from candidate h by checking σ(t^h) at each finite h.

**Critical no-overlap check.** Whole primes detected after initial trial must be stripped from *every* opaque cofactor. Both `Screen.py` and `FlowHull.py` run a complete second pass, rebuild H_t, and check gcd(opaque,∏t)=1 for every row. This prevents a hidden instance of t inside some other row occupying the same component for square credit and ordinary anonymous credit. In the forest only, active trees are an even smaller selection, still covered. All extra factors have deterministic prime64/Pocklington or verified elliptic Hasse chains (from parent `EC.py`). Untrusted discovery files/leftover PARI outputs are not certificates.

**Covers.** For the internal r|A, all retained residues coprime to A are source-free; all residues must additionally be <Q to exclude q. New forced subtrees are disjoint incl. assigned parent; full every-lawful-exponent DP or one tail choice. For initially inadequate internal forest leaves, exact rational LP dual support branches on a genuinely binary exponent column and covers both 1 and 0; counters and SciPy statuses are never trusted. `FinalInner.py` recomputes its 42/42 result with no SciPy. Frozen source support/frequency uses the parent forest/joint partition, independent of exponent.

**E3a does not inherit E3b bounds.** `OuterFlow.py` discards every unknown or possible source factor even if nominally cheap: its simple result is already sufficient for many leaves. For a sharper cover `ExternalHybrid.py` removes from every row every whole supported piece that shares a prime with a candidate group of source residues (or no group), then computes exact dual. `Oracles.py` instead assigns a conditional flow certificate only to forest scenarios with weak DP and charges the stronger one *under the same source case*; they are never added. `AtomCut.py` independently checks one large flow atom and further binary disjunctions as needed. For grouped overlap, representative integers may be composite. Coverage holds by assuming the source divides one representative and removing all supported costs overlapping it, not by requiring pairwise coprimality. No scenario is allowed to use both credit for the external source and its residual price.

## Replay

```
python -I -S -B joint-lab/Next/FinalInner.py unpack/PerfectNumbers-HEAD 1108
python -I -S -B joint-lab/Next/CheckOuter.py unpack/PerfectNumbers-HEAD 1108 283 1 2 3 4 5 6 7 8 9 10 11 12 29 30 31 32 33 34 35 36 37 38 39 40 41
python -I -S -B joint-lab/Next/AtomCut.py unpack/PerfectNumbers-HEAD 1108 0
```

The parent joint-lab core must be importable and the sealed `joint-lab/Joint/` 1162 deliverable was not modified. Integer branch tree lists encode ordered (x=1 child, x=0 child). Every reduced-cost penalty uses the real range [0,1] with the optional constraints Σ_f x_rf≤1. Only grouped/dual complete covers are acceptable; an integer low solution in a relaxation means no accepted lower certificate, not a candidate odd perfect number.
