"""Exhaustive source-class plus exponent-cases audit. Groups in ExternalHybrid certificate must form exact semantic coverage regardless of solver. Each failing group gets a branch-and-bound certificate in its *correct* cost model, verified by stdlib CheckCut. If q's source occurs in no group, use the no-loss base dual."""
import sys,json
from pathlib import Path
here=Path(__file__).resolve().parent;sys.path.insert(0,str(here));import ExternalHybrid as eh, IntegerCut as ic, CheckCut as cc
from ExternalHybrid import *

def check(i,search=False):
    d=json.loads((here/f'exthyb{i}.json').read_bytes());data,rows,b,names,opts,loss=eh.model(i);xa=list(loss);n=len(data);goal=283*hi(10);iv=names.index('vol');full=d['full'];fullnet=nf.verify(data,rows,b,names,opts,full);assert fullnet>goal or search
    cursor=0;mins=[fullnet];fails=[];extra=0
    from math import prod
    for a,k,dual in sorted(d['records'],key=lambda g:g[0]):
        assert a==cursor and a<k<=len(xa);cursor=k;rr=rows.copy();rr[iv]=rr[iv].copy();P=prod(xa[a:k])
        for t,li in loss.items():
            if gcd(P,t)>1:
                for jj,z in li:rr[iv][jj]-=z
        z=nf.verify(data,rr,b,names,opts,full if dual is None else dual)
        if z<=goal:
            assert k==a+1;target=here/f'atomcut{i}-{a}-{k}{i}.json';key=f'atomcut{i}-{a}-{k}';fun=lambda ii:(data,rr,b,names,opts,{})
            if search and not target.is_file():ic.model=fun;ic.branch(i,283,200,key)
            if target.is_file():
                obj=json.loads(target.read_bytes());
                if obj['info']['complete']:
                    # CheckCut exposes selector through small path parameter shim; require matching file.
                    text=inspect.getsource(cc.check);mark="prefix='hullcut' if 'hull' in sys.argv else 'cut';";assert mark in text
                    env=dict(vars(cc));env['model']=fun;exec(text.replace(mark,'prefix='+repr(key)+';'),env);z=max(z,env['check'](i,283)['minimum']);extra+=1
            if z<=goal:fails.append((xa[a],z))
        mins.append(z)
    assert cursor==len(xa);return dict(i=i,net=min(mins),min_floor=min(mins)//hi(10),cells=len(mins)-1,extra=extra,fails=fails)
if __name__=='__main__':
    assert __debug__;setup(int(sys.argv[2]));
    for i in (int(t) for t in sys.argv[3:] if t.isdigit()):print(json.dumps(check(i,'search' in sys.argv)),flush=True)
