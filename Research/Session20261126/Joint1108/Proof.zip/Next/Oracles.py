"""Exact forest/flow source-case intersection. If full forest without the source is above target, only atoms whose removal spoils its envelope need LP proof. Unknown factors x are NOT assumed prime. All charges supported on gcd(x,*) are excised inside common flow. A saved branch-and-bound witness partitions the exact binary exponent options over ambiguous scenarios."""
import sys,json,inspect
from pathlib import Path
here=Path(__file__).resolve().parent;sys.path.insert(0,str(here));import Outside as of,ExternalHybrid as eh,IntegerCut as ic,CheckCut as cc
from ExternalHybrid import *

def run(i,target,search,condfile=None):
    # Compute full-flow data first, possibly extending in-memory pool; outside forest loader requires original unmodified tree.
    F=(cert['cell10']+cert['cell11'])[i]['forest'];import copy;fcopy=copy.deepcopy(F);data,rows,rhs,names,opts,loss=eh.model(i);(cert['cell10']+cert['cell11'])[i]['forest']=fcopy
    if condfile is None:res=of.run(i,target)
    else:res=condfile
    if res['full']<=target*hi(10):return dict(i=i,undischarged='clean forest below target')
    path=here/f'oracle{i}.json';zrec=[];q=target*hi(10);iv=names.index('vol');minz=min(res['full'],res['safe_min'] if res['safe_min'] is not None else res['full']) # actual nanonat minimum, not just a rounded pass/fail flag
    # Send groups of problematic forest atoms through ONE identical worst-case cost model.
    # Bisection is used only if a covering (over-penalized) group has no complete certificate.
    blocks=sorted(res['unresolved']);failed=[];w=[];todo=[list(range(len(blocks)))] if blocks else []
    while todo:
        which=todo.pop();a,bx=which[0],which[-1]+1;x=math.prod(blocks[h][0] for h in which);v=min(blocks[h][1] for h in which)
        rr=rows.copy();rr[iv]=rr[iv].copy()
        for t,li in loss.items():
            if gcd(x,t)>1:
                for j,price in li:rr[iv][j]-=price
        fun=lambda ii:(data,rr,rhs,names,opts,{})
        import hashlib
        tag=f'case{i}-{hashlib.sha256(str(blocks[a:bx]).encode()).hexdigest()[:16]}-';fp=here/f'{tag}{i}.json'
        if search and not fp.exists():ic.model=fun;ic.branch(i,target,50,tag)
        if not fp.exists() or not json.loads(fp.read_bytes())['info']['complete']:
            if len(which)==1:failed.append((blocks[a][0],v))
            else:m=len(which)//2;todo.extend([which[:m],which[m:]])
            continue
        text=inspect.getsource(cc.check);mark="prefix='hullcut' if 'hull' in sys.argv else 'cut';";assert mark in text;ctx=dict(vars(cc));ctx['model']=fun;exec(text.replace(mark,'prefix='+repr(tag)+';'),ctx);b=ctx['check'](i,target)['minimum'];minz=min(minz,b);w.append((a,bx,b))
    if search:path.write_text(json.dumps(dict(i=i,forest=res,casebounds=w,fails=failed),separators=(',',':')))
    return dict(i=i,groups=res['groups'],fordp=res['lowest']//hi(10),cases=len(blocks),failed=failed,net=minz,netfloor=minz//hi(10))
if __name__=='__main__':
    assert __debug__;setup(int(sys.argv[2]));
    for i in (int(k) for k in sys.argv[3:] if k.isdigit()):print(json.dumps(run(i,283,'search' in sys.argv)),flush=True)
