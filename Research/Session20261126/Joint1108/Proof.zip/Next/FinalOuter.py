"""Exact 1108 E3a replay of independent finite binary / source-group certificates. Use ordinary stdlib or optional GMP-backed FLINT for batch gcd acceleration only. Does not trust saved pass/fail flags; will not claim any leaf with unresolved cells. i=0 special global one-atom cut, 1..12 and 29..41 robust uniform cuts, others conditional forest+flow."""
from pathlib import Path
import sys,json
here=Path(__file__).resolve().parent;sys.path.insert(0,str(here));import OuterFlow,CheckOuter,AtomCut,Oracles
from Screen import *

def verify(i):
    if i==0:
        r=AtomCut.check(i);assert not r['fails'];return r['net']
    if i in list(range(1,13))+list(range(29,42)):
        CheckOuter.model=OuterFlow.model;return CheckOuter.check(i,283)['minimum']
    r=Oracles.run(i,283,False)
    if 'failed' not in r or r['failed']:return None
    return r['net']
if __name__=='__main__':
    assert __debug__;setup(int(sys.argv[2]));ls=list(map(int,sys.argv[3:])) or list(range(42));passed=[]
    for i in ls:
        v=verify(i);tot=None if v is None else 2117*lo(10)+v;good=bool(tot and tot>2400*hi(10));print(json.dumps(dict(i=i,v=v,total_floor=None if not tot else tot//hi(10),good=good)),flush=True)
        if good:passed.append(i)
    print('certified',len(passed),'of',len(ls),passed,flush=True)
