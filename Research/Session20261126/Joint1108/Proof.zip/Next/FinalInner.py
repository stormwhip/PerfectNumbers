"""Final 1108 E3b replay: updated disjoint gcd and total multiplicity check at every leaf. Standalone stdlib with Next/ and prior Joint core. Run with argv[1]=snapshot, argv[2]=1108, optional specific leaves."""
import json,sys
from pathlib import Path
here=Path(__file__).resolve().parent;sys.path.insert(0,str(here));import Screen as sc,CheckCut as cc,FlowHull as flow
from Screen import *

def verify(i):
    if i<=12 or i in (16,23,30):
        cc.model=flow.model;return cc.check(i,311)['minimum']
    rec=json.loads((here/f'tree{i}.json').read_bytes());F=(cert['cell10']+cert['cell11'])[i]['forest'];pool=set(map(int,F['cut_even']))
    for r,t in rec['edges']:
        assert r in pool and t not in pool;pool.add(t);F['edges'].setdefault(str(r),[]).append(t);F['cut_even'][str(t)]=4
    assert rec['wide']>=315;return sc.solve(i,wide=rec['wide'])['net']
if __name__=='__main__':
    assert __debug__;setup(int(sys.argv[2]));ls=list(map(int,sys.argv[3:])) or list(range(42));sys.argv.append('hull');passed=[]
    for i in ls:
        v=verify(i);tot=2089*lo(10)+v;good=tot>2400*hi(10);print(json.dumps(dict(i=i,v=v,total_floor=tot//hi(10),good=good)),flush=True)
        if good:passed.append(i)
    print('certified',len(passed),'of',len(ls),passed,flush=True);assert len(passed)==len(ls)
