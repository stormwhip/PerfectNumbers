"""CPU-independent, fixed-snapshot 1108 Python cold run. FIRST compile/run Base/Trial1108.cpp (or use FLINT alternative). Child scripts inherit stdout; cwd independent; no writes to snapshot. The hardest leaf may use a separate sibling Hard/ pool data set; all other cases use Next/ unchanged. No result is accepted from cached logs."""
import sys,subprocess,json
from pathlib import Path
P=Path(__file__).resolve().parent
if len(sys.argv)<2:raise SystemExit('Usage: python -I -S -B Complete.py <frozen repo root> [--fast]')
ROOT=Path(sys.argv[1]).resolve()
def run(file,*rest):subprocess.run([sys.executable,'-I','-S','-B',str(P/file),*map(str,rest)],check=True)
if __name__=='__main__':
    assert __debug__;fast=['--fast'] if '--fast' in sys.argv else [];run('Prelude.py',ROOT);run('Base/InternalSupply.py');run('Base/Fast1108.py',2122,*fast);run('Base/InternalPrefix.py',2089,*fast);run('Next/FinalInner.py',ROOT,1108);run('Next/ColdOuter.py',ROOT,1108,*[i for i in range(42) if i not in (13,16)]);run('Next/ColdWide.py',ROOT,1108,16,278);run('Hard/ColdWide.py',ROOT,1108,13,278);print('PASS all Python parts: e=1108; require separate Trial1108.cpp range check')
