"""Targeted 2120-base two hard-leaf pass. Serial deterministic per-source grouping from the current common forest, with capped atom-specific exact binary witnesses. Never changes old low-precision/higher-threshold trees. Stdlib verify, SciPy for discover."""
import sys,math,json,hashlib,inspect
from pathlib import Path
here=Path(__file__).resolve().parent;sys.path.insert(0,str(here));import ExternalHybrid as eh,IntegerCut as ic,CheckCut as cc,Outside as of,Screen as sc
from ExternalHybrid import *

def verify(i,aim,search=False):
    import copy
    L=(cert['cell10']+cert['cell11'])[i];F=copy.deepcopy(L['forest']);data,rows,rhs,names,opts,loss=eh.model(i);L['forest']=F
    forest=of.run(i,aim);target=aim*hi(10);iv=names.index('vol');bad=sorted(forest['unresolved']);assert forest['full']>target
    observed=[forest['full']]+([forest['safe_min']] if forest['safe_min'] is not None else []);wp=here/f'last{i}-{aim}.json';book=json.loads(wp.read_bytes()) if wp.is_file() else {};closed=[];fails=[]
    def case(ix):
        a,b=ix[0],ix[-1]+1;xs=[bad[h][0] for h in ix];P=math.prod(xs);rr=rows.copy();rr[iv]=rr[iv].copy()
        for t,li in loss.items():
            if gcd(P,t)>1:
                for k,z in li:rr[iv][k]-=z
        # index independent id includes actual atom list; stable across forest price changes.
        key='z'+str(i)+'-'+str(aim)+'-'+hashlib.sha256(str(xs).encode()).hexdigest()[:20]+'-';fp=here/f'{key}{i}.json';fn=lambda _:(data,rr,rhs,names,opts,{})
        if search and (not fp.is_file()):ic.model=fn;ic.branch(i,aim,120,key)
        z=0
        if fp.is_file():
            r=json.loads(fp.read_bytes());
            if r['info']['complete']:
                tx=inspect.getsource(cc.check);m="prefix='hullcut' if 'hull' in sys.argv else 'cut';";assert m in tx;ns=dict(vars(cc));ns['model']=fn;exec(tx.replace(m,'prefix='+repr(key)+';'),ns)
                try:z=ns['check'](i,aim)['minimum']
                except (AssertionError,KeyError):z=0
        if z>target:closed.append([a,b,key]);observed.append(z)
        elif len(xs)>1:
            mid=len(ix)//2;case(ix[:mid]);case(ix[mid:])
        else:
            br=bad[ix[0]];fails.append(br);observed.append(br[1]);print('need',i,br[0],br[1],flush=True)
    if bad:case(list(range(len(bad))))
    summary=dict(i=i,aim=aim,net=min(observed),floor=min(observed)//hi(10),closed=closed,fail=fails,forest_groups=forest['groups'],forest_low=len(bad))
    if search:wp.write_text(json.dumps(summary,separators=(',',':')))
    return summary
if __name__=='__main__':
    assert __debug__;setup(int(sys.argv[2]));
    for i in (int(t) for t in sys.argv[4:] if t.isdigit()):print(json.dumps(verify(i,int(sys.argv[3]),'search' in sys.argv)),flush=True)
