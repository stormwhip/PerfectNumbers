"""Prepare adding global optional emitter cutoffs without changing existing mandatory supports: a prime with short tail may have cheap fictitious zero outflow. New member optional; old proof remains intact."""
from pathlib import Path
import sys,json,inspect
here=Path(__file__).resolve().parent;sys.path.insert(0,str(here));import NextFlow as nf,OuterFlow as of, IntegerCut as ic
from NextFlow import *

def patch(i,extras):
    l=(cert['cell10']+cert['cell11'])[i];F=l['forest'];LP=l['lp'];from copy import deepcopy
    if LP is None:l['lp']={'P':[]}
    pool=set(map(int,F.get('cut_even',{})));lp=l['lp']['P'];avail=[t for t in extras if t not in pool and t not in l['absent_extra'] and t not in BAN and (prime(t) or t in nf.sc.extra()[1]) and j.nosource(t)];lp.extend(t for t in avail if t not in lp)
    # Before generating model, designate selected LP primes as wide cutoffs in an isolated wrapper. Do not add to actual forest.
    for r in avail:F['cut_even'][str(r)]=4

if __name__=='__main__':
    assert __debug__;setup(int(sys.argv[2]));i=int(sys.argv[3]);xs=[739,97,43,733,19381,251,631,127159831,19531,66721,443,267431,292561,579281,47,53,61,71,101,103,37,149,26881,1702313,5839,239,134369]
    patch(i,xs);ic.model=of.model;print(json.dumps(ic.branch(i,283,350,'widecut')),flush=True)
