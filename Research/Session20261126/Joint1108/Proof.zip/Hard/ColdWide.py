"""Final strict conditional-source certificate (all branches must have checked duals)."""
from pathlib import Path
import sys,json
here=Path(__file__).resolve().parent;sys.path.insert(0,str(here));import WideLast as w
if __name__=='__main__':
    assert __debug__;w.setup(int(sys.argv[2]));i=int(sys.argv[3]);goal=int(sys.argv[4]);r=w.run(i,goal,False);assert 278<=goal and not r['fail'] and 2122*w.lo(10)+r['net']>2400*w.hi(10),(i,r);print(json.dumps(r),flush=True)
