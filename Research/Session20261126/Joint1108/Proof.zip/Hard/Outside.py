"""External-source forest optimized per residue. Every residual retained after stripping named primes is below Q and coprime to A. It can overlap the external source. For each source scenario delete *all* numbers sharing that prime; use a budget-sieving forest oracle to prune safe scenarios. Residues may be left composite; no pairwise coprime assumption across different rows."""
import sys,json,inspect
from pathlib import Path
here=Path(__file__).resolve().parent;sys.path.insert(0,str(here));import Screen as sc
from Screen import *
# split out model generation; preserve exact verified coefficient inequalities
s=inspect.getsource(sc.solve);p='    @cache\n    def dp(r,m):';assert s.count(p)==1
s=s.split(p)[0]+'    return roots,child,cutoff,opts,weights\n';ns=dict(vars(sc));exec(s,ns);model=ns['solve']

def run(i,goal):
    L=(cert['cell10']+cert['cell11'])[i];F=L['forest'];rec=json.loads((here/f'tree{i}.json').read_bytes());pool=set(map(int,F['cut_even']));
    for r,t in rec['edges']:
        assert r in pool and t not in pool;F['edges'].setdefault(str(r),[]).append(t);F['cut_even'][str(t)]=4;pool.add(t)
    roots,edges,cut,opts,wt=model(i,rec['wide']);rows={};unk={};ids={};target=goal*hi(10)+10000;minproof=None
    for r,ops in opts.items():
        ls=[];rows[r]=ls
        for f,S,c,v,ks,left in ops:
            # only buy proven non-source factors, or track the whole potentially overlapping factor under one identity
            paid=c+v+sum(k*wt[t] for t,k in ks);loss={}
            for t,k in ks:
                if not j.nosource(t):loss[t]=k*wt[t]
            if left>1:loss[left]=v
            for x in loss:
                if x not in ids:ids[x]=len(ids)
            ls.append((f,paid,[(t,val(S,t)) for t in edges.get(r,[]) if S%t==0],{ids[t]:v for t,v in loss.items()}))
    xs=list(ids)
    def dp(bad):
        @cache
        def go(r,m):
            fe=max(cut[r],m+m%2);best=fe*lo(r)-(4*hi(fe+1) if r%3==1 else 0)
            for f,c,ch,v in rows[r]:
                if f<m:continue
                cost=c-sum(z for k,z in v.items() if k in bad)
                if cost>=best:continue
                for t,h in ch:
                    cost+=go(t,h)
                    if cost>=best:break
                best=min(best,cost)
            return best
        return sum(go(r,2) for r in roots)
    full=dp(set());todo=[list(range(len(xs)))];lowest=full;unresolved=[];tested=0;groups=0
    @cache
    def product(a,b):
        if b-a==1:return xs[a]
        m=(a+b)//2;return product(a,m)*product(m,b)
    from Batch import adjacency
    adj=adjacency(xs)
    while todo:
        src=todo.pop();# source divides one of xs[src]. All overlapping other residues are potentially contaminated.
        # A product of representatives supports all possible prime divisors in this subset.
        from math import prod
        # On large nodes use all costs pessimistically, or memoize by overlap map at small nodes.
        if len(src)==len(xs):bad=set(range(len(xs)))
        else:
            # Batch residues via a product/remainder tree; reduces huge P modulo sibling subproducts once per level.
            bad=set.union(*(adj[k] for k in src))
        v=dp(bad);tested+=1
        if v>target or len(src)==1:
            lowest=min(lowest,v);groups+=1
            if v<=target:unresolved.append((xs[src[0]],v))
            else:minproof=v if minproof is None else min(v,minproof)
        else:
            m=len(src)//2;todo.extend([src[:m],src[m:]])
    return dict(i=i,full=full,safe_min=minproof,lowest=lowest,digits=lowest//hi(10),groups=groups,tested=tested,unresolved=unresolved)
if __name__=='__main__':
    assert __debug__;setup(int(sys.argv[2]));goal=int(sys.argv[3]);
    for i in map(int,sys.argv[4:]):print(json.dumps(run(i,goal)),flush=True)
