# Root 3, exponent 1108: portable companion certificate

**Result:** the separate integer range check, initial branches, source theorem, and the 42 internal plus 42 external conditional net certificates jointly exclude the actual exponent (3,1108). The weakest final node is external leaf 13 (net 640677831930 nanonats) and requires the **2122** external base, not 2120. This does not close the other three exponents.

**Fixed input:** `Research/P3I00193Review/Candidate/P3E1162Complete.json` in snapshot `2889e47f6db49c8a9bc8dda2c9153829c18a70ca`, raw SHA256 `54652cb67d6f807170248c00eb0c9004a200cd7b9027a73e923b7ea1a46cb30b`. This 1162 file is used only as untrusted support/forest hints; fixed e=1108, A, source tests, abundance, parent inflows and all root power obligations are rechecked. No dependence on a solver, PARI, internet, or `theory-lab` at verification time. Python 3.11+ `-I -S -B`, assertions enabled; one standalone C++17 GCC/Clang trial (or alternative FLINT range).

From any directory, set PACK to this directory and REPO to the reference checkout. On Windows replace `/tmp/...` with paths in a private worker directory. Commands:

```
python -I -S -B $PACK/Prelude.py $REPO
g++ -O3 -std=c++17 $PACK/Base/Trial1108.cpp -o /tmp/proof1108-range && /tmp/proof1108-range
# Optional independent cross-check: python -I -S -B $PACK/Base/NextRange.py  (needs python-flint==0.9.0 in Base/vendor)
python -I -S -B $PACK/Base/Fast1108.py 2122
python -I -S -B $PACK/Base/InternalSupply.py
python -I -S -B $PACK/Base/InternalPrefix.py 2089
python -I -S -B $PACK/Next/FinalInner.py $REPO 1108
```

`Fast1108` and `InternalPrefix` work without vendor when `--fast` is omitted. To accelerate, provide python-flint in `Base/vendor` and add `--fast`, which changes only modular arithmetic implementation. `Prelude.py` runs the frozen E0/E1/E2 program with its JSON writer redirected to RAM, replays the supplied general b=0 proof and 12+30 support cover. `InternalSupply` is redundant under b=0 but included for an independent guard. See `Next/NOTES.md` for the total incoming capacity argument and disjointness audit.

## Thresholds (strict)

The external E3a base is >10^2122; internal E3b >10^2089. In addition to running the independent C++ range executable, the complete Python invocation is `python -I -S -B $PACK/Complete.py $REPO`. This runs all preceding Python prerequisites plus all three external verifiers (the ordinary 40, and the two isolated hard leaves). `--fast` is optional and affects the two base power sweeps only. For a manual replay use `Next/ColdOuter.py $REPO 1108` followed by the 40 indices other than 13,16; `Next/ColdWide.py $REPO 1108 16 278`; and `Hard/ColdWide.py $REPO 1108 13 278`. The combined script supplies those explicit indices. Every successful comparison is against an upper enclosure of 2400 ln 10. The minima in Internal/External order are 725613132094 net nanonats (leaf 16) and 640677831930 net nanonats (leaf 13). The ordinary 40 have their weakest auxiliary bound 651699757732 (leaf 18); the separate external leaf 16 obtains 644937099608. Net cost is added only to its corresponding uniform 2089 or 2122 base.
