"""E3a valuation+private cyclotomic incoming-mass transfer, conditional on the chosen emitter r being disjoint from all forced W factors.
Sufficient disjointness: r=2 mod3 AND r!=1 mod13. No low-cost assumption, works for every b=v13(sigma(r^f)).
"""
from pathlib import Path
from math import gcd
import sys,json
root=Path(sys.argv[1]);sys.path.insert(0,str(root/'Research/EulerOneSieve'));import TeichmullerBaseline as T
p=13; B=10**2400;K=10**5

def guard(p,e,prof,s,k=0):
    # k distinct INTERNAL suppliers among non-emitter u of odd order 3: each has the extra K^2 price established by CRT.
    pe=p**e;A=(p*pe-1)//(p-1);U=prof.U(e);y=p**s;q=2*y-1
    return 2*pe*A*q*q*p**(e-s)*K**(2*k)>3*B*U

def tables(e):
    pr=T.Profile(13,e);U=pr.U(e);assert U==2771
    out=[min(s for s in range(1,e+1) if guard(13,e,pr,s,k)) for k in range(8)]
    print(dict(e=e,U=U,min_s_for_n_internal_cubic_suppliers=out))
    # Cross-check easy monotonic Q²/p^s = (2y−1)^2/y strictly increases. Verify the tails instead of trusting formula.
    for k,s0 in enumerate(out):assert all(guard(13,e,pr,s,k) for s in range(s0,e+1))
if __name__=='__main__':
    tables(612);tables(618)
