"""Exact Euler coefficient prefix exclusion for r∤A and all b. Returns mass alternative or p^s coefficient bound for possible q.
"""
import sys,math
from pathlib import Path
here=Path(__file__).resolve().parent;sys.path.insert(0,str(here));from Source13 import *

def tighter(e,s,m):
    # If C<q² then all r<q. Each group d tested once with its *smallest* encountered f; later f only shrinks cap.
    y=p**s;q=2*m*y-1;C=limit(e,s,q)
    if C<1:return True,0
    if C>=q*q:
        out,groups=survey(e,s,m);return not out,groups
    maxf=C.bit_length();assert maxf+1<q;ss={1};groups=0
    for f in range(2,maxf,2):
        d=math.gcd(f+1,q-1)
        if d in ss:continue
        for a in range(2,100):
            g=power(a,(q-1)//d,q);z=g;x=[1]
            while z!=1 and len(x)<d:x.append(z);z=z*g%q
            if z==1 and len(x)==d:break
        else:return False,groups
        groups+=1
        for r in x[1:]:
            if (r.bit_length()-1)*f>=C.bit_length() or r**f>C:continue
            if r%2 and all(r%t for t in ban) and power(2,r-1,r)==1:return False,groups
        ss.add(d)
    return True,groups

def check(e,slo,shi,cap):
    assert __debug__;small=[i for i in range(3,20000,2) if all(i%j for j in range(2,math.isqrt(i)+1))];n=0;o=0
    for s in range(slo,shi+1):
        y=13**s;assert 2*y-1>20000;bs=bytearray(b'\1')*(cap+1);bs[::2]=bytes(cap//2+1)
        for t in (*ban,13):bs[::t]=bytes(cap//t+1)
        for t in small:
            if t==13:continue
            k=pow(2*y,-1,t)
            if k<=cap:bs[k::t]=bytes((cap-k)//t+1)
        st=0;og=0
        for m in range(1,cap+1,2):
            if not bs[m]:continue
            q=2*m*y-1
            if power(2,q-1,q)!=1:continue
            yes,g=tighter(e,s,m);assert yes,(e,s,m);st+=1;og+=g
        n+=st;o+=og;print('s',s,'prefix probable survivors',st,'orders',og,flush=True)
    print(dict(e=e,slo=slo,shi=shi,max_m=cap,conditional_prime_count=n,order_group_checks=o),flush=True)
if __name__=='__main__':check(*(int(v) for v in sys.argv[1:5]))
