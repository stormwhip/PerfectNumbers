# A 176–226 digit valuation surplus for the actual Euler emitter

Let r^f be the external ordinary source of q, b=v13(σ(r^f)), N≤10^2400. For each (e,s0,K) certified below, if s≥s0 then r^f / 13^(2b) > K². No hypothesis on the class of r mod3, or m, is needed.

|e|s0|K|proved surplus >|initial rectangle hits|full interval checks|
|---:|---:|---:|---:|---:|---:|
|612|238|10^88|10^176|8|1676|
|618|236|10^88|10^176|1672|318411|
|612|306|10^112|10^224|0|402|
|618|309|10^113|10^226|0|364|

First 13|(f+1) is impossible by the q order-reduction and mass test. If b=0 then r^f>2q/3>K². For b>0, ord13(r)=3, so 3|(f+1), and r²+r+1 has v13=b because j=0. Teich price of the ordinary component r² implies r²/13^(2b)≥1/U_e (one-prime deficit bounded by product U_e=2771). Thus if f≥8, r^f/13^(2b)≥r^(f−2)/U_e≥(r^f)^(3/4)/U_e>(2q/3)^(3/4)/U_e>K² by strict integer comparison. Only f=2 could survive.

For fixed b=1..e−s0 set M=13^b and lift x mod M of one of the two nontrivial cubic classes 3,9. If r²/13^(2b)≤K² then r=x+Mk with 0≤k≤K. Put z=(r²+r+1)/M. The integer w=z/q is positive and w≤z/Q, Q=2·13^s0−1. The modulus T=min(M,13^s0) divides q+1; therefore

    w ≡ −z ≡ −(x²+x+1)/M − (2x+1)k  (mod T).

The quadratic k² term disappears modulo T. Additional exact bounds: r² q P A R ≤B (disjoint square hull on A) and r² z P A≤B (multiplicative input, NO extra R); and r²+r+1≥M Q. These give a short interval of candidate k, although the literal number of integers therein can be ~10^110. For this interval count the residues not exceeding the endpoint-specific upper bound on w by Euclidean floor sums, recurse only into nonempty halves; if a singleton remains, check r's necessary trial/primality conditions and actual divisibility and candidate q. The full proofs do not accept any unresolved positive class. No general Fermat success is treated as primality. Formula for # residues ≤W in progression ak+b: n − (Σfloor((ak+b+T−W−1)/T)−Σfloor((ak+b)/T)); standard Euclidean recursion. The optional audit compares 10000 deterministic randomized small cases against literal enumeration. For replay execute `CheapSource13.py e s0 digits` with digits=88,88,112,113 respectively. No LP or third-party module. In this package assumptions about R and U are precisely those of the previously supplied anonymous-block certificate.

**Independent counting for price use:** Since r is outside A, any ordinary prime premiums collected about A, including the certified shallow factor >R²/13² and the other distinct ordinary factors >10^10 each, remain disjoint from the above surplus. Sums of these prices are legal; other mass-ledger lower bounds must be taken as maxima, not multiplied without proving divisibility. `CombineGuard13.py` gives sample consequent numerical count caps on the full s windows; these do not close an exponent.
