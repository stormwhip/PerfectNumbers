"""Export/read final finite ordinary source domain, conditional on earlier full-window proof receipts (no subsumption assumed)."""
from pathlib import Path
from math import gcd
import sys,json,contextlib,io
here=Path(__file__).resolve().parent;sys.path.insert(0,str(here));from OrderTight13 import domains

def verify():
    res=json.loads((here/'SurvivingRegions.json').read_bytes());assert len(res)==2
    for row in res:
        e=row['e'];s=row['s_min'];z=domains(e,s,2000001)
        ref=[dict(f=f,order=d,rmin=l,rmax=h,b_possible=bp) for f,d,l,h,bp in z if f<70]
        assert ref==row['regions'] and len(ref)==31 and all(v['order']==v['f']+1 for v in ref)
        print(dict(e=e,smin=s,smax=456 if e==612 else 450,degree_count=31,maximum_degree=68),flush=True)
if __name__=='__main__':verify()
