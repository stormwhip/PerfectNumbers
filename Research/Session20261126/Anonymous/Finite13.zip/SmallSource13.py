"""Exact all-coefficient ordinary Euler-source sieve for r<=L; no factorization/primality claims for surviving q.
Given s>=s0, q≡2p^s0−1 mod4p^s0. Let z=σ(r^f)/p^b; since z odd and q|z, w=z/q has a known residue mod4p^s0.
Test exact w candidates. Necessity lower bound p^e A' r^f z |? p^e A r^f z divides N by distinct sigma inputs; do NOT add square premium to this mass.
"""
import sys,math
p=13;B=10**2400;ban=(7,11,19,31)

def primes(L):
    b=bytearray(b'\1')*(L+1);b[:2]=b'\0\0'
    for t in range(2,math.isqrt(L)+1):
        if b[t]:b[t*t::t]=bytes((L-t*t)//t+1)
    return [t for t in range(3,L+1,2) if b[t]]

def test(e,s0,L):
    A=(p**(e+1)-1)//12;P=p**e;lim=B//(P*A);Y=p**s0;Q=2*Y-1;T=4*Y;inv=pow(Q,-1,T);N=0;K=0;W=0;out=[]
    # Every possible r^f has p^e A r^f q<=B (r external) so monotone tail bound.
    rcap=lim//Q
    for r in primes(L):
        if r in (*ban,p) or A%r==0:continue
        rr=r*r;rf=rr;f=2
        while rf<=rcap:
            n=(rf*r-1)//(r-1);z=n
            while z%p==0:z//=p
            if z>=Q and rf*z<=lim and all(z%t for t in ban):
                K+=1;w=(z*inv)%T;assert w>0
                while w*Q<=z:
                    W+=1
                    if z%w==0:
                        q=z//w
                        if q%4==1 and pow(2,q-1,q)==1:out.append((r,f,q))
                    w+=T
            rf*=rr;f+=2
        N+=1
    print(dict(e=e,s_min=s0,Y_digits=len(str(Y)),limit=L,source_primes_tested=N,geometric_options=K,cofactor_candidates=W,remaining=len(out)),flush=True)
    assert not out,[(r,f,len(str(q))) for r,f,q in out[:4]]
if __name__=='__main__':test(*(int(x) for x in sys.argv[1:4]))
