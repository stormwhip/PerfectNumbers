"""Integer finite (f,r)-bound and possible multiplicative order d of the chosen Euler prime.
Actual r in the interval must satisfy q|sigma(r^f), and q chosen as 2m13^s−1; no unproved factorization.
"""
import sys,math
p=13;B=10**2400

def ceilingroot(n,f):
    if n<1:return 0
    l=0;h=1<<(n.bit_length()//f+2)
    while l+1<h:
        m=(l+h)//2
        if m**f<=n:l=m
        else:h=m
    return l

def run(e,s0,minr,detail=False):
    P=13**e;A=(P*13-1)//12;lim=B//(P*A);R=1+2*(e+1)*65536*100000;Q=2*13**s0-1
    out=[];f=2
    while minr**f*Q*R<=lim:
        j=0;n=f+1
        while n%13==0:j+=1;n//=13
        if j:
            # q | sigma(r^((f+1)/13-1)) -> r^f > (2q/3)^13. This contradicts P A r^f q<=B here.
            assert P*A*Q*(2*Q)**13>3**13*B
            f+=2;continue
        # Thus b nonzero only if 3|f+1; then ord_p(r)=3, b=v_p(r^3−1) and 13^b|r²+r+1.
        # lim >= r^f sigma(r^f)/13^b > r^(2f)/(r²+r+1) >= (1/2)r^(2f-2).
        # If 3 does not divide f+1, b=0 => even stronger r^(2f)<lim directly. r>minr.
        b_possible=(f+1)%3==0
        up0=ceilingroot(lim//(Q*R),f);u=ceilingroot(2*lim,2*f-2) if b_possible else ceilingroot(lim,2*f)
        up=min(up0,u)
        orders=[d for d in range(3,f+2,2) if (f+1)%d==0 and d%13]
        # q much larger than f, r!=1 (mod q). To avoid assuming r<q, finite congruences valid even when r larger.
        if up>=minr and orders:out.append((f,minr,up,orders,b_possible))
        f+=2
    print(e,s0,'fmax',max(v[0] for v in out),'exponents',[v[0] for v in out],'nonzero supply f',[v[0] for v in out if v[4]],flush=True)
    if detail:
        for f,lo,hi,ds,b in out:print(f,lo,hi,ds,int(b))
    return out
if __name__=='__main__':
    for e,s in ((612,242),(618,238)):run(e,s,30001,'--details' in sys.argv)
