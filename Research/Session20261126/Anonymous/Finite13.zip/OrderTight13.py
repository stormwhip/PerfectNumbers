"""Certified sharp order d and two-sided r intervals for all remaining source exponent cells. Exact cyclotomic bounds.
Assumes external Euler emitter, r>=minr via Sweep13, s>=s0; q conditional prime. See note for covering all f including index divisors.
"""
from pathlib import Path
from math import gcd
from functools import cache
import sys
here=Path(__file__).resolve().parent;sys.path.insert(0,str(here));from FiniteEmitter13 import run,ceilingroot
@cache
def phi_eval(x,n):
    z=x**n-1
    for d in range(1,n):
        if n%d==0:z//=phi_eval(x,d)
    return z

def domains(e,s0,L,write=False):
    Q=2*13**s0-1;rows=run(e,s0,L);ans=[]
    for f,lo,hi,ds,poss in rows:
        for d in ds:
            # Phi is increasing for real x>1, by conjugate pair product over primitive dth unit roots.
            if phi_eval(hi,d)<Q:continue
            a=0;b=hi
            # solve Phi_d(r)>=Q, no high-degree factorization. log2(hi) iterations worst. Shrink using phi degree.
            deg=sum(gcd(i,d)==1 for i in range(1,d+1));# (r-1)^deg <= Phi_d(r) <= (r+1)^deg
            a=max(lo-1,ceilingroot(Q-1,deg)-1);b=min(b,ceilingroot(Q,deg)+3);assert phi_eval(b,d)>=Q
            while a+1<b:
                m=(a+b)//2
                if phi_eval(m,d)>=Q:b=m
                else:a=m
            low=max(lo,b)
            if low>hi:continue
            ans.append((f,d,low,hi,poss));
    print(e,'s>=',s0,'rows',len(ans),'all d=f+1',all(f+1==d for f,d,lo,hi,p in ans),'f range',min(r[0] for r in ans),max(r[0] for r in ans));
    if write:
        for f,d,lo,hi,b in ans:print(e,s0,f,d,lo,hi,int(b))
    return ans
if __name__=='__main__':
    for e,s in [(612,238),(618,236)]:domains(e,s,2000001,'--details' in sys.argv)
