"""E3b EMITTER NET PREMIUM: r|A. If r²|A high cubic lift enough to contradict existing AnonymousGuard square certificate. If v_r(A)=1, own r^2 loses one r in mass but price test and capped slope suffice.
Exact floor-sum source-price screen under assumption b<s0 or with truncated T; no additional 1st-order lattice needed for f=2.
"""
from pathlib import Path
from math import isqrt,gcd
import sys
here=Path(__file__).resolve().parent;sys.path.insert(0,str(here));from CheapSource13 import below
p=13;B=10**2400;U=2771

def guard(e,s0,digits,verbose=False):
    C=(13**(e+1)-1)//12;D=2*(e+1);R=1+D*65536*100000;assert gcd(C,D*p)==1 and all((e+1)%j for j in range(2,isqrt(e+1)+1));K=10**digits;Y=13**s0;Q=2*Y-1
    assert 13**e*Q*(2*Q)**13>3**13*B # j>=1 impossible, no A factor used in this bound
    assert 2*Q>3*K*K and (2*Q)**3>27*(U*K*K)**4
    m=1;roots=(3,9);tot=0;hits=0;branches=0;checks=0
    for b in range(1,min(e-s0+1,200) if '--single' in sys.argv else e-s0+1):
        m*=13;T=min(m,Y)
        for x in roots:
            # r=x+m*k; owner block r=1 mod2(e+1), equivalent k=k0+D*i.
            k0=(1-x)*pow(m,-1,D)%D;z=x+m*k0;step=m*D
            lo=max(R+1,isqrt(m*Q)-1);hi=min(K*m,isqrt(B//(13**e*Q)),C)
            # Even without r disjoint, A z_sigma|N where z_sigma=(r²+r+1)/m is p-free. If r²|A only use that; if r²∤A then r is available for one further power.
            hi=min(hi,isqrt(m*(B//(13**e*C))))
            if b in range(124 if e==612 else 125,e+1):
                # Appeal to the prior published square-screen: v_r(A)=1; gain an extra r. Prove r³<=m*B/(P A).
                a=0;c=1<<(( (m*(B//(13**e*C))).bit_length()+2)//3)
                while a+1<c:
                    v=(a+c)//2
                    if v**3<=m*(B//(13**e*C)):a=v
                    else:c=v
                hi=min(hi,c)
            # If r>=initial CRT representative then also A/r == A/z (mod step). This upper can cut very high levels.
            if z>1:hi=min(hi,C//(C*pow(z,-1,step)%step))
            l=max(0,(lo-z+step-1)//step);h=(hi-z)//step
            if l>h:continue
            coef=-(2*x+1)*D;bias=-(x*x+x+1)//m-(2*x+1)*k0
            def positions(a,c):
                u=z+c*step;W=(u*u+u+1)//(m*Q)
                return below(c-a+1,coef,bias+coef*a,T,W)
            count=positions(l,h);tot+=count;branches+=1
            if count>10**6:print(e,s0,digits,'excess rectangle',b,len(str(count)),flush=True);return False
            todo=[(l,h)] if count else []
            while todo:
                a,c=todo.pop();checks+=1
                if positions(a,c)==0:continue
                if a==c:
                    r=z+a*step
                    if C%r==0:print('actual divisor or composite in class',e,s0,b,r);return False
                    continue
                mid=(a+c)//2;todo.extend(((a,mid),(mid+1,c)))
        roots=tuple(pow(x,13,13*m) for x in roots)
    print(dict(e=e,s0=s0,K=digits,initial=tot,branches=branches,floor_splits=checks,certified=True),flush=True);return True
if __name__=='__main__':assert guard(*map(int,sys.argv[1:4]))
