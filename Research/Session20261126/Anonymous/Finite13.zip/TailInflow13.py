"""Full-nonabsorber s-window: m small via exact Euler order; m large via sigma-emission/ordinary-supplier lower bound. No valuation LP.
"""
from pathlib import Path
import sys,math
here=Path(__file__).resolve().parent;sys.path.insert(0,str(here));from Prefix13 import tighter,power,ban
B=10**2400;U=2771

def go(e,s0,k,cap):
    p=13;pe=p**e;A=(p*pe-1)//12;n=ng=nc=0;small=[z for z in range(3,30000,2) if all(z%i for i in range(2,math.isqrt(z)+1))]
    for s in range(s0,e+1):
        y=13**s;K=2*pe*A*p**(e-s)*10**(10*k);qr=math.isqrt((3*U*B)//K);l=(qr+1)//(2*y)
        if not l:break
        assert l<cap,(e,s,k,l)
        ss=bytearray(b'\1')*(l+1);ss[::2]=bytes(l//2+1)
        for t in (*ban,13):ss[::t]=bytes(l//t+1)
        for t in small:
            if t==13:continue
            a=pow(2*y,-1,t)
            if a<=l:ss[a::t]=bytes((l-a)//t+1)
        for m in range(1,l+1,2):
            if not ss[m]:continue
            q=2*m*y-1
            if power(2,q-1,q)!=1:continue
            ok,g=tighter(e,s,m);assert ok,(e,s,m,k);ng+=g;nc+=1
        n+=l;print(s,l,nc,flush=True)
    print(dict(e=e,s0=s0,k=k,m_prefix=n,cond_q=nc,group_checks=ng),flush=True)
if __name__=='__main__':go(*map(int,sys.argv[1:5]))
