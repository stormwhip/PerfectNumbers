"""Strong internal-source (r|A) all-s g=1 cofactor pressure using known exact fixed A and bounded order.
General balanced-gap forms D1,D2 from Proof2400 §3.3, sharpen denominator by actual lower bound r>R.
"""
import sys,math
p=13;B=10**2400

def raw(e,s,q,b=0):
    P=p**(e+1);A=(P-1)//(p-1);pe=P//p;z=p**(s+b);delta=P//z;R=1+2*(e+1)*65536*100000
    # Universal D1,D2 gap in t=r^(f-c). If r-1≥2delta use stronger D2 yielding t ≥ Z/[3H].
    # Plus bound when f≥c secured by product A | N.
    I=z*q//(max(q,P)*(3 if R>=2*delta+1 else delta+4));return pe*A*q*max(1,I)

def cutoff(e):
    for s in range(1,e+1):
        y=p**s;q=2*y-1
        if raw(e,s,q)>B and all(raw(e,k,2*p**k-1)>B for k in range(s,e+1)):print(dict(e=e,all_internal_source_excluded_from_s=s));break
if __name__=='__main__':cutoff(612);cutoff(618)
