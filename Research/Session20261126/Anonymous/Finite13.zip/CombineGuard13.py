"""Exact bounds on number of distinct ordinary p-primes inside presumed low-budget anomaly. Does not purport to derive a lower bound on omega(A).
Assumes external r, source net price per certified CheapSource13; per A-prime generic 10^10, shallow R²/p². All prices on different primes.
"""
import math,sys
p=13;U=2771;B=10**2400

def thresholds(e,branches):
    A=(p**(e+1)-1)//12;P=p**e;R=1+2*(e+1)*65536*100000;wmax=0
    while R**(wmax+1)<=A:wmax+=1
    assert pow(A,3,p*p)!=1 and math.isqrt(A)**2!=A and pow(2,A-1,A)!=1
    D=[]
    for lo,hi,g in branches:
        mx=-1;states=[]
        for s in range(lo,hi+1):
            y=p**s;Q=2*y-1;w=-1
            for k in range(1,wmax+1):
                odd=max(1,2*k-wmax);H=A*R**odd
                mass=2*P*H*Q*Q>3*B
                val=p**(3*e)*Q*10**(10*(k-1))*R*R*10**g>B*p*p*U*y*y
                if not mass and not val:w=k
            mx=max(mx,w);states.append(w)
        print(e,lo,hi,'premium',g,'max A primes anywhere',mx,'at minimum s',states[0],'at maximum s',states[-1]);D.append((lo,hi,states))
    return D
if __name__=='__main__':thresholds(612,[(238,305,176),(306,456,224)]);thresholds(618,[(236,308,176),(309,450,226)])
