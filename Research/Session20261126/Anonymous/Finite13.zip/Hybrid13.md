## New mass lemma for Euler-one cofactor overlapping the source

Let p^e||N, Euler q^1||N, q∤A=σ(p^e), r^f||N an ordinary source r∤A, q|σ(r^f), Y=p^s with s=v_p(q+1)>0 and m=(q+1)/(2Y). Then

    N > p^e A m q²/3.

This is stronger by a factor growing with m than the naive E3a mass lemma, without any assumption about overlaps between m and r, A or other costs. First, A m|N: use two distinct terms of σ(N), removing all powers of 2 and p. Let u=r^{v_r(m)}, necessarily u|r^f because m|N; since r∤A, p^e A q (m/u) r^f divides N. If u=1, r^f>2q/3 suffices. If u>1, write σ(r^f)=qw, and reduce mod u. Since q=2mY−1 ≡−1 mod u, we have w≡−σ(r^{v_r(m)−1}) mod u. The latter geometric sum is (u−1)/(r−1)<u/2. Thus w>u/2 and r^f>(2/3)q w>q u/3. Combine. No source supply b needs to be subtracted anywhere. Even when A,m share prime factors their product divides N (the two divisibility inputs are distinct). Do not multiply this bound by the entire A-square premium without rechecking the input support for m.

HighSTail13.py uses this lemma to cap the integer prefix at each s, then verifies each remaining prime candidate q by source-order exclusion in the disjoint A-square budget. Once the first m exceeds the cap, all larger m are impossible monotonically. This verifies an all-m and all-b exterior-source subdomain without restricting r mod3 or r mod13. An additional premise q∤A and r∤A is essential.
