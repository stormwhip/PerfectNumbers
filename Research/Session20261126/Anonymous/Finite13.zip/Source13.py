"""Given q=2m13^s−1, exclude a true ordinary r∤A with q|σ(r^f), b=0 or not: exact residue classes, no primality assumed except q Euler conditional.
"""
import math,sys
from functools import cache
from pathlib import Path
here=Path(__file__).resolve().parent
if '--fast' in sys.argv:
    sys.path.insert(0,str(here/'vendor'));from flint import fmpz
    def power(a,g,n):return int(pow(fmpz(a),g,fmpz(n)))
else:power=pow
B=10**2400;ban=(19,7,11,31);p=13

def limit(e,s,q):
    # A nonsquare, q∤A so H≥A*R, R certified by LiftAnchor. r external, mass p^e H q r^f|<=N.
    R=1+2*(e+1)*65536*100000;A=(13**(e+1)-1)//12;assert math.isqrt(A)**2<A
    return B//(13**e*A*R*q)

def survey(e,s,m,full=False):
    y=13**s;q=2*m*y-1;C=limit(e,s,q)
    while C<1:return [],0
    seen={};left=[];groups=0
    for f in range(2,C.bit_length(),2):
        if 3**f>C:break
        d=math.gcd(f+1,q-1)
        if d==1:
            # r≡1 (mod q); q|σ(r^f) would force q|f+1. In this size regime q>f+1.
            assert f+1<q;continue
        if f+1>=q:raise ValueError('small Euler q not supported')
        if d not in seen:
            for a in range(2,100):
                g=power(a,(q-1)//d,q);x=g;xs=[1]
                while x!=1 and len(xs)<d:xs.append(x);x=x*g%q
                if x==1 and len(xs)==d:break
            else:raise AssertionError((e,s,m,d,'no generator'))
            seen[d]=xs[1:];groups+=1
        zs=seen[d];rmin=min(zs)
        if (rmin.bit_length()-1)*f>=C.bit_length() or rmin**f>C:continue
        # If a minimal representative survives, bound actual r in its residue stream. f>=2 implies r<=isqrt(C).
        for z in zs:
            if (z.bit_length()-1)*f>=C.bit_length() or z**f>C:continue
            u=z;cnt=0
            while u**f<=C and cnt<500:
                if u%2 and all(u%t for t in ban) and power(2,u-1,u)==1: left.append((f,d,z,u))
                u+=q;cnt+=1
            if u**f<=C:left.append((f,d,z,'continued'))
    if full:print(e,s,m,'orders',groups,'remaining',len(left),'examples',[(a,b,len(str(z)),len(str(u))) for a,b,z,u in left[:4]],flush=True)
    return left,groups
if __name__=='__main__':
    for e,s,m in ((612,306,225),(618,309,1153)):
        left,g=survey(e,s,m,True);assert not left
