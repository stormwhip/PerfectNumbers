"""Fast geometric progression implementation guarding actual emitter primes across unbounded Euler coefficients.
At most one exact cofactor check per candidate in this parameter range, but no cap is assumed. No FLINT/LP.
"""
import math,sys
from pathlib import Path
here=Path(__file__).resolve().parent;sys.path.insert(0,str(here));from SmallSource13 import primes
B=10**2400;badpr=(7,11,19,31)

def rootfloor(x,r):
    # greatest k>=0 with r^k<=x. Start from bit estimates then adjust by integer comparisons.
    k=max(0,(x.bit_length()-1)//r.bit_length());u=r**k
    while u*r<=x:k+=1;u*=r
    return k

def survey(e,s0,L):
    P=13**e;A=(13*P-1)//12;R=1+2*(e+1)*65536*100000;lim=B//(P*A);Y=13**s0;Q=2*Y-1;T=4*Y;inv=pow(Q,-1,T);rf_cap=lim//(R*Q)
    Tsmall=math.prod(badpr);ps=primes(L);tot=0;options=0;wc=0;heavy=0
    for r in ps:
        if r in (7,11,13,19,31):continue
        assert L<=R and 3**10>1
        # q<=3 r^f/2, r^f<=sqrt(2*lim*(r²+r+1)), when j=0.
        # The j>0 possibility is already killed by P A Q (2Q/3)^13>B.
        if r%13 in (3,9):
            c=r*r+r+1;b=1;c//=13
            while c%13==0:b+=1;c//=13
            pb=13**b
        else:pb=1
        floor=(2*Q)//3;cap=min(rf_cap,math.isqrt(lim*pb))
        # sigma(r^f)>r^f so r^(2f)<=lim*p^b; pb is upper bound on p^b since j=0.
        f0=max(2,rootfloor(floor,r));f0-=f0%2
        f1=rootfloor(cap,r);tot+=1
        if f0>f1:continue
        rr=r*r;rf=r**f0
        # update sigma(r^f) mod T via exact actual geometrical sigma when needed; divisions cached.
        for f in range(f0,f1+1,2):
            if (f+1)%13:
                n=(rf*r-1)//(r-1);z=n//(pb if (f+1)%3==0 else 1)
                if z>=Q and rf*z<=lim and math.gcd(z,Tsmall)==1:
                    options+=1;w=z*inv%T;assert w
                    if w*Q<=z:heavy+=1
                    while w*Q<=z:
                        wc+=1
                        if z%w==0:
                            q=z//w
                            assert q%4!=1 or pow(2,q-1,q)!=1,(e,r,f,q)
                        w+=T
            rf*=rr
    print(dict(e=e,s0=s0,limit=L,primes=tot,geometric_options=options,cofactor_at_least_one=heavy,cofactor_candidates=wc),flush=True)
if __name__=='__main__':
    e,s,L=map(int,sys.argv[1:]);assert __debug__ and 13**e*((13**(e+1)-1)//12)*(2*13**s-1)*(2*(2*13**s-1))**13>3**13*B;survey(e,s,L)
