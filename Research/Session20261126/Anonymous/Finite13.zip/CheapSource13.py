"""Exact inexpensive-source exclusion in E3a (r∤A,q∤A), using both 13-adic cubic lifts and the cofactor congruence.
If r^2/13^(2b)≤K² then r=x+k13^b, 0≤k<K. With T=13^min(s0,b), w=sigma(r²)/(13^b q)≡−z (mod T), z=z0+(2x+1)k+13^b k², linear mod T.
A Euclidean floor sum counts all admissible residues, including zero as a safe relaxation. No heuristic factorization, lattice or primality assumptions.
"""
from math import isqrt,gcd
B=10**2400;p=13;U=2771

def floor_sum(n,m,a,b):
    s=0
    while True:
        t,a=divmod(a,m);s+=n*(n-1)//2*t
        t,b=divmod(b,m);s+=n*t
        v=a*n+b
        if v<m:return s
        n,b=divmod(v,m);m,a=a,m

def below(n,a,b,mod,cap):
    if cap<0 or n<=0:return 0
    if cap>=mod-1:return n
    return n-(floor_sum(n,mod,a,b+mod-cap-1)-floor_sum(n,mod,a,b))

def survey(e,s0,digits,allow_res=False):
    K=10**digits;y=13**s0;Q=2*y-1;A=(13**(e+1)-1)//12;P=13**e;lim=B//(P*A);R=1+2*(e+1)*65536*100000
    assert isqrt(A)**2<A and 2*P*A*Q*(2*Q)**13>3**13*B # excludes 13|(f+1)
    assert 2*Q>3*K*K # b=0 cheaper than K² contradicts q|sigma
    # When f>=8 and b>0, ordinary price r^f/13^(2b)>=r^(f-2)/U >=(r^f)^(3/4)/U > (2q/3)^(3/4)/U.
    assert (2*Q)**3 >27*(U*K*K)**4
    # Thus cheap source positive b can only have f=2 (3|f+1) and r^2+r+1=13^b q w.
    roots=(3,9);m=1;rows=[];calls=0;potential=0;examples=[]
    for b in range(1,e-s0+1):
        m*=13;T=min(y,m)
        for x in roots:
            assert (x*x+x+1)%m==0 and x%13 in (3,9)
            # P*A*r²*(r²+r+1)/13^b <=B; also P*A*R*q*r²<=B.
            upper=min(K*m,isqrt(isqrt(lim*m)),isqrt(lim//(R*Q)));lower=max(3,isqrt(Q*m)-1)
            lo=max(0,(lower-x+m-1)//m);hi=(upper-x)//m
            if lo>hi:continue
            v=(x*x+x+1)//m;d=2*x+1;M=-(d%T);N=-(v%T)
            def getcnt(l,h):
                z=x+h*m;W=(z*z+z+1)//(m*Q)
                return below(h-l+1,M,N+l*M,T,W)
            count=getcnt(lo,hi);calls+=1;potential+=count
            if not count:continue
            # Recurse on interval to account for w upper varying with r. Avoid explosion: any unprocessed positive rectangle is retained.
            stack=[(lo,hi)];debt=0
            while stack:
                a,c=stack.pop();u=getcnt(a,c);calls+=1
                if not u:continue
                if len(examples)>=12 and allow_res:debt+=u;continue
                if a==c:
                    r=x+a*m;z=(r*r+r+1)//m;w=(-z)%T or T
                    # r prime condition can only strengthen rejection. If a genuine positive solution remains record and do not certify.
                    if r%2==0 or z%13==0 or any(r%v==0 or z%v==0 for v in (7,11,19,31)):continue
                    if pow(2,r-1,r)!=1:continue
                    while w*Q<=z:
                        if z%w==0:
                            q=z//w
                            if q%4==1 and q%y==y-1 and pow(2,q-1,q)==1: examples.append((b,a,r,q));debt+=1;break
                        w+=T
                    continue
                mid=(a+c)//2;stack.extend(((a,mid),(mid+1,c)))
            if debt:rows.append((b,x%13,debt))
        roots=tuple(pow(x,13,13*m) for x in roots)
    print(dict(e=e,s_min=s0,K_power=digits,cubic_rectangles_with_rows=rows,initial_hits=potential,checks=calls,witness_count=len(examples)),flush=True)
    if not allow_res:assert not rows and not examples
if __name__=='__main__':
    import sys
    survey(*map(int,sys.argv[1:4]))
