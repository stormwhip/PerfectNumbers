"""Unconditional exclusion of all A prime divisors at deep 13-adic cubic level (c=1), independently of N.
Contains two targets (13,612),(13,618). Whole global Coppersmith witness, no probabilistic primality or factorization.
"""
from math import gcd,isqrt,log
import sys,gzip,json
from pathlib import Path
here=Path(__file__).resolve().parent;repo=Path(sys.argv[1]);sys.path.insert(0,str(repo/'Research/NightMerge'));import LatticeLeaf as L
sys.set_int_max_str_digits(60000)

def check(e,gen):
    if gen:
        sys.path.insert(0,str(here/'vendor'));from flint import fmpz_mat,fmpz_poly
    p=13;n=e+1;C=(13**n-1)//12;h=200;Y=p**h;T=2*n*Y;assert gcd(C,T)==1
    for a in (3,9):
        x=pow(a,p**(h-1),Y);assert x%13==a and pow(x,3,Y)==1;z=x+Y*((1-x)*pow(Y,-1,2*n)%(2*n));lo=z;hi=C//(C*pow(z,-1,T)%T);name=here/f'Single13-{e}-{a}.json.gz';rows=[] if gen else json.loads(gzip.decompress(name.read_bytes()));i=0
        while lo<=hi:
            end=min(lo*10**7,hi)
            if not gen:
                l,r,w=rows[i];assert (l,r)==(lo,end) and L.verify(C,1,z,T,l,r,w)
            else:
                beta=log(lo)/log(C);hit=None
                for d in (4,5,6,7,8,9,10,12,14,16):
                    for m in sorted({max(1,min(d-1,round(beta*d)+j)) for j in (0,1,-1,2)},key=lambda j:abs(j-beta*d)):
                        first,rad,mid,cent,K,bb=L.build(C,1,z,T,lo,end,d,m)
                        if rad<0:hit=[2,1,[0,0],[]];break
                        ww=[K**j for j in range(d)];mat=fmpz_mat([[v*w for v,w in zip(rr,ww)] for rr in bb]);red,trans=mat.lll(transform=True)
                        for k in range(d):
                            if sum(abs(int(red[k,j])) for j in range(d))>=first**m:continue
                            pol=fmpz_poly([int(red[k,j])//ww[j] for j in range(d)]);ll=[]
                            for g,b in pol.factor()[1]:
                                if g.degree()==1:
                                    i0,d0=int(-g[0]),int(g[1]);ll.extend([[i0 if d0>0 else -i0,abs(d0)]]*b)
                            w=[d,m,[int(trans[k,j]) for j in range(d)],ll]
                            if L.verify(C,1,z,T,lo,end,w):hit=w;break
                        if hit:break
                    if hit:break
                assert hit,(e,a,i);rows.append((lo,end,hit))
            i+=1;lo=end+1
        assert i==len(rows)
        if gen:name.write_bytes(gzip.compress(json.dumps(rows,separators=(',',':')).encode(),mtime=0))
        print(e,'depth',h,'class',a,'witnesses',i,flush=True)
if __name__=='__main__':
    assert __debug__
    for e in (612,618):check(e,sys.argv[2]=='gen')
