"""Exhaust high-degree portions directly: finitely many prime r and cofactor APs at fixed s lower modulus. Independent of m.
For each included row use first primal / binary segmented sieve, exact z modulo T cofactor bound; no trial beyond finite interval.
"""
import math,sys
from pathlib import Path
here=Path(__file__).resolve().parent;sys.path.insert(0,str(here));from OrderTight13 import domains,phi_eval
from SmallSource13 import primes
B=10**2400

def check(e,s,f0):
    rows=domains(e,s,2000001);mx=max(hi for f,d,lo,hi,b in rows if f>=f0)
    y=13**s;Q=2*y-1;T=4*y;inv=pow(Q,-1,T);counts=[]
    pre=primes(math.isqrt(mx)+1); # cross-check primal sieve: ordinary r>2e6, all sieve factors below that threshold
    assert pre[-1]<2000001
    for f,d,lo,hi,b in rows:
        if f<f0:continue
        tested=0;accepted=0
        # phi_d(r) divisible by q; cofactor therefore bounded by phi_d(r)/Q independently of other sigma factors.
        for a in range(lo,hi+1,100000):
            n=min(100000,hi-a+1);bts=bytearray(b'\1')*n;bts[(-a)%2::2]=bytes((n-1-(-a)%2)//2+1)
            for p in pre:
                i=-a%p
                if i<n:bts[i::p]=bytes((n-1-i)//p+1)
            for i,h in enumerate(bts):
                if not h:continue
                r=a+i;assert d==f+1;tested+=1
                # ord_q=r's order d. If q=1 (mod d), q=Q mod 4Y, combine by CRT to T*d.
                D=T*d;z0=Q+T*((1-Q)*pow(T,-1,d)%d);S=phi_eval(r,d)
                if S<Q or any((r**(f+1)-1)%(t*(r-1))==0 for t in (19,7,11,31)):continue
                if S%13==0: # strip p part to sharpen cofactor AP (non-cubic cases cannot contain any)
                    while S%13==0:S//=13
                w=S*pow(z0,-1,D)%D
                while w*Q<=S:
                    accepted+=1
                    if S%w==0:
                        q=S//w;assert pow(2,q-1,q)!=1,(r,f,q)
                    w+=D
            phi_eval.cache_clear()
        counts.append((f,tested,accepted));print(e,f,tested,accepted,flush=True)
    print('complete',e,s,f0,sum(a for f,a,b in counts),sum(b for f,a,b in counts),flush=True)
if __name__=='__main__':check(*map(int,sys.argv[1:4]))
