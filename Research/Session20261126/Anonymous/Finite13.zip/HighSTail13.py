"""All-m high-s exclusion using Euler-one σ(q)/2 cofactor times source r^f, plus low-prefix exact-order enumeration.
Switch m0 chosen per s from mass inequality 13^e A m q²>3B. Only surviving conditional primes under m0 need full order checks.
"""
from pathlib import Path
import sys,math
here=Path(__file__).resolve().parent;sys.path.insert(0,str(here));from Prefix13 import tighter,power,ban
B=10**2400

def run(e,s0,maxprefix):
    A=(13**(e+1)-1)//12;P=13**e;candidates=0;groups=0;total=0;raw=None
    small=[q for q in range(3,30000,2) if all(q%t for t in range(2,math.isqrt(q)+1))]
    for s in range(s0,e+1):
        y=13**s
        def reject(m):return P*A*m*(2*m*y-1)**2>3*B
        if reject(1):raw=s if raw is None else raw;continue
        assert reject(maxprefix+1),(e,s,'prefix too short');lo=0;hi=maxprefix+1
        while lo+1<hi:
            k=(lo+hi)//2
            if reject(k):hi=k
            else:lo=k
        l=lo
        total+=l;ss=bytearray(b'\1')*(l+1);ss[::2]=bytes(l//2+1)
        for p in (*ban,13):ss[::p]=bytes(l//p+1)
        for p in small:
            if p==13:continue
            i=pow(2*y,-1,p)
            if i<=l:ss[i::p]=bytes((l-i)//p+1)
        for m in range(1,l+1,2):
            if not ss[m]:continue
            q=2*m*y-1
            if power(2,q-1,q)!=1:continue
            good,g=tighter(e,s,m);assert good,(e,s,m);groups+=g;candidates+=1
        print(s,l,candidates,flush=True)
    print(dict(e=e,external_source_s_min=s0,raw_smin=raw,m_prefix=total,conditional_primes=candidates,orders=groups),flush=True)
if __name__=='__main__':run(*map(int,sys.argv[1:4]))
