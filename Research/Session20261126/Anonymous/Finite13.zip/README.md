# Explicit remaining external-source cells, (13,612) and (13,618)

**Summary as of verification: no complete exponent.** This packet studies q^1 Euler, q∤A, s=v13(q+1)>0 and an ordinary source r∤A with q|σ(r^f). The 31-row finite domain applies only to r∤A. A supplementary theorem for r|A is in `InternalNet.md`: the same 176/224/226-digit actual-source premiums hold, and s≥537 is ruled out for both e by the balanced-gap and Euler prefix. Altogether q^1 exterior cannot have s≥537 regardless of the emitter. No entire exponent is claimed. B=10^2400. Given the anonymous-block proof of A's roughness and U=2771, the remaining large-s region has the exact r ranges in `SurvivingRegions.json`, with only 31 f values, and true multiplicative order ord_q(r)=f+1 in every row. There are 31 remaining rows for e=612,s=238..456, and 31 for e=618,s=236..450. Above these s bands all m and b have been ruled out by combining the new cofactor-mass bound with a finite Euler prefix; below these s bands no claim of the 31-row reduction. Within a band, r>2,000,000, f≤68 even, f not one of 12,38,64. The nonabsorbing subgroup (r≡2 mod3, r≠1 mod13) is completely impossible already at s≥310 and s≥302 respectively. The cheaper conditions in `ThirteenBounds.md` are intermediate results. Source-price premium exceeds 10^176 on each full band, rising to 10^224 and 10^226 in and above the respective half-supply bands. See `NetPrice.md` and `Hybrid13.md`.

All verifiers are standard library; optional `--fast` on Euler prefix commands uses python-flint==0.9.0 only for exact modular exponentiation. Without --fast it is slower, but no mathematical behavior changes. The internal-source supplement uses archived `NightMerge/LatticeLeaf.py`; the external-source proof's only other import is optional Teich `U` profile audit for `Inflow13.py`; R values are proved by the separate Anonymous/LiftAnchor.py. The reported finite regions are a necessary domain, not a list of primes or known witnesses. Source13 excludes the two previously reported genuine-prime *scalar* obstructions as actual Euler candidates. Distinct-prime accumulation from positive suppliers used in Inflow13 is not charged a second time into any separate auxiliary volume. Details and exact counts are in the two notes.

Replay from inside this directory; REPO indicates fixed original repository only for reproducing the U tables:

```
python -I -S -B Source13.py
python -I -S -B Sweep13.py 612 238 2000000
python -I -S -B Sweep13.py 618 236 2000000
python -I -S -B OrderTight13.py --details
python -I -S -B LargeDegree13.py 612 238 70
python -I -S -B LargeDegree13.py 618 236 70
python -I -S -B Prefix13.py 612 307 322 10001 --fast
python -I -S -B Prefix13.py 618 305 320 10001 --fast
python -I -S -B Inflow13.py REPO
python -I -S -B TailInflow13.py 612 310 0 2000000 --fast
python -I -S -B TailInflow13.py 618 302 0 2000000 --fast
python -I -S -B HighSTail13.py 612 457 2000000 --fast
python -I -S -B HighSTail13.py 618 451 2000000 --fast
python -I -S -B CheapSource13.py 612 238 88
python -I -S -B CheapSource13.py 618 236 88
python -I -S -B CheapSource13.py 612 306 112
python -I -S -B CheapSource13.py 618 309 113
python -I -S -B FinalRanges.py
python -I -S -B DeepSingle13.py REPO verify
python -I -S -B DenseSource13.py 612 238 88 --single
python -I -S -B DenseSource13.py 618 236 88 --single
python -I -S -B DenseSource13.py 612 306 112 --single
python -I -S -B DenseSource13.py 618 309 113 --single
python -I -S -B InternalPrefix13.py 612 537 30000 --fast
python -I -S -B InternalPrefix13.py 618 537 30000 --fast
```

No scheduled operations, repository edits, or pure-heuristic cells promoted to full coverage. Exact unit-price bounds are usable only when their receiving prime r has not already had its entire ratio credited in the same valuation ledger.
