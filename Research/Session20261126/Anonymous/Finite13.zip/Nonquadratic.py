"""Conditional q|sigma(r^f), q exterior Euler q≡−1 mod13^s (s sufficiently high); r inside OR outside A, f>=4.
A stronger source net price >=q^1/U up to a small constant, independent of r's relation to A.
"""
import math
B=10**2400;U=2771

def check(e,s):
    Q=2*13**s-1;assert 13**e*Q*(2*Q)**13>3**13*B # j>0 impossible
    # r>2e6 for external via mass sieve; internally from roughness. Yet log-bound below uses r>=3, and d<=f+1,
    # uniform Phi_d(r) < 3r^phi(d) for any r>=3 from product over Mu(d/k): product(1-r^-k)^(-1) <= 1/(1-sum r^-k) <=2.
    # Since 1/(1-sum_{k>=1}3^-k)=2, and all finite products strictly better, 2 suffices.
    assert 2*(13**s)>U
    print('nonquadratic price > Q/(2U)',e,s,'decimal floor',len(str(Q//(2*U)))-1)
if __name__=='__main__':
    for vals in [(612,238),(618,236),(612,306),(618,309)]:check(*vals)
