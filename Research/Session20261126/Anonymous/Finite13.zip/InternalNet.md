# The same emitter net prices hold even if r|A

Original scope external Euler q^1||N with q∤A, p=13. Now allow its ordinary source r to belong to A. For both roots a first-power lattice certificate excludes every prime r|A of order three mod13 with λ=v13(r³−1)≥200. Mod 13^200, r is one of the two Teichmüller lifts of 3,9. Combine each with r≡1 mod 2(e+1) by CRT into class z mod T. The cofactor A/r lies in class A/z mod T. Thus [z,A/(A/z mod T)] covers every candidate; exact consecutive lattice boxes use the archived LatticeLeaf.verify(C,1,...). There are 33+34 boxes for e612 and 34+35 for e618, 136 in total. Cold verification is standard library; optional generation alone uses python-flint. This stronger *first-power* exclusion at λ=200 should not be confused with the earlier square certificate at λ=124/125 (which is still useful at intermediate levels).

For s≥238 (612) or 236 (618), an argument as in NetPrice: if 13|(f+1), then q|σ(r^((f+1)/13−1)) implies 13^e q r^f>10^2400 WITHOUT A, by the integer threshold. Exclude b=0 and f≥8 price exceptions the same way as for external r via r^f>2q/3 and the blanket one-prime Teich deficit bound. Therefore the only possible counterexample to the value r^f/13^(2b)>K² is f=2 and b=λ>0. By the first-power proof b≤199. In each class x mod m=13^b, parameterize r=x+m k, additionally k=k0+2(e+1)i from the cyclotomic order. The cofactor w=(r²+r+1)/(m q) is linear in i modulo min(m,13^s0), with the same exact floor-sum count as for external emitters. Internally, use 13^e A (r²+r+1)/m≤B, because A·σ(r²) is an input product after stripping 13; no additional r^f free unless proven. When b≥124 or 125, prior r²∤A certificate gives one further r in this product. Always r² q 13^e≤B, and r≤A/[A z^{-1} mod (2(e+1)m)]. At the four threshold rows below, each initial constrained rectangle has zero points, no primality assumption needed. The same four actual-source prices now hold regardless of r's relation to A, but when reusing them one may not also charge a generic/shallow A prime fee for the SAME r.

|e|s≥|K exponent|proved net >|initial rectangles|nonempty|
|---:|---:|---:|---:|---:|---:|
|612|238|88|10^176|238|0|
|618|236|88|10^176|242|0|
|612|306|112|10^224|188|0|
|618|309|113|10^226|186|0|

Replay `DeepSingle13.py REPO verify`; replay earlier AnonymousGuard.py REPO verify for c=2 λ=124/125. Then `DenseSource13.py e s0 digits --single` at each row. `--single` uses already-verified first-power result to omit b≥200; do not skip DeepSingle. For v13(f+1)>0 source reduction one need not assume r|A or not: the claim is 2^13·13^e·Q^14>3^13 B, proven by the verifier. See also CofactorDepth13.py/InternalPrefix13.py for high-u cases, a different argument independent of these net prices.
