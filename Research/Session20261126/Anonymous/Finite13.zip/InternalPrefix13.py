"""All internal-source (r|A) high-s guard with exact certified k-order limit. q Euler exterior. Integral exact range until balanced gap surpasses B.
"""
from pathlib import Path
import sys,math
here=Path(__file__).resolve().parent;sys.path.insert(0,str(here));from CofactorDepth13 import raw;from Source13 import power
p=13;B=10**2400

def run(e,s0,cap):
    A=(p**(e+1)-1)//12;P=p**e;R=1+2*(e+1)*65536*100000
    # r|A, r>R, hence f<200 by budget. Nontrivial mod q residues since q≫f.
    assert R**200>B
    small=[q for q in range(3,30000,2) if all(q%i for i in range(2,math.isqrt(q)+1))];total=0;n=0;g=0
    for s in range(s0,e+1):
        y=p**s
        if raw(e,s,2*y-1)>B:continue
        a,h=0,cap+1;assert raw(e,s,2*h*y-1)>B,(e,s,cap)
        while a+1<h:
            j=(a+h)//2
            if raw(e,s,2*j*y-1)>B:h=j
            else:a=j
        l=a;total+=l;bs=bytearray(b'\1')*(l+1);bs[::2]=bytes(l//2+1)
        for t in (7,11,13,19,31):bs[::t]=bytes(l//t+1)
        for t in small:
            if t==13:continue
            k=pow(2*y,-1,t)
            if k<=l:bs[k::t]=bytes((l-k)//t+1)
        for m in range(1,l+1,2):
            if not bs[m]:continue
            q=2*m*y-1
            if power(2,q-1,q)!=1:continue
            # r>=q => q²>A, so c=1 and t>=r, giving P A q² >B at s ranges considered.
            assert q*q>A and P*A*q*q>B
            seen={1}
            for f in range(2,200,2):
                d=math.gcd(q-1,f+1)
                if d in seen:continue
                for x in range(2,80):
                    w=power(x,(q-1)//d,q);u=w;saw=[1];pr=1
                    while u!=1 and len(saw)<d:saw.append(u);pr=pr*u%A;u=u*w%q
                    if u==1 and len(saw)==d:break
                else:raise AssertionError((s,m,d))
                assert math.gcd(pr,A)==1;g+=1;seen.add(d)
            n+=1
        print(s,l,n,flush=True)
    print(dict(e=e,min_s=s0,m_prefix=total,conditional_q=n,groups=g),flush=True)
if __name__=='__main__':run(*map(int,sys.argv[1:4]))
