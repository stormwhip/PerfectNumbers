"""Pure descendant closure of no-five supports, without LP. Existing forest is hints only. Freeze selected prime labels and certify all."""
from searchforest import *
from copy import deepcopy
repo=D.parent.parent/'sprint/Research/P3I00193Review/Candidate/P3E1162Complete.json'
leaves=json.loads(repo.read_bytes())['cell10'];dest=D/'nforests';dest.mkdir(exist_ok=True)
# nofive uses d=0 and S=1, authoritative cap on all s here, not old 990 numerical values
(D/'fac5/0.json').write_text('{"factors":[]}')
@cache
def localbase(m):return run_fast(0,m)[0]
def train(i,m,niter=90):
 l=leaves[i];absent={5}|set(l['absent_extra']);rt=l['present'];p=dest/f'{i}-{m}.json';ow={};f=l['forest'] or {};seen=set(rt);stack=rt[:];assert all(cert(t) for t in rt)
 while stack:
  t=stack.pop()
  for z in f.get('edges',{}).get(str(t),[]):
   if z in seen or z in absent or A%z==0 or z>=2*3**789-1 or not m and not ak(z) or not cert(z):continue
   seen.add(z);ow[z]=t;stack.append(z)
 if p.exists():q=json.loads(p.read_bytes());ow=dict(q['ow']);old=q['v']
 else:old=0
 done=set()
 for depth in range(niter):
  z,tr=evalforest(0,m,ow,rt,True,absent=absent,nofive=True,goal=900);v=z+localbase(m)
  if v>old:old=v;p.write_text(json.dumps(dict(i=i,m=m,ow=sorted(ow.items()),v=v),separators=(',',':')))
  if v>2400*hi(10) or not tr:break
  new={}
  for t,h in tr:
   if (t,h) in done:continue
   done.add((t,h))
   for z in bank.factors(t,h):
    if z in rt or z in ow or z in BAN or z in absent or z==3 or A%z==0 or z>=2*3**789-1 or not m and not ak(z) or not cert(z):continue
    new.setdefault(z,t)
  if not new:break
  ow.update(new)
 print(i,m,old//hi(10),len(ow),'depth',depth,flush=True)
if __name__=='__main__':
 for i in map(int,sys.argv[2:]):train(i,int(sys.argv[1]))
