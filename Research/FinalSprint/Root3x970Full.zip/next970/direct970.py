"""One-shot switch to stronger known net LP over the same leaf, including an exact partition-by-atom for external r and rigorous integer dual. Search files kept in own sandbox copied from frozen bundle."""
import sys,json,shutil
from pathlib import Path
D=Path(__file__).resolve().parent;dest=D/'model/Next/Lower';dest.parent.parent.mkdir(parents=True,exist_ok=True)
if not dest.exists():shutil.copytree(D.parent/'Partial',dest.parent.parent,dirs_exist_ok=True)
sys.path[:0]=[str(dest),str(dest.parent)];import CoherentRobust as cr,ThirdRobust as third,Gen3 as gen
from Screen import *
# Optimize with validated model + forest-active early prominent primes; EC chains checked same mechanism.
mode=int(sys.argv[2]);i=int(sys.argv[3]);assert mode in (2,3);setup(970)
print(json.dumps((cr if mode==2 else third).calc(i,970,545,True)),flush=True)
