"""Run 970 support predicates individually with exact rational/nonnegative comparison; track all missing cells and disallow accidental full credit."""
from pathlib import Path
import sys,json
sys.path.insert(0,str(Path(__file__).resolve().parent));from forest5 import *
repo=Path(sys.argv[1]).resolve();ls=json.loads((repo/'Research/P3I00193Review/Candidate/P3E1162Complete.json').read_bytes())['cell10'];valid=[]
for ii in range(0,len(sys.argv[2:]),2):
 i=int(sys.argv[2+ii]);m=int(sys.argv[3+ii]);r=json.loads((D/f'nforests/{i}-{m}.json').read_bytes());assert (r['i'],r['m'])==(i,m);ow=dict(r['ow']);assert len(ow)==len(r['ow']);z,_=evalforest(0,m,ow,ls[i]['present'],absent=ls[i]['absent_extra'],nofive=True,goal=900);v=run_fast(0,m)[0]+z
 assert v>2400*hi(10),(i,m,v);print('cell',i,m,v,flush=True);valid.append((i,m))
print('verified',valid)
