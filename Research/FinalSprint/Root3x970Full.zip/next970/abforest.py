"""Nonnegative abundance-adjusted surplus in the forced ordinary forest. Minimize by exact-exponent DP and directed log bounds. Optional no-five conditional support tester is standalone."""
from forest5 import *
@cache
def discount1(t,lam,absent):
 if t in absent or t in BAN or t in (2,3,5):return 0
 mx=0;u=hi(t)-lo(t-1)
 for h in range(2,8000,2):
  if h*lo(t)-12*hi(43)-lam*u>=0:break
  if any(pow(t,h+1,(t-1)*p)==1 for p in absent):continue
  # nofive, so omit 5-supply tariff entirely. In base d=0 no five supply revenue.
  k=val(h+1,3) if t%3==1 else 0
  mx=max(mx,lam*u-h*lo(t)+2*k*hi(43))
 return mx
@cache
def sfor(lam,absent):
 # Explicitly bound every discount prime; t>=10000 has n/h>=ln(10000/43), ab<= 1/9999. Uses tiny additive exception budget 1/1000 for combined A,q,source contributions (no need to test candidates past 2000).
 assert lam<=30000 and (2*(lo(10000)-hi(43)))>lam*101
 assert all(ak(p) for p in range(5,2000,2) if prime64(p) and p not in absent and p not in BAN)
 return sum(discount1(t,lam,absent) for t in range(5,10000,2) if prime64(t))

def evalab(m,ow,rt,absent,lam):
 absent=tuple(sorted(set(absent)|set(BAN)|{5}));pool=set(rt)|set(ow);assert not pool.intersection(absent);assert len(rt)==len(set(rt)) and not set(rt).intersection(ow);ch=defaultdict(list);g=prod(pool)*A;seen=set()
 for t,p in ow.items():ch[p].append(t)
 stack=list(rt)
 while stack:
  t=stack.pop();assert t not in seen;seen.add(t);stack.extend(ch[t])
 assert seen==pool and all(prime(p) and A%p and p<2*3**789-1 and (m or ak(p)) for p in pool)
 @cache
 def node(p,k):
  best=900*hi(10);trace=[];ab=hi(p)-lo(p-1);disc=discount1(p,lam,absent)
  for h in range(max(2,k+k%2),8000,2):
   if h*lo(p)-12*hi(43)-lam*ab+disc>=best:break
   if any(pow(p,h+1,t*(p-1))==1 for t in absent):continue
   S=sig(p,h);v3=val(S,3);z=max(0,h*lo(p)-2*v3*hi(43)-lam*ab+disc)
   if z>=best:continue
   x=S//3**v3
   while (y:=gcd(x,g))>1:x//=y
   ss,left=split(x)
   for t,v in ss:
    if not m and not ak(t):continue
    # h>=2 so net/h adjusted by at most lambda ab/2 (ignore positive discount).
    c=max(0,lo(t)-(hi(43) if t%3==1 else 0)-((lam*(hi(t)-lo(t-1))+1)//2));z+=v*c
   if m and 1<left<2*3**789-1:z+=lo(left)*max(0,lo(1000)-hi(43)-(lam*1003+1)//2)//lo(1000)
   kids=[]
   if z<best:
    for t in ch[p]:
     if not S%t:
      c,tk=node(t,val(S,t));z+=c;kids+=tk
      if z>=best:break
    if z<best:best=z;trace=[(p,h)]+kids
  return best,trace
 C=lam*(lo(4)-hi(3)-1000)-sfor(lam,absent);trace=[]
 for t in rt:
  z,tr=node(t,1);C+=z;trace+=tr
 return C,trace
if __name__=='__main__':
 import json,sys
 repo=Path(sys.argv[1]);ls=json.loads((repo/'Research/P3I00193Review/Candidate/P3E1162Complete.json').read_bytes())['cell10'];m=0
 for i in map(int,sys.argv[2:]):
  f=D/f'nforests/{i}-{m}.json';r=json.loads(f.read_bytes());l=ls[i]
  for lam in (0,1000,2500,5000,10000,20000):
   z,tr=evalab(m,dict(r['ow']),l['present'],l['absent_extra'],lam);print(i,lam,(run_fast(0,m)[0]+z)//hi(10),flush=True)
