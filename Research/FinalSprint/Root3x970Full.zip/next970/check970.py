"""Full (3,970) singleton proof. Unpack beside 990 proof for inherited ../Partial. All children checked, no receipt is used to accept any leaf."""
import sys,os,subprocess,tempfile
from pathlib import Path
D=Path(__file__).resolve().parent;repo=Path(sys.argv[1]).resolve();assert __debug__
def run(*args):subprocess.run(list(args),cwd=D,check=True)
def py(path,*args):run(sys.executable,'-I','-S','-B',path,*map(str,args))
with tempfile.TemporaryDirectory() as t:
 exe=str(Path(t)/('trial970.exe' if os.name=='nt' else 'trial970'));run(os.environ.get('CXX','g++'),'-std=c++17','-O3','../Partial/Base/Trial970.cpp','-o',exe);run(exe)
py('trans.py',repo);py('cold970.py');py('cover970.py',repo,0,1,1,1,0,0,1,0,2,0,3,0,5,0,6,0);py('abcheck.py',repo);py('model/Next/Lower/StrictInterval.py',repo,970,2,545,4,8,9)
print('PASS: all 42+42 E3a/E3b supports and E0/E1/E2, exact (3,970), P3_I00165.')
