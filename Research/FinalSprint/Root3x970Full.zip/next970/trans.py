"""Minimal common LP transfer. Typical role e970 internal rows 2..11, external 10,11. No decimal floor threshold ambiguity."""
from pathlib import Path
import sys,subprocess,json
D=Path(__file__).resolve().parent;repo=Path(sys.argv[1]).resolve();p=D.parent/'Partial';u=p/'Next/Lower'
# These scripts intentionally read only from repository; the new scenario invokes an in-memory sink for the old E0/E1/E2 wrapper.
sys.path[:0]=[str(p),str(p/'Next'),str(u)];import Prelude990,PrimitiveAudit,Hull,Base
PrimitiveAudit.main();Prelude990.cover();assert Hull.setup(970)==789
import importlib.util
spec=importlib.util.spec_from_file_location('frozenpartial',repo/'Research/P3I00193Review/VerifyPartial.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
class Sink:
 def __truediv__(self,s):assert s=='PartialResults.json';return self
 def write_text(self,s,encoding):self.val=json.loads(s)
sink=Sink();m.HERE=sink;m.EXPONENTS=(970,);m.run();assert sink.val['rows'][0]['e']==970
sp=importlib.util.spec_from_file_location('ext',p/'Base/External.py');ext=importlib.util.module_from_spec(sp);sp.loader.exec_module(ext);ext.run(970,1855)
Base.check_range(970,10**11);z,_=Base.envelope(970,10**11);assert z[1]==4174321231820
# Recheck two-generation direct LP leaves; only below combinations are accepted.
for role,goal,keys in [('int',586,range(2,12)),('ext',544,(10,11))]:subprocess.run([sys.executable,'-I','-S','-B',str(u/'StrictDirect.py'),str(repo),'970',role,str(goal),*map(str,keys)],check=True)
print('PASS 970 underlying Euler prelude, lower bases, 10/12 inside and 2/12 outside no-five leaves.')
