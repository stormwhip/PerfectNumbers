"""External no-five cell 7, re-priced forced forest. Offline proof only. No score or digit from prior run used."""
from pathlib import Path
import sys,json
sys.path.insert(0,str(Path(__file__).resolve().parent));from abforest import *
assert __debug__;repo=Path(sys.argv[1]).resolve();l=json.loads((repo/'Research/P3I00193Review/Candidate/P3E1162Complete.json').read_bytes())['cell10'][7];v=json.loads((D/'nforests/7-0.json').read_bytes());assert v['i']==7 and v['m']==0 and l['present']==[23];ow=dict(v['ow']);assert len(ow)==len(v['ow']);assert R**40>A
from fractions import Fraction
assert Fraction(40,R-1)+Fraction(1,1999)+Fraction(1,2*3**789-2)<Fraction(1,1000)
z,_=evalab(0,ow,l['present'],l['absent_extra'],1000);lb=z+run_fast(0,0)[0];print('external cell7',lb,2400*hi(10));assert lb>2400*hi(10)
