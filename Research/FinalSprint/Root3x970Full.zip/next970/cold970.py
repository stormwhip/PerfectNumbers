"""Root970 all 5-present E3 branches. Zero network, zero solver. No independent proof of absence of 5 here."""
import sys,math,json
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent));from forest5 import *
assert __debug__;assert R==1+2*971*32768*140000 and math.isqrt(A)**2!=A and E==970
assert nosource(5) and A%5 and gcd(A,5*3)==1
def tail(d0,m):
 # Actual d>=d0: allocate only d0 of total five units, Euler u0=min(u,d0). Monotone q_0 and five-power inequalities; 5 emits no 3 and no 5. Discard ALL of its children; verify 5 is not r by nosource, 5 ∤ A.
 import fast
 old=fast.row;fast.row=lambda d,m,a,b:d*lo(5)
 try:return fast.run_fast(d0,m)[0]
 finally:fast.row=old
for m in (0,1):
 z=tail(412,m);print('tail',m,z,'>',2400*hi(10),flush=True);assert z>2400*hi(10)
 ds=[d for d in range(2,412,2) if good(5,d)];zs=[]
 for d in ds:
  S=pow_sum(5,d);assert gcd(S,3*5*A)==1 and S<2*3**789-1
  lb,_=run_fast(d,m);kind='child'
  if lb<=2400*hi(10):
   r=json.loads((D/f'forests/{d}-{m}.json').read_bytes());rt=r['roots'];owners=dict(r['owners']);assert (d,m)==(r['d'],r['m']) and len(set(rt))==len(rt) and len(owners)==len(r['owners']);assert all(S%p==0 for p in rt);z,_=evalforest(d,m,owners,rt);lb=base(d,m)+z;kind='forest'
  assert lb>2400*hi(10),(m,d,lb);zs.append((lb,d));print(m,d,kind,lb,flush=True)
 print('five-present complete',m,len(zs),min(zs),flush=True)
