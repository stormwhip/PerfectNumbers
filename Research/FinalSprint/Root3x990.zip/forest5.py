"""Explicit necessary child trees for an exact five exponent. Stdlib cold replay. All size/supplier units use micro-nats."""
from fast import *
from functools import lru_cache
# Micro-nat enclosures are intentionally one-sided. A theoretically zero net at
# t=43 or t=41 might be numerically negative owing to rounding; clipping at
# zero is valid here ONLY because prices (43,41) cannot overprice any supplier.
# Below 43, the only eligible t=1 mod3 is 37; Phi_3(37) has banned 7.
# All positive 5-suppliers are >=41 by canonical bans. Hence h ln t >=
# 2v3 ln43 + 4v5 ln41, since 3^v3*5^v5 divides h+1, h>=2v3+4v5.
from math import prod,gcd
from collections import defaultdict
@cache
def sig(t,h):return pow_sum(t,h)
@cache
def good(t,h):return all(pow(t,h+1,(t-1)*p)!=1 for p in BAN)
@cache
def net(t,h,a,b):return h*lo(t)-(2*hi(a)*val(h+1,3) if t%3==1 else 0)-(4*hi(b)*val(h+1,5) if t%5==1 else 0)
small=[p for p in range(5,1000,2) if prime64(p)]
@lru_cache(50000)
def split(n):
 a=[]
 for p in small:
  if not n%p:
   k=val(n,p);a.append((p,k));n//=p**k
 return a,n
@cache
def ak(p):return nosource(p) if p<2*3**813-1 and A%p else False

def evalforest(d,mode,owners,roots,scout=False,a=43,b=41,goal=560,absent=(),fixed=()):
 assert (a,b)==(43,41) and all(not good(r,2) for r in small if r not in BAN and r<43 and r%3==1) and all(r%5!=1 for r in small if r not in BAN and r<41)
 S=sig(5,d);pool=set(roots)|set(owners)|{5};ch=defaultdict(list);fixed=dict(fixed);absent=set(absent)|set(BAN);g=prod(pool);assert not(pool&absent);assert not(set(roots)&set(owners));assert not set(fixed)-pool
 for t,r in owners.items():assert r in pool and r!=5;ch[r].append(t)
 seen=set();stack=list(roots)
 while stack:
  p=stack.pop();assert p not in seen;seen.add(p);stack.extend(ch[p]);
 assert seen==pool-{5};assert all(A%p and p!=3 and p<2*3**813-1 and (mode or ak(p)) for p in pool)
 if not scout:assert all(prime(p) for p in pool)
 @cache
 def node(p,k):
  ls=range(max(2,k+k%2),8000,2) if p not in fixed else [fixed[p]];best=goal*hi(10)+1000;choice=None
  for h in ls:
   if h<k or h%2:continue
   # Tail bound from k3<=6,k5<=4 independent of h. When raw>=best, all later h are also harmless.
   z=h*lo(p)-12*hi(a)-16*hi(b)
   if z>=best:break
   if not good(p,h):continue
   n=sig(p,h)
   if any(not n%b0 for b0 in absent):continue
   z=max(0,net(p,h,a,b))
   if z>=best:continue
   ns=n//3**val(n,3); # multiplicities from other rows accumulate in outside pool
   x=ns
   while (u:=gcd(x,g*A))>1:x//=u
   ss,left=split(x);price=0
   # Incoming net paid proportionally to log(p) - max(ln(a),ln(b)), all h>=2k3+4k5. For p never supplying either use full coefficient.
   for t,v in ss:
    if mode or ak(t):price+=v*max(0,lo(t)-max(hi(a) if t%3==1 else 0,hi(b) if t%5==1 else 0))
   if 1<left<2*3**813-1 and mode:price+=lo(left)*(lo(1000)-max(hi(a),hi(b)))//lo(1000)
   # Larger external anonymous factors are left uncredited (could share emitter).
   z+=price;children=[]
   if z<best:
    for t in ch[p]:
     if ns%t==0:
      cz,ct=node(t,val(ns,t));z+=cz;children+=ct
      if z>=best:break
    if z<best:choice=[(p,h)]+children;best=z
  return best,([] if choice is None else choice)
 z=d*lo(5);trace=[]
 for p in roots:
  v,t=node(p,max(1,val(S,p)));z+=v;trace+=t
 return z,trace

def initial(d,mode):
 S=sig(5,d);fs=[int(t) for t,_ in json.loads((D/f'fac5/{d}.json').read_bytes())['factors']];return sorted(t for t in fs if prime(t) and (mode or ak(t)))

def base(d,mode,a=43,b=41):return run_fast(d,mode,a,b)[0]-row(d,mode,a,b)
if __name__=='__main__':
 assert __debug__
 for path in sorted((D/'forests').glob('*.json')):
  rec=json.loads(path.read_bytes());d=rec['d'];m=rec['m'];roots=rec['roots'];assert all(sig(5,d)%p==0 for p in roots);owners=dict(rec['owners']);z,trace=evalforest(d,m,owners,roots);v=base(d,m)+z;assert v>=rec['lb'];print(d,'IE'[not m],v//hi(10),v>2400*hi(10))
