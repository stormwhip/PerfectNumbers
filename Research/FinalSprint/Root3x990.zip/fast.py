"""Cold proof: per fixed d, (s,u) envelope and its rigorous linear relaxation. A power-of-three range premise is replayed independently in Prelude990 and Trial990."""
from scan import *
@cache
def ss(s):
 y=3**s;delta=P//y
 return lo(2*y-1),lo(y),hi(3 if R>=2*delta+1 else delta+4)
def run_fast(d,mode,a=43,b=41,bonus=0,sv=813):
 C=row(d,mode,a,b)-discounts(a,b)+bonus;ta=2*lo(a);tb=4*lo(b);r=lo(R);zbest=10**14;worst=None
 for s in range(sv,E+1):
  U=E-s;q0,y,jden=ss(s)
  for u in range(d+1):
   # q >= (2*3^s-1)*5^u; internal lower bound Y*min(1,q/P)/D
   qe=q0+u*lo(5);ee=qe+lo(2)-hi(3);ii=max(0,y+min(0,qe-hi(P))-jden) if mode else 0
   Q=lo(PE)+qe+C+(ee if not mode else 0);H=lo(A)+max(r,ii);F=max(ii,ee) if mode else 0;other=max(0,d-u-(0 if u else 4))
   assert 2*r>max(ta,(tb+1)//2)
   cap=max(0,H-F);saved=0
   for qty,wt,v in sorted(((U,2*r,ta),(other,4*r,tb)),key=lambda z:z[2]*(4*r//z[1]),reverse=True):
    c=min(cap,qty*wt);saved+=(c*v+wt-1)//wt;cap-=c
   v=Q+max(H,F)+ta*U+tb*other-saved
   if v<zbest:zbest=v;worst=s,u
 return zbest,worst
if __name__=='__main__':
 assert __debug__
 ds=json.loads((D/'FiveSupplement/AdmissibleD.json').read_text())['E3b'];out=[]
 for d in ds:
  rec={'d':d}
  for mode in (0,1):
   v,w=run_fast(d,mode);rec['EI'[mode]]={'lb':v,'floor':v//hi(10),'args':w}
  out.append(rec);print(json.dumps(rec),flush=True)
 (D/'first.json').write_text(json.dumps(out,indent=1))
