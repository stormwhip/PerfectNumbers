"""Cold exact replay: no network, no SciPy/SymPy, no historical factor index, no stored numeric lower bounds. Run python -I -S -B check990.py. Companion prerequisites: g++ Trial990 and prereq.py REPO."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from forest5 import *
assert __debug__
assert PE%3==0 and A==(P-1)//2 and math.isqrt(A)**2!=A and R==1+2*991*32768*140000
assert 43**(3**7-1)>B and 41**(5**5-1)>B
assert all(t%3!=1 or not good(t,2) for t in small if t<43 and t not in BAN)
assert all(t%5!=1 for t in small if t<41 and t not in BAN)
assert nosource(5) and max(hi(41),hi(43))<lo(1000) and lo(PE)>0
res=[]
for mode,upper in enumerate((244,370)):
 ds=[d for d in range(2,upper+1,2) if good(5,d)];assert len(ds)==(64,98)[mode]
 for d in ds:
  S=pow_sum(5,d);assert gcd(S,3*5*A)==1 and S<2*3**813-1
  file=D/f'forests/{d}-{mode}.json';lb,_=run_fast(d,mode);kind='child'
  if lb<=2400*hi(10):
   r=json.loads(file.read_bytes());assert (d,mode)==(r['d'],r['m']);roots=r['roots'];ow=dict(r['owners']);assert len(set(roots))==len(roots) and len(ow)==len(r['owners']);assert all(S%t==0 and prime(t) for t in roots);z,trace=evalforest(d,mode,ow,roots);lb=base(d,mode)+z;kind='forest'
  assert lb>2400*hi(10),(d,mode,lb)
  res.append((mode,d,lb,kind));print('E3'+('b' if mode else 'a'),d,kind,lb,'>',2400*hi(10),flush=True)
for m in (0,1):
 x=min(x for x in [(k,d,mode) for mode,d,k,method in res] if x[2]==m);print('minimum',m,x,'cutoff',2400*hi(10))
print('PASS: all 64+98 branches over exact admissible v5, E3a and E3b. With declared inherited premises, (3,990) = P3_I00168 closed.')
