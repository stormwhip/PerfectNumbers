import json,time,urllib.request,sys
from pathlib import Path
D=Path(__file__).resolve().parent
for d in json.loads((D/'FiveSupplement/AdmissibleD.json').read_text())['E3b']:
 path=D/f'fac5/{d}.json';path.parent.mkdir(exist_ok=True)
 if path.exists():continue
 n=(5**(d+1)-1)//4
 for i in range(3):
  try:
   dat=json.load(urllib.request.urlopen('https://factordb.com/api?query='+str(n),timeout=12));assert __import__('math').prod(int(x)**k for x,k in dat['factors'])==n;path.write_text(json.dumps(dat));print(d,dat['status'],[(len(x),k) for x,k in dat['factors']],flush=True);break
  except Exception as err:print(d,str(err),flush=True);time.sleep(3)
 time.sleep(1)
