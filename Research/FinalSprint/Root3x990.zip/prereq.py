"""Cold parent-theorem replay. No new file writes to main. Expected copies under Partial and FiveSupplement are byte-checked against the snapshot zip entries."""
from pathlib import Path
import subprocess,sys,zipfile,hashlib
here=Path(__file__).resolve().parent
repo=Path(sys.argv[1]).resolve()
banks=repo/'Research/Session20261126/NoFive990'
for zipname,folder in [('Partial.zip',here/'Partial'),('IndexFive.zip',here)]:
 with zipfile.ZipFile(banks/zipname) as z:
  for n in z.namelist():
   if n.endswith('.py') or n.endswith('.cpp'):assert z.read(n)==(folder/n).read_bytes(),n
def run(*a):subprocess.run(list(a),check=True,cwd=here)
run(sys.executable,'-I','-S','-B','Partial/NoFive990.py',str(repo))
run(sys.executable,'-I','-S','-B','FiveSupplement/ExactTests.py',str(repo))
# s>=813: failed s in the elementary supplier cap. The Q-squared bound holds independently of source role.
sys.path.insert(0,str(here/'Partial'/'Next'));sys.path.insert(0,str(here/'Partial'));from Hull import setup
assert setup(990)==813
print('PREREQUISITES PASS: E0/E1/E2 + source b=0 + s>=813 + 5 required + upper caps 244/370. Native Trial990.cpp to be compiled separately.')
