"""Offline/optional discovery: PARI ECPP for candidate prime factors. No returned data trusted for proof."""
from pathlib import Path
import subprocess,json,sys,hashlib
import sympy
D=Path(__file__).resolve().parent
for a in sorted((D/'fac5').glob('*.json'),key=lambda p:int(p.stem)):
 for st,_ in json.loads(a.read_bytes())['factors']:
  z=int(st);mk=D/'ec'/hashlib.sha256(st.encode()).hexdigest();mk.parent.mkdir(exist_ok=True)
  if z<2**64 or mk.exists() or not sympy.isprime(z):continue
  try:
   res=subprocess.run([str(D.parent/'lab/GpWin.exe'),'-fq'],input=f'default(parisizemax,500000000);default(nbthreads,1);\nprint(primecert({z}));\n',capture_output=True,text=True,errors='replace',timeout=150)
   ls=[json.loads(s) for s in res.stdout.splitlines() if s.startswith('[[')];assert len(ls)==1;mk.write_text(json.dumps(ls[0],separators=(',',':')));print(a.stem,len(st),flush=True)
  except Exception as err:print(a.stem,len(st),err,flush=True)
