"""Exact 5-index + witnessed prime descendants with joint (3,5)-supply pricing. Integer-only checker."""
from pathlib import Path
import sys,math,json,hashlib,itertools
from functools import cache
D=Path(__file__).resolve().parent
sys.path.insert(0,str(D/'Partial'));from EC import ecprime
E=990;PE=3**E;P=3*PE;A=(P-1)//2;B=10**2400;BAN=(7,11,13,19,31);R=9092464640001
# Integer nanobits, stored logs via explicit floor of scaled natural log. Up/down enclosures.
from decimal import Decimal,localcontext,ROUND_FLOOR
T=10**6
@cache
def lo(z):
 if z==1:return 0
 with localcontext() as c:
  c.prec=48
  return int((Decimal(z).ln().next_minus()*T).to_integral_value(rounding=ROUND_FLOOR))
def hi(z):return lo(z)+2
def pow_sum(t,h):return (t**(h+1)-1)//(t-1)
def val(z,t):
 a=0
 while not z%t:z//=t;a+=1
 return a
@cache
def prime64(n):
 if not 2<=n<2**64:return False
 for t in (2,3,5,7,11,13,17,19,23,29,31,37):
  if n%t==0:return n==t
 s=val(n-1,2);u=(n-1)>>s
 for a in (2,325,9375,28178,450775,9780504,1795265022):
  x=pow(a,u,n)
  if x in (0,1,n-1):continue
  for _ in range(s-1):
   x=x*x%n
   if x==n-1:break
  else:return False
 return True
@cache
def prime(n):
 if n<2**64:return prime64(n)
 path=D/'ec'/hashlib.sha256(str(n).encode()).hexdigest();return path.is_file() and ecprime(n,json.loads(path.read_bytes()),prime64)
@cache
def nosource(t):
 # Assuming only E3a, r=t would be impossible: test sigma(r^h)=qw, b=0, all even h within size cap.
 if A%t==0 or t==3 or t>=2*3**813-1:return False
 y=3**813;h=2
 while PE*A*t**h*pow_sum(t,h)<=B:
  z=pow_sum(t,h);w=(-z)%y or y
  if z%3 and not any(z%b==0 for b in BAN) and w*(2*y-1)<=z:return False
  h+=2
 return True
@cache
def least(t):
 assert prime(t)
 for f in itertools.count(2,2):
  if not any(pow_sum(t,f)%p==0 for p in BAN):return f
@cache
def discounts(a,b):
 # Price 3-supply at t_3^2, 5-supply at t_5^4. One discount per small prime for BOTH.
 z=0
 for t in range(5,max(a,b)):
  if not prime64(t) or t in BAN:continue
  w=0
  for i in range(7 if t%3==1 else 1):
   for j in range(5 if t%5==1 else 1):
    f=3**i*5**j-1
    if not f or not all(pow(t,f+1,p*(t-1))!=1 for p in BAN):continue
    w=max(w,2*i*hi(a)+4*j*hi(b)-f*lo(t))
  z+=w
 return z

def row(d,mode,a,b):
 # Assumed non-emitter 5 and its identified source-free child primes.
 S=pow_sum(5,d);assert math.gcd(S,3*A*5)==1 and S<2*3**813-1 and nosource(5)
 z=0;fac=json.loads((D/f'fac5/{d}.json').read_bytes());factors=fac['factors'];assert all(isinstance(t,str) and t.isdigit() and int(t)>=2 and type(k)==int and k>0 for t,k in factors);assert len({int(t) for t,k in factors})==len(factors);assert math.prod(int(t)**k for t,k in factors)==S
 # Raw net on child primes allows them positive supply even when optimal exponent > least.
 for st,k in fac['factors']:
  t=int(st)
  if not prime(t) or mode==0 and not nosource(t):continue
  assert t not in BAN and t%2 and A%t
  net=B.bit_length()*hi(2)
  for h in range(2,B.bit_length()+2,2):
   if h%2 or h<k:continue
   # for h' >= h, supply per root bounded by 6,4. Check cap early.
   if h*lo(t)-12*hi(a)-16*hi(b)>=net:break
   if any(pow(t,h+1,p*(t-1))==1 for p in BAN):continue
   i=val(h+1,3) if t%3==1 else 0;j=val(h+1,5) if t%5==1 else 0
   net=min(net,h*lo(t)-2*i*hi(a)-4*j*hi(b))
  z+=net
 return z+d*lo(5)

def run(d,mode,a,b):
 # Analytically minimize across Euler 5-supply u via per-unit price interpolation? use exhaustive small mesh s,u.
 C=row(d,mode,a,b)-discounts(a,b);ta=2*lo(a);tb=4*lo(b);r=lo(R);zbest=10**14;worst=None
 for s in range(813,E+1):
  U=E-s;y=3**s;delta=P//y
  for u in range(d+1):
   q=2*y*5**u-1;qe=lo(q);ee=lo(2*q//3);ii=lo(max(1,y*q//(max(q,P)*(3 if R>=2*delta+1 else delta+4)))) if mode else 0
   Q=lo(PE)+qe+C+(ee if not mode else 0);H=lo(A)+max(r,ii);F=max(ii,ee) if mode else 0;other=max(0,d-u-(0 if u else 4))
   # Sources in A: ordinary 3 i and 5 j, disjoint from r. h=i+2j. Least net price = 3^... or 5^..., solve by maximizing linear function at each h.
   # Over REAL i,j: min max(H,F+2rh)+ta(U-i)+tb(other-j) is a 2-item continuous knapsack: first fill capacity to intersection by higher tariff/weight then cheaper. If beyond capacity, 2r>max(ta,tb/2) makes no improvement.
   assert 2*r>max(ta,(tb+1)//2)
   cap=max(0,H-F);saved=0
   for qty,wt,v in sorted(((U,2*r,ta),(other,4*r,tb)),key=lambda z:z[2]*(4*r//z[1]),reverse=True):
    c=min(cap,qty*wt);saved+=(c*v+wt-1)//wt;cap-=c
   v=Q+max(H,F)+ta*U+tb*other-saved
   if v<zbest:zbest=v;worst=(s,u)
 return zbest,worst
if __name__=='__main__':
 assert __debug__;ds=list(map(int,sys.argv[1:])) or json.loads((D/'FiveSupplement/AdmissibleD.json').read_text())['E3b'];out=[]
 for d in ds:
  rec={'d':d}
  for mode in (0,1):
   arr=[(run(d,mode,a,b),a,b) for a,b in [(43,41),(43,101),(101,101),(241,101),(601,241)]]; (v,w),a,b=max(arr);rec['EI'[mode]]=dict(l=v//hi(10),z=v,w=w,a=a,b=b)
  print(json.dumps(rec),flush=True)
