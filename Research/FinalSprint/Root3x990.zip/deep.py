from searchforest import *
for a,b in [(10,0),(6,1),(6,0)]:run(a,b,300)
