"""Standard-library receipt for REGIONS ONLY, no completed exponent. Supply fixed historical-root arithmetic premises from the parity base and Base.py before interpreting cut sums, see README. Read-only; untrusted phase names and log minima are never used as proof."""
from pathlib import Path
import json,sys
p=Path(__file__).resolve().parent;sys.path.insert(0,str(p/'Next/Lower'));sys.path.insert(0,str(p/'Next'));import CheckBatch as cb,CoherentRobust as cr
from Screen import *

def reset(e):cert.clear();cert.update(json.loads(j.raw));setup(e)
if __name__=='__main__':
    assert __debug__
    for e,mode,ids,base,target in [(990,'int',[1,2,3,4,5,6,7,8,9,10,11,33,35,36,37,38,39],4262210214887,549),(970,'int',list(range(2,12)),4174321231820,549),(970,'ext',[10,11],1855*lo(10),507)]:
        for i in ids:
            reset(e);z=cb.run(i,e,mode,target);assert z and z+base>2400*hi(10),(e,i,z,base);print(e,mode,i,(z+base)//hi(10),flush=True)
    for i in [3,4,9,10,11]:
        reset(990);k=cr.calc(i,990,507,False);assert not k['uncovered'] and k['net']+1893*lo(10)>2400*hi(10);print(990,'ext',i,(k['net']+1893*lo(10))//hi(10),flush=True)
    reset(856);j.nosource=lambda t:j.A%t!=0 and t<j.Q;import Flow;Flow.nosource=j.nosource;z=cb.run(11,856,'int',549);assert z+3686537375611>2400*hi(10);print(856,'int',11,(z+3686537375611)//hi(10));print('PASS REGIONS (not actual exponents)')
