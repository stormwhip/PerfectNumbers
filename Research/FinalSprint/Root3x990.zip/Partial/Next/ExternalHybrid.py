"""Fallback for E3a: union of source scenarios from forest atoms; for each failed forest scenario certify LP with all factors supported on the same atom removed from both held and residual terms. Overlapping atoms are allowed; exact coverage by outer cutset. Tests only proofs, never treats primal status as proof."""
from pathlib import Path
import sys,inspect,json,math
here=Path(__file__).resolve().parent;sys.path.insert(0,str(here));import OuterFlow as fo,NextFlow as nf,Screen as sc
from NextFlow import *
# Return full per-row volume and a list of possibly-source overlapping factors and their prices.
s=inspect.getsource(fo.model);tt='for k,(ks,left) in out.items():rows[pvol][k]=sum(coeff[t]*h for t,h in ks if j.nosource(t)); # deliberately drop all unresolved factors; safe without branching on the unique external source';assert tt in s
s=s.replace(tt,'''loss={}
    for k,(ks,left) in out.items():
        z=(lo(left)*(lo(50000)-Tpen)//lo(50000)) if left>1 else 0
        rows[pvol][k]=sum(coeff[t]*h for t,h in ks)+z
        for t,h in ks:
            if not j.nosource(t):loss.setdefault(t,[]).append((k,coeff[t]*h))
        if left>1:loss.setdefault(left,[]).append((k,z))''').replace('return data,rows,rhs,names,opts,lefts','return data,rows,rhs,names,opts,loss');ns=dict(vars(fo));exec(s,ns);model=ns['model']

def search(i,target=283,limit=1000):
    # no dependence on tree ordering/price in the forest; simply cover all disjoint support atoms of the flow rows here.
    import numpy as np
    from scipy.optimize import linprog
    from scipy.sparse import coo_matrix
    data,rows,rhs,names,opts,loss=model(i);n=len(data);D=10**7;vrow=names.index('vol');xa=list(loss);goal=target*hi(10);dest=here/f'exthyb{i}.json';records=[]
    I=[];J=[];V=[]
    for id,row in enumerate(rows):I.extend([id]*len(row));J.extend(row);V.extend(v/T for v in row.values())
    aa=coo_matrix((V,(I,J)),shape=(len(rows),n)).tocsr();b=np.array(rhs)/T;c=np.array(data)/T
    @cache
    def product(a,b):
        if b-a==1:return xa[a]
        m=(a+b)//2;return product(a,m)*product(m,b)
    from Batch import adjacency
    adj=adjacency(xa)
    def contaminated(a,b):return [xa[k] for k in set.union(*adj[a:b])]
    def solve(rr,mat):
        res=linprog(c,A_ub=mat,b_ub=b,bounds=[(0,1)]*(n-1)+[(0,None)],method='highs');assert res.success;d={k:int(round(max(0,-v)*D)) for k,v in zip(names,res.ineqlin.marginals) if v<0};return nf.verify(data,rr,rhs,names,opts,d),d
    stack=[(0,len(xa))];zfull,full=solve(rows,aa);minz=zfull;leaves=[];fail=[]
    while stack and len(records)<limit:
        a,bx=stack.pop();bad=xa if a==0 and bx==len(xa) else contaminated(a,bx);rr=rows.copy();rr[vrow]=rr[vrow].copy()
        for t in bad:
            for k,z in loss[t]:rr[vrow][k]-=z
        z=nf.verify(data,rr,rhs,names,opts,full);d=None
        if z<=goal:
            mat=aa.copy().tolil();mat[vrow,:]=0
            for k,v in rr[vrow].items():mat[vrow,k]=v/T
            z,d=solve(rr,mat.tocsr())
        if z>goal or bx-a==1:
            records.append((a,bx,d));minz=min(z,minz)
            if z<=goal:fail.append((xa[a],z))
        else:
            m=(a+bx)//2;stack.extend([(a,m),(m,bx)])
    dest.write_text(json.dumps(dict(full=full,records=records),separators=(',',':')));return dict(i=i,net=minz,digits=minz//hi(10),atoms=len(xa),groups=len(records),remaining=len(stack),fails=fail)
if __name__=='__main__':
    assert __debug__;setup(int(sys.argv[2]));
    for i in map(int,sys.argv[3:]):print(json.dumps(search(i)),flush=True)
