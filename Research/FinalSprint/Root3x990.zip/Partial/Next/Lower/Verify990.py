"""Independently replay external atom-group dual, then the already available internal dual at e=990. Stdlib only. Canonical partition subdomain 11 only."""
from pathlib import Path
import sys,json,math
here=Path(__file__).resolve().parent;sys.path.insert(0,str(here.parent));import ExternalHybrid as eh,NextFlow,CheckCut as cc,FlowHull,Base
from Screen import *
if __name__=='__main__':
    assert __debug__;setup(990);i=11;data,rows,b,names,opts,loss=eh.model(i);key=json.loads((Path(__file__).resolve().parent/'exthyb11.json').read_bytes());xs=list(loss);iv=names.index('vol');z=NextFlow.verify(data,rows,b,names,opts,key['full']);cursor=0
    for a,k,w in sorted(key['records']):
        assert a==cursor and a<k<=len(xs);cursor=k;P=math.prod(xs[a:k]);rr=rows.copy();rr[iv]=rr[iv].copy()
        for t,li in loss.items():
            if gcd(P,t)>1:
                for j,c in li:rr[iv][j]-=c
        z=min(z,NextFlow.verify(data,rr,b,names,opts,w or key['full']))
    assert cursor==len(xs) and 1893*lo(10)+z>2400*hi(10)
    cc.model=FlowHull.model;sys.argv.append('hull');inner=cc.check(i,311)['minimum'];assert inner+4262210214887>2400*hi(10)
    print(dict(e=990,i=i,ext=z,int=inner,ext_floor=(1893*lo(10)+z)//hi(10),int_floor=(4262210214887+inner)//hi(10),source_premises='external 1893 by parity/Next, internal 4262210214887 by Base.py',accepted_actuals=[]))
