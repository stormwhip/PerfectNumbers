"""990 E3a across families: use GLOBAL second-generation flow + exclusive exponent transition rows and support-specific residual overlap. Rather than erase every unknown cost, group all possible Euler-source atoms by exact gcd incidence; for each group independently first try full uniform-dual integer tree, then refine. Code uses common checked arithmetic and rc. Does not change global joint or 1108 files."""
from pathlib import Path
import sys,inspect,json,math,hashlib
here=Path(__file__).resolve().parent;sys.path.insert(0,str(here));sys.path.insert(0,str(here.parent));import DeepPool as dp,ExternalHybrid as eh,IntegerCut as ic,CheckCut as cc,NextFlow as nf
from Screen import *
from Batch import adjacency

def model(i):
    # Factor candidate enrichment is identical to DeepPool but return UNKNOWN residue -> per-column scheduled loss rather than raw left.
    s=inspect.getsource(dp.built);old="base=fh if mode=='int' else __import__('OuterFlow');d,rows,b,names,opts,lefts=base.model(i)";assert old in s;ctx=dict(vars(dp));ctx['E']=eh;exec(s.replace(old,"d,rows,b,names,opts,lefts=E.model(i)"),ctx);return ctx['built'](i)

def calc(i,e,aim,search):
    import copy
    data,rows,b,names,opts,loss=model(i);xs=list(loss);adj=adjacency(xs);iv=names.index('vol');target=aim*hi(10);root=Path(__file__).resolve().parent;ic.here=root;ids={j:r for r,c in opts.items() for _,j in c};stats=0;lo_all=10**20;miss=[];keep=[];openall=False
    def cell(a,bx,depth):
        nonlocal stats,lo_all,openall
        rr=rows.copy();rr[iv]=rr[iv].copy();bad=range(len(xs)) if bx-a==len(xs) else set.union(*adj[a:bx]);
        for u in bad:
            for j,h in loss[xs[u]]:rr[iv][j]-=h
        key=f'r{e}i{i}a{a}b{bx}-';fn=lambda ii:(data,rr,b,names,opts,{})
        path=root/f'{key}{i}.json'
        if search and not path.is_file():ic.model=fn;ic.branch(i,aim,50 if depth<2 else 100,key)
        z=0
        if path.is_file():
            try:
                ob=json.loads(path.read_bytes());
                if ob['info']['complete']:
                    txt=inspect.getsource(cc.check);tag="prefix='hullcut' if 'hull' in sys.argv else 'cut';";env=dict(vars(cc));env.update(here=root,model=fn);exec(txt.replace(tag,'prefix='+repr(key)+';'),env);z=env['check'](i,aim)['minimum']
            except (KeyError,AssertionError):z=0
        stats+=1
        if z>target:lo_all=min(lo_all,z);keep.append([a,bx,z]);return
        if bx-a==1 or depth>=6 or stats>=140:miss.append([a,bx]);return
        m=(a+bx)//2;cell(a,m,depth+1);cell(m,bx,depth+1)
    cell(0,len(xs),0);return dict(e=e,i=i,aim=aim,nres=len(xs),tested=stats,closed=keep,uncovered=miss,net=lo_all if not miss else None)
if __name__=='__main__':
    assert __debug__;setup(int(sys.argv[2]));
    for i in (int(x) for x in sys.argv[4:] if x.isdigit()):print(json.dumps(calc(i,int(sys.argv[2]),int(sys.argv[3]),'search' in sys.argv)),flush=True)
