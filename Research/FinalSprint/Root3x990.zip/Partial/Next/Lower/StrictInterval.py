"""Fail-closed wrapper for a short list of correctly rebuilt external source partitions."""
import sys,json
from pathlib import Path
p=Path(__file__).resolve().parent;sys.path.insert(0,str(p));import IntervalCertificate as x
if __name__=='__main__':
    assert __debug__;e=int(sys.argv[2]);gen=int(sys.argv[3]);aim=int(sys.argv[4]);b={990:1893,970:1855,856:1639}[e]*x.lo(10)
    for i in map(int,sys.argv[5:]):x.cert.clear();x.cert.update(json.loads(x.j.raw));x.setup(e);r=x.run(e,i,gen,aim,b);assert r['ok'];print(json.dumps(r),flush=True)
