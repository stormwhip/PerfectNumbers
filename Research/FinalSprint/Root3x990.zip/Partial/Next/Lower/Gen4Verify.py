"""Cold replay of a finite next-generation support set, not its statistical discovery. The list is a hint only: every named prime, divisibility implication and selection constraint must still pass the exact model builder."""
from pathlib import Path
import sys,inspect,json
p=Path(__file__).resolve().parent;sys.path.insert(0,str(p));sys.path.insert(0,str(p.parent));import Gen4 as g,CheckCut as cc
from Screen import *
if __name__=='__main__':
    assert __debug__;e=int(sys.argv[2]);mode=sys.argv[3];goal=int(sys.argv[4]);orig=sc0=g.sc.extra
    for i in map(int,sys.argv[5:]):
        reset=setup(e);cert.clear();cert.update(json.loads(j.raw));g.sc.extra=orig;txt=inspect.getsource(cc.check);q="prefix='hullcut' if 'hull' in sys.argv else 'cut';";env=dict(vars(cc));env.update(here=p,model=lambda ii:g.gp(ii,mode));exec(txt.replace(q,'prefix='+repr('gen4'+str(e)+mode)+';'),env);print(json.dumps(env['check'](i,goal)),flush=True)
