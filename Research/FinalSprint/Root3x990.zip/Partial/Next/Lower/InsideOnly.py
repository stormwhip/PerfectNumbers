"""For E3b the source r|A, so t∤A directly forbids source overlap; no need for the E3a congruence-killer window. E3b abundance of q and A support only, not an additional unknown external-source base. No arithmetic or assumption about prime supply imported across root exponents. Useful at 856 where small t cannot yet be excluded as external sources uniformly."""
import sys,json,inspect
from pathlib import Path
here=Path(__file__).resolve().parent;sys.path.insert(0,str(here));sys.path.insert(0,str(here.parent));import CheckBatch as cb,DeepPool as dp,Screen as sc
from Screen import *
if __name__=='__main__':
    e=int(sys.argv[2]);setup(e)
    # Existing model calls this for every possible known emitter and auxiliary candidate. In E3b with r|A and A%t!=0 it is exact even when t could emit q in external E3a.
    j.nosource=lambda t: j.A%t!=0 and t<j.Q
    from Flow import __dict__ as flglobals
    flglobals['nosource']=j.nosource
    for i in map(int,sys.argv[3:]):
        pp=Path(__file__).resolve().parent;k=pp/f'new{e}int{i}.json';k.write_bytes((pp/f'new990int{i}.json').read_bytes());v=cb.run(i,e,'int',549);b={856:3686537375611,970:4174321231820,990:4262210214887}[e];print(dict(e=e,i=i,net=v,passes=bool(v and b+v>2400*hi(10)),floor=(b+(v or 0))//hi(10)),flush=True)
