"""Adaptive but all-family third-generation common bank. Promote only children of rows frequent in complete corpus LP relaxation examples; none assumed active. Fixed source pool, EC witnesses and completed factorizations are checked with prior stdlib core; promoted nodes appear exclusively through individual + grouped inflows. Generic for every support leaf, not a leaf-specific hardcoding."""
import sys,json,inspect
from pathlib import Path
p=Path(__file__).resolve().parent;sys.path.insert(0,str(p));sys.path.insert(0,str(p.parent));import DeepPool as dp,Screen as sc, IntegerCut as ic
from Screen import *

def gp(i,mode):
    F=(cert['cell10']+cert['cell11'])[i];h=F['forest'];F['forest']=h if h else {'cut_even':{},'edges':{},'roots':[]};h=F['forest'];qset=json.loads((Path(__file__).resolve().parent/'Gen3Factors.json').read_bytes());ec=set();from EC import ecprime
    for l in (Path(__file__).resolve().parent/'Gen3EC.jsonl').read_text().splitlines():
        if l.startswith('[['):c=json.loads(l);q=c[0][0];assert ecprime(q,c,prime64);ec.add(q)
    old=sc.extra;ds,ds_ec=old();sc.extra=lambda:(ds|set(qset),ds_ec|ec)
    for t in qset:
        if t in BAN|set(F['absent_extra']) or not (prime(t) or t in ds_ec|ec) or not j.nosource(t):continue
        h['cut_even'].setdefault(str(t),6)
    # Any new factor from the hint file entering sc.extra must be a verified prime.
    assert all(prime(t) or t in ds_ec|ec for t in qset)
    return dp.built(i,mode)
if __name__=='__main__':
    assert __debug__;setup(int(sys.argv[2]));mode=sys.argv[3];aim=int(sys.argv[4]);ic.here=Path(__file__).resolve().parent;ic.model=lambda i:gp(i,mode)
    for i in map(int,sys.argv[5:]):print(json.dumps(ic.branch(i,aim,120,'gen3'+sys.argv[2]+mode)),flush=True)
