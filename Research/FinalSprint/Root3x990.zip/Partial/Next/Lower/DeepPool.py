"""All-990 support-level, parent-coherent AND transitions (one set of named columns per prime). If any of the mutually exclusive columns of parent r emits t^v, its indicator-sum must not exceed the SUM of t's choices with h>=v. Last generation imposed each antecedent individually; here their convex aggregation fixes low fractional splitters. Dynamic 2nd generation is global and not specialized to one leaf. Large-prime admission always checked independently. No files written outside Lower. Search/cold use mode argument; E3b. Reuse existing hull cap H_t=sum across sources max across exponents, rather than paying an arbitrary square twice."""
import sys,json,inspect
from pathlib import Path
p=Path(__file__).resolve().parent;sys.path.insert(0,str(p.parent));import NextFlow as nf, FlowHull as fh, IntegerCut as ic,Screen as sc
from Screen import *

def built(i,mode='int'):
    L=(cert['cell10']+cert['cell11'])[i];F=L['forest'] or {};src=set(map(int,F.get('cut_even',{})));absent=BAN|set(L['absent_extra']);hints,ec=sc.extra();P=(L['lp'] or {}).get('P',[]);named=set(P)|src;primary={r for r in j.small if r<260 and r not in absent};children=set()
    for r in primary:
        for f in range(2,22,2):
            S=sig(r,f)
            if any(S%a==0 for a in absent):continue
            fac,y=small_parts(S//3**val(S,3));children.update(t for t,k in fac);children.update(t for t in hints if y%t==0)
            if y>1 and (prime(y) or y in ec):children.add(y)
    children={t for t in children if t not in absent and j.nosource(t) and (prime(t) or t in ec)};primary|=children;named|=primary
    # Put every nominated second-generation prime in finite support; only relatively small primaries receive broadened tails (a correctness-neutral choice).
    L['lp']=dict(P=sorted(set(P)|children));
    if L['forest'] is None:L['forest']={'cut_even':{},'edges':{},'roots':[]}
    for t in primary:
        if t<10000:L['forest']['cut_even'].setdefault(str(t),8)
    base=fh if mode=='int' else __import__('OuterFlow');d,rows,b,names,opts,lefts=base.model(i);ix={k:r for r,l in opts.items() for f,k in l}; added=[]
    for row,name in zip(rows[:],names[:]):
        if not name.startswith('sum'):continue
        t=int(name[3:]);g={}
        for k,val0 in row.items():
            if val0>0:g.setdefault(ix[k],[]).append((k,val0//T))
        for r,ls in g.items():
            for v in set(h for k,h in ls):
                pred=[k for k,h in ls if h>=v]
                if len(pred)<2:continue
                rr={k:T for k in pred};rr.update({k:-T for f,k in opts[t] if f is None or f>=v});added.append((f'aggregate{r}:{t}:{v}',rr))
    for k,row in added:names.append(k);rows.append(row);b.append(0)
    return d,rows,b,names,opts,lefts
if __name__=='__main__':
    assert __debug__;setup(int(sys.argv[2]));mode=sys.argv[3];aim=int(sys.argv[4]);ic.here=Path(__file__).resolve().parent;ic.model=lambda i:built(i,mode)
    for i in map(int,sys.argv[5:]):print(json.dumps(ic.branch(i,aim,120,'new'+sys.argv[2]+mode)),flush=True)
