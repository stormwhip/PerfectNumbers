"""Exact proof for selected ordered source ranges. No solver required. Every used source index must be covered; all ranges are rebuilt from the exact model, and entire contaminated prime support removed. Calculates next-snapshot aggregate support outside one atom (Bernstein) and verifies every supplied row tree. Accepting a cell ignores solver metadata once a complete external cover has been parsed."""
import sys,json,inspect,math
from pathlib import Path
p=Path(__file__).resolve().parent;sys.path.insert(0,str(p));sys.path.insert(0,str(p.parent));import CheckCut as cc,CoherentRobust as cr,ThirdRobust as third
from Screen import *
from Batch import adjacency

def run(e,i,gen,aim,base):
    root=Path(__file__).resolve().parent;key=('gen3r' if gen==3 else 'r')+f'{e}i{i}';ps=[]
    for f in root.glob(f'{key}a*b*-{i}.json'):
        rec=json.loads(f.read_bytes());s=f.stem[len(key)+1:].split('-')[0];a,b=s.split('b');
        if rec['info']['complete']:ps.append((int(a),int(b),f.stem[:-len(str(i))]))
    data,rows,rhs,names,opts,loss=(third.model if gen==3 else cr.model)(i);xs=list(loss);n=len(xs);a=0;queue=[];safe=False
    if (e,i,gen)==(990,0,3):
        from EC import ecprime
        x=xs[97];fs=[5266228211,4217468380980037880092527701441161,237916085520023302947010376750220097331];assert x==math.prod(fs) and x==json.loads((root/'atom990.json').read_bytes());cs=[json.loads(l) for l in (root/'atom990cert.jsonl').read_text().splitlines() if l.startswith('[[')];ec={c[0][0] for c in cs if ecprime(c[0][0],c,prime64)};assert all((prime64(t) or t in ec) and j.nosource(t) for t in fs);safe=True
    while a<n:
        if safe and a==97:a+=1;continue # all prime factors of this hypothesized source support are certified non-sources
        poss=[(b,tag) for l,b,tag in ps if l==a and b<=n]
        if not poss:return dict(i=i,ok=False,first_gap=a)
        b,tag=max(poss);queue.append((a,b,tag));a=b
    adj=adjacency(xs);iv=names.index('vol');out=[]
    for a,b,tag in queue:
        vrows=rows.copy();vrows[iv]=vrows[iv].copy();bad=set.union(*adj[a:b]);
        for jj in bad:
            for k,v in loss[xs[jj]]:vrows[iv][k]-=v
        text=inspect.getsource(cc.check);mark="prefix='hullcut' if 'hull' in sys.argv else 'cut';";assert mark in text;ctx=dict(vars(cc));ctx['here']=root;ctx['model']=lambda ii:(data,vrows,rhs,names,opts,{})
        exec(text.replace(mark,'prefix='+repr(tag)+';'),ctx);out.append(ctx['check'](i,aim)['minimum'])
    val=min(out);assert base+val>2400*hi(10);return dict(i=i,ok=True,cells=len(out),net=val,total_floor=(base+val)//hi(10))
if __name__=='__main__':
    e=int(sys.argv[2]);gen=int(sys.argv[3]);aim=int(sys.argv[4]);base={990:1893,970:1855,856:1639}[e]*lo(10)
    for i in map(int,sys.argv[5:]):cert.clear();cert.update(json.loads(j.raw));setup(e);print(json.dumps(run(e,i,gen,aim,base)),flush=True)
