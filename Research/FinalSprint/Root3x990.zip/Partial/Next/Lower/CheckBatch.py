"""Untrusted transcript of 990 batch certificates. Check complete binary trees with exact reduced costs after reconstructing full two-generation support pool; no SciPy. Reads only candidates with certified dual paths; outcomes obtained by recomputing, not trusting optimizer status. I/O kept in Lower."""
from pathlib import Path
import sys,inspect,json
here=Path(__file__).resolve().parent;sys.path.insert(0,str(here));sys.path.insert(0,str(here.parent));import DeepPool as d,CheckCut as cc
from Screen import *

def run(i,e,mode,aim):
    pp=Path(__file__).resolve().parent;key='new'+str(e)+mode;fp=pp/f'{key}{i}.json';r=json.loads(fp.read_bytes());
    if not r['info']['complete']:return None
    s=inspect.getsource(cc.check);text="prefix='hullcut' if 'hull' in sys.argv else 'cut';";assert text in s
    ns=dict(vars(cc));ns['here']=pp;ns['model']=lambda ii:d.built(ii,mode);exec(s.replace(text,'prefix='+repr(key)+';'),ns);return ns['check'](i,aim)['minimum']
if __name__=='__main__':
    assert __debug__;e=int(sys.argv[2]);mode=sys.argv[3];aim=int(sys.argv[4]);setup(e)
    for i in map(int,sys.argv[5:]):
        v=run(i,e,mode,aim)
        if v:print(json.dumps(dict(e=e,i=i,mode=mode,net=v,base=4262210214887 if mode=='int' and e==990 else 1893*lo(10) if mode=='ext' and e==990 else None)),flush=True)
