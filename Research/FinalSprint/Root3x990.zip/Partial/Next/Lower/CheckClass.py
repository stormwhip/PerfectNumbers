"""Further organizational convenience: validate all available successful dual trees for a given e without treating claimed success as proof. If no witness, report unattempted instead of declaring all leaves. Computes total using conservative base (same wider e=856 E3b-specific guard if necessary)."""
from pathlib import Path
import sys,json,copy
p=Path(__file__).resolve().parent;sys.path.insert(0,str(p));sys.path.insert(0,str(p.parent));import CheckBatch as c
from Screen import *
if __name__=='__main__':
    e=int(sys.argv[2]);mode=sys.argv[3];aim=int(sys.argv[4]);base=(dict([(990,4262210214887),(970,4174321231820),(856,3686537375611)])[e] if mode=='int' else dict([(990,1893),(970,1855),(856,1639)])[e]*lo(10));setup(e)
    if mode=='int' and e==856:
        j.nosource=lambda t:j.A%t!=0 and t<j.Q;import Flow;Flow.nosource=j.nosource
    oks=[];none=[]
    for i in range(42):
        j.cert.clear();j.cert.update(json.loads(j.raw));q=p/f'new{e}{mode}{i}.json'
        if not q.exists():none.append(i);continue
        v=c.run(i,e,mode,aim)
        if v is None or v+base<=2400*hi(10):none.append(i);continue
        oks.append((i,v,(v+base)//hi(10)));print(i,v,flush=True)
    print(json.dumps(dict(e=e,mode=mode,verified=oks,remaining=none,accepted_actuals=[])),flush=True)
