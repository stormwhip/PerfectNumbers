"""Apply group-aware externally robust source LP to all 5-absent leaves with shared 99-child pool. Complement to the second generation: mathematically all added nodes also in sum indices, both rho->t ancestry and price hull checked. Does not rely on scipy for cold receipts."""
from pathlib import Path
import sys,json,inspect
p=Path(__file__).resolve().parent;sys.path.insert(0,str(p));sys.path.insert(0,str(p.parent));import Gen3 as gen,CoherentRobust as cr,ExternalHybrid as eh,DeepPool as dp
from Screen import *

def model(i):
    # Gen3 uses dp.built; substitute the same coherent-with-loss model as in prior stage, without any new arithmetic predicates.
    base=cr.model;dp0=dp.built
    import types
    gptext=inspect.getsource(gen.gp);ctx=dict(vars(gen));ctx['DP']=base;exec(gptext.replace('return dp.built(i,mode)','return DP(i)'),ctx);return ctx['gp'](i,'int')
if __name__=='__main__':
    assert __debug__;e=int(sys.argv[2]);aim=int(sys.argv[3]);setup(e);txt=inspect.getsource(cr.calc);ctx=dict(vars(cr));ctx['model']=model;ctx['here']=p;txt=txt.replace("key=f'r{e}i{i}a{a}b{bx}-'","key=f'gen3r{e}i{i}a{a}b{bx}-'");exec(txt,ctx)
    for i in (int(x) for x in sys.argv[4:] if x.isdigit()):print(json.dumps(ctx['calc'](i,e,aim,'search' in sys.argv)),flush=True)
