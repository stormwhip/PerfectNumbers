from pathlib import Path
import sys,json
p=Path(__file__).resolve().parent;sys.path.insert(0,str(p));import CheckBatch as c
if __name__=='__main__':
    assert __debug__;e=int(sys.argv[2]);mode=sys.argv[3];aim=int(sys.argv[4]);base={990:4262210214887,970:4174321231820,856:3686537375611}[e] if mode=='int' else {990:1893,970:1855,856:1639}[e]*c.lo(10)
    for i in map(int,sys.argv[5:]):c.cert.clear();c.cert.update(json.loads(c.j.raw));c.setup(e);z=c.run(i,e,mode,aim);assert z and z+base>2400*c.hi(10);print(e,mode,i,(z+base)//c.hi(10),flush=True)
