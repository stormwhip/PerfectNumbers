"""Standalone cold validation of saved integer disjunction witnesses; no optimizer dependency."""
from pathlib import Path
import json,sys
here=Path(__file__).resolve().parent;sys.path.insert(0,str(here));from NextFlow import *

def check(i,aim):
    data,rows,rhs,names,opts,lefts=model(i);ids={r:l for r,l in opts.items()};D=10000000
    prefix='hullcut' if 'hull' in sys.argv else 'cut';tree=json.loads((here/f'{prefix}{i}.json').read_bytes())['tree'];seen=set();stack=[(0,{})];bs=[];n=len(data)
    while stack:
        k,fix=stack.pop();assert 0<=k<len(tree) and k not in seen;seen.add(k);a=tree[k]
        if 'split' in a:
            j=a['split'];assert type(j)==int and 0<=j<n-1 and j not in fix and len(a['children'])==2;c,d=a['children'];stack.extend([(c,fix|{j:1}),(d,fix|{j:0})]);continue
        w=a['done'];assert set(w)<=set(names) and all(type(t)==int and t>=0 for t in w.values());rc=[z*D for z in data];v=0;den=D
        for row,name,b in zip(rows,names,rhs):
            h=w.get(name,0)
            if h:
                v-=h*b
                for j,z in row.items():rc[j]+=h*z
        if rc[-1]<0:
            u=T*D;dd=u-rc[-1];rc=[u*z+(dd-u)*y*D for z,y in zip(rc,data)];v*=u;den*=dd
        assert rc[-1]>=0
        for ls in ids.values():
            yes=[j for _,j in ls if fix.get(j)==1]
            if yes:v+=sum(rc[k] for k in yes)
            else:v+=min([0]+[rc[j] for _,j in ls if fix.get(j)!=0])
        assert v//den>aim*hi(10),(i,k,v//den);bs.append(v//den)
    assert len(seen)==len(tree) and bs;return dict(i=i,aim=aim,cells=len(bs),minimum=min(bs))
if __name__=='__main__':
    assert __debug__;setup(int(sys.argv[2]));aim=int(sys.argv[3]);
    if 'hull' in sys.argv:from FlowHull import model
    for i in (int(z) for z in sys.argv[4:] if z.isdigit()):print(json.dumps(check(i,aim)),flush=True)
