"""Finite LP branch-and-bound proof search over genuinely binary options. Test all cases: cut x_j=0 or 1. Per-node lower bound is exact verified integral dual after supporting finite 0/1 bounds, no MILP solver or numerical optimality trusted. E3b only."""
import sys,json,time
from pathlib import Path
here=Path(__file__).resolve().parent;sys.path.insert(0,str(here));import NextFlow as nf
from NextFlow import *

def branch(i,aim,maxnodes=300,prefix='cut'):
    data,rows,rhs,names,opts,lefts=model(i);n=len(data);targ=aim*hi(10);lookup={j:(r,f) for r,l in opts.items() for f,j in l};from scipy.optimize import linprog;import numpy as np;from scipy.sparse import coo_matrix
    I=[];J=[];V=[]
    for k,row in enumerate(rows):I.extend([k]*len(row));J.extend(row);V.extend(v/T for v in row.values())
    mat=coo_matrix((V,(I,J)),shape=(len(rows),n)).tocsr();c=np.array(data)/T;b=np.array(rhs)/T;start=time.monotonic();nodes=0;closed=0;lowest=10**20;openlow=10**20;sample=[];tree=[];stack=[({},None)];D=10**7
    while stack and nodes<maxnodes:
        fix,par=stack.pop();ub=[(0,1)]*(n-1)+[(0,None)]
        for j,v in fix.items():ub[j]=(v,v)
        res=linprog(c,A_ub=mat,b_ub=b,bounds=ub,method='highs');nodes+=1
        if res.status==2:
            # No solver infeasibility trusted: obtain a finite-penalty bound via dual of elastic model, with same bounded variables.
            from scipy.sparse import hstack,eye
            zz=hstack((mat,-eye(len(rows)))).tocsr();res=linprog(np.concatenate((c,np.full(len(rows),10000.))),A_ub=zz,b_ub=b,bounds=ub+[(0,None)]*len(rows),method='highs');assert res.success
        assert res.success;d={name:int(round(max(0.,-v)*D)) for name,v in zip(names,res.ineqlin.marginals) if v<0};rc=[z*D for z in data];v=0
        for row,name,k in zip(rows,names,rhs):
            h=d.get(name,0)
            if h:
                v-=k*h
                for j,x in row.items():rc[j]+=h*x
        den=D
        if rc[-1]<0:
            k=T*D;dd=k-rc[-1];v*=k;rc=[k*z+(dd-k)*y*D for z,y in zip(rc,data)];den*=dd
        assert rc[-1]>=0
        for r,ls in opts.items():
            forced=[j for _,j in ls if fix.get(j)==1]
            if forced:v+=sum(rc[k] for k in forced)
            else:v+=min([0]+[rc[j] for _,j in ls if fix.get(j)!=0])
        z=v//den
        if z>targ:
            k=len(tree);tree.append(dict(done=d));closed+=1;lowest=min(lowest,z)
        else:
            fractional=[j for j,x in enumerate(res.x[:n-1]) if 1.e-5<x<1-1.e-5 and j not in fix]
            if not fractional:
                k=len(tree);tree.append(dict(open=z));openlow=min(openlow,z);sample.append((z,[lookup[j] for j,x in enumerate(res.x[:n-1]) if x>.99]));break
            # Promote small forced exponent choices early: high inflows and small prime often give largest fractionality gap.
            jj=max(fractional,key=lambda j: min(res.x[j],1-res.x[j])/(1+0.02*(lookup[j][0].bit_length())))
            k=len(tree);tree.append(dict(split=jj,children=[]));stack.append((fix|{jj:0},k));stack.append((fix|{jj:1},k))
        if par is not None:tree[par]['children'].append(k)
    out=dict(i=i,aim=aim,nodes=nodes,closed=closed,complete=(not stack and not sample),netmin=lowest,open_nodes=len(stack),open_example=sample[:1],elapsed=round(time.monotonic()-start,1));(here/f'{prefix}{i}.json').write_text(json.dumps(dict(info=out,tree=tree),separators=(',',':')));return out
if __name__=='__main__':
    assert __debug__;setup(int(sys.argv[2]));print(json.dumps(branch(int(sys.argv[3]),int(sys.argv[4]),int(sys.argv[5]))),flush=True)
