"""1108 common support flow. Strong net objective forces absolute supply as in Root-3 joint. All source columns (including additional large forest nodes) have abundance columns. Add integral root exponent disjunctions at user-selected r via explicit exact-cover alternatives. Model returns integral verified per-branch dual, not LP solver output as proof."""
from pathlib import Path
import sys,inspect,json
from functools import cache
here=Path(__file__).resolve().parent;sys.path.insert(0,str(here));import Screen as sc
from Screen import *
import Flow as fl

def model(i):
    F=(cert['cell10']+cert['cell11'])[i]['forest'] or {}
    p=here/f'tree{i}.json'
    if F and p.exists():
        for r,t in json.loads(p.read_bytes())['edges']:
            if str(t) not in F['cut_even']:F['edges'].setdefault(str(r),[]).append(t);F['cut_even'][str(t)]=4
    s=inspect.getsource(fl.model);a='stop=F.get(\'cut_even\',{}).get(str(r),42 if r<100 else 22 if r<400 else 12);opts[r]=[];fe=stop';assert a in s
    s=s.replace(a,"stop=F.get('cut_even',{}).get(str(r),42 if r<100 else 22 if r<400 else 12)\n        if str(r) in F.get('cut_even',{}):\n            while stop*lo(r)-(4*hi(stop+1) if r%3==1 else 0)<350*hi(10):stop+=2\n        opts[r]=[];fe=stop")
    s=s.replace('if left>1 and (not external or (prime(left) and nosource(left))):vv+=lo(left)*(lo(50000)-2*hi(3))//lo(50000)','if left>1:\n                        lefts[len(data)]=left;vv+=lo(left)*(lo(50000)-2*hi(3))//lo(50000)')
    s=s.replace('opts={};rows=[]','lefts={};opts={};rows=[]').replace('return data,rows,rhs,names','return data,rows,rhs,names,opts,lefts')
    d=dict(vars(fl));d.update(e=j.e,A=j.A,Q=j.Q,pe=j.pe,Y=j.Y,prime=lambda t:prime(t) or t in sc.extra()[1]);exec(s,d);return d['model'](i)

def solve(i):
    data,rows,b,names,opts,lefts=model(i);lookup={j:(r,f)for r,l in opts.items() for f,j in l};D=10**7
    import numpy as np
    from scipy.optimize import linprog
    from scipy.sparse import coo_matrix
    I=[];J=[];V=[]
    for k,rr in enumerate(rows):I.extend([k]*len(rr));J.extend(rr);V.extend(v/T for v in rr.values())
    a=coo_matrix((V,(I,J)),shape=(len(rows),len(data))).tocsr();n=len(data);res=linprog(np.array(data)/T,A_ub=a,b_ub=np.array(b)/T,bounds=[(0,1)]*(n-1)+[(0,None)],method='highs');assert res.success
    ds={name:round(max(0,-v)*D) for name,v in zip(names,res.ineqlin.marginals) if v<0};flow=here/f'Flow{i}.json';flow.write_text(json.dumps(ds,separators=(',',':')))
    val=verify(data,rows,b,names,opts,ds);return dict(i=i,net=val,digits=val//hi(10),floating=res.fun,root_support=[(lookup[jj],round(float(x),4)) for jj,x in enumerate(res.x[:-1]) if x>0 and lookup[jj][0] in (5,17,23,29,37,41)])

def verify(data,rows,b,names,opts,dual):
    D=10**7;rc=[v*D for v in data];v=0;assert set(dual)<=set(names) and all(type(a)==int and a>=0 for a in dual.values())
    for row,n,z in zip(rows,names,b):
        a=dual.get(n,0)
        if a:
            v-=a*z
            for j,h in row.items():rc[j]+=a*h
    den=D
    if rc[-1]<0:
        x=T*D;d=x-rc[-1];rc=[x*z+(d-x)*c*D for z,c in zip(rc,data)];v*=x;den*=d
    assert rc[-1]>=0
    for l in opts.values():v+=min(0,min(rc[j] for _,j in l))
    return v//den
if __name__=='__main__':
    assert __debug__;setup(int(sys.argv[2]));
    for i in map(int,sys.argv[3:]):print(json.dumps(solve(i)),flush=True)
