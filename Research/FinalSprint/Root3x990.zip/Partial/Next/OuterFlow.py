"""Safe hull volume constraints shared by finite flow rows. Certified large residuals use their per-prime even upper-demand hull; unknown blocks conservative. Source overlap omitted only for internal r|A, all retained blocks coprime to A. Actual outside V is net; abundance remains upper via original uniform estimator. Reuses exact cut verifier."""
from pathlib import Path
import sys,inspect
here=Path(__file__).resolve().parent;sys.path.insert(0,str(here));import NextFlow as nf
from NextFlow import *

def model(i):
    # Need actual full residuals, not only >50000 left; build and check deterministic finite source list from options.
    data,rows,rhs,names,opts,lefts=nf.model(i);absent=BAN|set((cert['cell10']+cert['cell11'])[i]['absent_extra']);A=j.A;pool=set(opts);hints,ec=sc.extra();facts={};cap={};coeff={};tbl={};out={};pvol=names.index('vol');Tpen=2*hi(3)
    @cache
    def parts(n):
        ks,left=small_parts(n);ks=list(ks)
        for t in hints:
            if t in pool:continue
            if left%t==0:h=val(left,t);left//=t**h;ks.append((t,h))
        if left>1 and (prime(left) or left in ec):ks.append((left,1));left=1
        return ks,left
    for r,ls in opts.items():
        bounds={}
        for f,k in ls:
            if f is None:continue
            S=sig(r,f);n=S//3**val(S,3)
            for t in pool:
                while n%t==0:n//=t
            if gcd(n,A)!=1 or n>=j.Q:continue
            kf,left=parts(n);out[k]=kf,left
            for t,h in kf:bounds[t]=max(bounds.get(t,0),h)
        for t,h in bounds.items():cap[t]=cap.get(t,0)+h
    # Globally isolate all whole primes recognized at the end of trial division, not merely the original hints.
    new=set(cap)-hints-set(j.small);cap={}
    for r,ls in opts.items():
        o={}
        for _,jcol in ls:
            if jcol not in out:continue
            ks,left=out[jcol];ks=list(ks)
            for t in new:
                if left%t==0:h=val(left,t);left//=t**h;ks.append((t,h))
            out[jcol]=ks,left
            for t,h in ks:o[t]=max(o.get(t,0),h)
        for t,h in o.items():cap[t]=cap.get(t,0)+h
    from math import prod
    modulus=prod(cap);assert all(gcd(left,modulus)==1 for ks,left in out.values())
    for t,H in cap.items():
        fe=max(20,2*H+4)+2;c=(fe*lo(t)-(4*hi(fe+1) if t%3==1 else 0))//H
        for h in range(2,fe,2):
            if any(sig(t,h)%z==0 for z in absent):continue
            c=min(c,(h*lo(t)-(4*hi(3)*val(h+1,3) if t%3==1 else 0))//min(H,h))
        coeff[t]=c
    for k,(ks,left) in out.items():rows[pvol][k]=sum(coeff[t]*h for t,h in ks if j.nosource(t)); # deliberately drop all unresolved factors; safe without branching on the unique external source
    return data,rows,rhs,names,opts,lefts
if __name__=='__main__':
    import IntegerCut as cut
    assert __debug__;setup(int(sys.argv[2]));cut.model=model
    for i in map(int,sys.argv[5:]):
        x=cut.branch(i,int(sys.argv[3]),int(sys.argv[4]),'outercut');print(json.dumps(x),flush=True)
