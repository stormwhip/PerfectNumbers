"""Global linear square hull for fixed finite forest rows, with a safe per-prime capacity LP.
For each odd prime t in an atom, valuation demands from realized rows add. If for ANY two selectable distinct source primes their *total possible* t-supply is at most 1, we may pay its even hull without double charging. More generally use weights based on max total demand across distinct source primes. Unknown composite atoms conservatively grouped; arithmetic means no factoring needed for multiplicity proof when exponent is squarefree inside atom. See report.
"""
import sys,json
from pathlib import Path
from functools import cache
from fractions import Fraction
here=Path(__file__).resolve().parent;sys.path.insert(0,str(here.parent));import Joint as j
from Joint import lo,hi,prime,prime64,sig,val,small_parts,gcd,T,B,BAN,cert,basis

def setup(e):
    j.e=e;j.pe=3**e;j.A=(3*j.pe-1)//2
    K=10000**2;d=Fraction(1)
    for r in j.small:
        if r>=10000:break
        if r%3==1 and r not in BAN and all(sig(r,2)%t for t in BAN):d*=Fraction(K,r*r)
    s=next(s for s in range(1,e+1) if 2*j.pe*(2*3**s-1)**2*K**(e-s)*d.denominator<=3*B*d.numerator);j.Y=3**s;j.Q=2*j.Y-1;j.nosource.cache_clear();return s

def calc(idx):
    l=(cert['cell10']+cert['cell11'])[idx];F=l['forest'] or {};roots=l['present'];absent=BAN|set(l['absent_extra']);pool=set(map(int,F.get('cut_even',{})));child={int(k):v for k,v in F.get('edges',{}).items()};assert set(roots)==set(F.get('roots',[]));assert all(prime(t) and j.A%t and t<j.Q and j.nosource(t) for t in pool)
    assert len(pool)==len(roots)+sum(len(t) for t in child.values()) and len(pool)==len(set(roots)|{t for v in child.values() for t in v});rows={};unknown=[]; known=set();dicts={};hist={};P=2*hi(3)
    for r in pool:
        # Extend *every* too-short tail to 350 decimal digits of raw component volume, preserving all old edges.
        cut=F['cut_even'][str(r)];want=350*hi(10)
        while cut*lo(r)-(4*hi(cut+1) if r%3==1 else 0)<want:cut+=2
        F['cut_even'][str(r)]=cut;rows[r]=[]
        for f in range(2,cut,2):
            S=sig(r,f)
            if any(S%a==0 for a in absent):continue
            b=val(S,3);n=S//3**b
            for t in pool:
                while n%t==0:n//=t
            if gcd(n,j.A)!=1 or n>=j.Q:n=1
            parts,left=small_parts(n);known.update(t for t,h in parts)
            if left>1:unknown.append(left)
            rows[r].append((f,S,f*lo(r)-4*hi(3)*b,n))
    divs,ec=j.extra_info();bs=basis(list(set(unknown))+divs);known|={t for t in bs if prime(t) or t in ec};known-=pool
    # Build maximal incoming valuations independently per source prime and target.
    for n in {n for opts in rows.values() for f,s,c,n in opts}:
        x=n;pieces={}
        for t in sorted(known):
            if x%t==0:v=val(x,t);x//=t**v;pieces[t]=v
        for a in bs:
            z=1
            while (h:=gcd(a,x))>1:x//=h;z*=h
            if z>1:pieces[a]=z # unknown component supported on this atom
        assert x==1;dicts[n]=pieces
    for r,opts in rows.items():
        direct={}
        for _,_,_,n in opts:
            for t,h in dicts[n].items():
                if t in known:direct[t]=max(direct.get(t,0),h)
        for t,h in direct.items():hist[t]=hist.get(t,0)+h
    # alpha coefficient per known t from all h>=1 up to a valid incoming ceiling. Stronger than only square uplift for singleton supply.
    coeff={}
    for t,H in hist.items():
        # Full even exponent h may be arbitrarily larger than all requests. Check finite h and tail; capped H makes tail safe.
        best=lo(t)*10
        for h in range(2,max(20,2*H+4)+1,2):
            k=val(h+1,3) if t%3==1 else 0
            best=min(best,(h*lo(t)-4*hi(3)*k)//min(H,h))
        fe=max(20,2*H+4)+2;assert (fe*lo(t)-(4*hi(fe+1) if t%3==1 else 0))//H>=best
        coeff[t]=max(0,best)
    opts={};unsafe=set()
    for r,rr in rows.items():
        opts[r]=[]
        for f,S,c,n in rr:
            w={}
            for t,h in dicts[n].items():
                if t in known:z=coeff[t]*h
                else:z=lo(h)*(lo(50000)-P)//lo(50000)
                w[t]=z
                if t not in known or not j.nosource(t):unsafe.add(t)
            opts[r].append((f,S,c,sum(w.values()),w))
    def dpbad(bad):
        @cache
        def dp(r,m):
            fe=max(F['cut_even'][str(r)],m+m%2);best=fe*lo(r)-(4*hi(fe+1) if r%3==1 else 0)
            for f,S,c,z,w in opts[r]:
                if f<m:continue
                v=c+z-w.get(bad,0)
                for t in child.get(r,[]):
                    if S%t==0:v+=dp(t,val(S,t))
                best=min(v,best)
            return best
        return sum(dp(r,2) for r in roots)
    inte=dpbad(None);ext=inte;worst=None
    for t in unsafe:
        v=dpbad(t)
        if v<ext:ext=v;worst=t
    return dict(i=idx,internal=inte,external=ext,internal_digits=inte//hi(10),external_digits=ext//hi(10),unsafe=len(unsafe),total_known=len(hist),singletons=sum(z==1 for z in hist.values()),worst=worst)
if __name__=='__main__':
    assert __debug__;print('smin',setup(int(sys.argv[2])),flush=True)
    for i in (list(map(int,sys.argv[3:])) or list(range(42))):print(json.dumps(calc(i)),flush=True)
