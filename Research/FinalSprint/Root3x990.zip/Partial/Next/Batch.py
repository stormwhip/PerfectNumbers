"""Certified batch-GCD overlap incidence. Bernstein product/remainder tree; use FLINT GMP kernels when available for discovery, Python int otherwise. Given n_i possibly non-coprime and repeated prime powers, g_i=gcd(n_i,(P mod n_i²)//n_i), P=prod n. It records exactly the prime support shared with at least one other entry. Pairwise intersections can then be looked up by gcd of the much-smaller shared parts."""
import math

def adjacency(ns):
    try:
        from flint import fmpz
        def G(a,b):return a.gcd(b)
    except ImportError:fmpz=int;G=math.gcd
    n=len(ns);assert n and len(set(ns))==n;tree=[[fmpz(p) for p in ns]]
    while len(tree[-1])>1:
        old=tree[-1];tree.append([old[i]*old[i+1] if i+1<len(old) else old[i] for i in range(0,len(old),2)])
    rem=tree[-1]
    for layer in tree[-2::-1]:
        rem=[rem[i//2]%(x*x) for i,x in enumerate(layer)]
    shared=[]
    for i,(x,y) in enumerate(zip(tree[0],rem)):
        assert y%x==0;g=int(G(x,y//x));assert ns[i]%g==0
        if g>1:shared.append((i,g))
    out=[{i} for i in range(n)]
    for j,(a,g) in enumerate(shared):
        for b,h in shared[:j]:
            if math.gcd(g,h)>1:out[a].add(b);out[b].add(a)
    return out
