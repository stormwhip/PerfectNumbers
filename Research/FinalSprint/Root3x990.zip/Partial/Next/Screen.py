"""One-pass localized branch study. Internal-source forest bound; deterministic joint even-hull net cost distinguished per option through an upper bound on incoming demand from OTHER source rows. No factoring except trial and EC input. Stdlib. Arg1 fixed checkout, arg2 e, subsequent leaf ids."""
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent));import Hull as h
from Hull import *

@cache
def extra():
    divs,old=j.extra_info();ec=set(old);from EC import ecprime
    for name in ('FrontCerts.jsonl','MoreCerts.jsonl','KeyCerts.jsonl'):
        path=here/name
        if path.is_file():
            for line in path.read_text().splitlines():
                if line.startswith('[['):c=json.loads(line);t=c[0][0];assert ecprime(t,c,prime64);ec.add(t)
    ds=set(divs+json.loads((here/'Factors.json').read_bytes()))
    for name in ('More.json','KeyFactors.json'):
        p=here/name
        if p.is_file():ds.update(t for v in json.loads(p.read_bytes()).values() for t in v)
    return {t for t in ds if prime(t) or t in ec},ec

def solve(idx,wide=350):
    L=(cert['cell10']+cert['cell11'])[idx];F=L['forest'] or {};pool=set(map(int,F.get('cut_even',{})));absent=BAN|set(L['absent_extra']);roots=L['present'];child={int(k):v for k,v in F.get('edges',{}).items()};assert set(roots)==set(F.get('roots',[]));assert all(prime(t) and j.A%t and t<j.Q and j.nosource(t) for t in pool)
    seen=set();st=roots[:]
    while st:
        a=st.pop();assert a not in seen;seen.add(a);st.extend(child.get(a,[]))
    assert seen==pool
    auxset,ec=extra();known=auxset|set(j.small);known-=pool;opts={};cutoff={};weights={};counts={};unity={};uweight_cache={};tailw=lo(50000)-2*hi(3);taild=lo(50000);choices={}
    @cache
    def parts(n):
        knowns=[]
        a,left=small_parts(n);knowns.extend(a)
        for t in auxset-pool:
            if left%t==0:v=val(left,t);left//=t**v;knowns.append((t,v))
        if left>1 and (prime(left) or left in ec):knowns.append((left,1));left=1
        return knowns,left
    for r in pool:
        cut=F['cut_even'][str(r)];w=wide*hi(10)
        while cut*lo(r)-(4*hi(cut+1) if r%3==1 else 0)<w:cut+=2
        cutoff[r]=cut;items=[];o={};opts[r]=items
        for f in range(2,cut,2):
            S=sig(r,f)
            if any(S%t==0 for t in absent):continue
            b=val(S,3);n=S//3**b
            for t in pool:
                while n%t==0:n//=t
            if n>=j.Q or gcd(n,j.A)!=1:n=1
            ks,left=parts(n);z=lo(left)*tailw//taild if left>1 else 0
            for t,v in ks:o[t]=max(o.get(t,0),v)
            items.append((f,S,f*lo(r)-4*hi(3)*b,z,ks,left));
        for t,v in o.items():counts[t]=counts.get(t,0)+v
    # Newly recognized whole primes must be stripped from EVERY unresolved residual before any square-hull uplift.
    # Otherwise another row might charge a fraction of the same prime as anonymous volume.
    extra_t=set(counts)-auxset-set(j.small);counts={}
    for r,ls in opts.items():
        out=[];o={}
        for f,S,c,_,knownpart,left in ls:
            ks=list(knownpart)
            for t in extra_t:
                if left%t==0:v=val(left,t);left//=t**v;ks.append((t,v))
            for t,h in ks:o[t]=max(o.get(t,0),h)
            out.append((f,S,c,lo(left)*tailw//taild if left>1 else 0,ks,left))
        opts[r]=out
        for t,h in o.items():counts[t]=counts.get(t,0)+h
    # Independent disjointness audit: no unit of the anonymous volume can use a hull-priced prime.
    from math import prod
    modulus=prod(counts);assert all(gcd(left,modulus)==1 for ls in opts.values() for _,_,_,_,_,left in ls)
    for t,H in counts.items():
        best=10000*lo(t);fe=max(40,2*H+4)+2
        for k in range(2,fe,2):
            if any(sig(t,k)%p==0 for p in absent):continue
            best=min(best,(k*lo(t)-(4*hi(3)*val(k+1,3) if t%3==1 else 0))//min(k,H))
        best=min(best,(fe*lo(t)-(4*hi(fe+1) if t%3==1 else 0))//H);weights[t]=best
    @cache
    def dp(r,m):
        fe=max(cutoff[r],m+m%2);best=fe*lo(r)-(4*hi(fe+1) if r%3==1 else 0);choice=(fe,0,[],[])
        for f,S,c,z,ks,left in opts[r]:
            if f<m:continue
            v=c+z+sum(k*weights[t] for t,k in ks);kids=[]
            for t in child.get(r,[]):
                if S%t==0:k=val(S,t);v+=dp(t,k);kids.append((t,k))
            if v<best:best=v;choice=(f,left,ks,kids)
        choices[r,m]=choice;return best
    net=sum(dp(r,2) for r in roots)
    path=[];stack=[(r,2) for r in roots]
    while stack:
        r,m=stack.pop();f,left,ks,ch=choices[r,m];path.append((r,f,left,ks));stack.extend(ch)
    return dict(i=idx,e=j.e,internal_digits=net//hi(10),net=net,emitter_path=path,known=len(weights),rows=sum(map(len,opts.values())))
if __name__=='__main__':
    assert __debug__;print('smin',setup(int(sys.argv[2])),flush=True)
    for i in (list(map(int,sys.argv[3:])) or list(range(42))):print(json.dumps(solve(i)),flush=True)
