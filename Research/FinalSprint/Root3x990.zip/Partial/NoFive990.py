"""Theorem (regional, not a full exponent): if N<=10^2400 is odd perfect, 3^990||N, and canonical root-three bans hold, then 5|N. Run Base/Trial990.cpp beforehand to verify external-A range; this script reruns every remaining necessary branch in check=True children. Does not modify reference repo."""
import sys,subprocess,importlib.util
from pathlib import Path
p=Path(__file__).resolve().parent;q=p/'Next/Lower';repo=Path(sys.argv[1]).resolve()
def call(fn,*args):subprocess.run([sys.executable,'-I','-S','-B',str(fn),str(repo),*map(str,args)],check=True)
if __name__=='__main__':
    assert __debug__;call(p/'Prelude990.py');sys.path.insert(0,str(p));spec=importlib.util.spec_from_file_location('external990',p/'Base/External.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.run(990,1893);import Base;Base.check_range(990,10**11);z,_=Base.envelope(990,10**11);assert z[1]==4262210214887
    call(q/'StrictDirect.py',990,'int',549, *range(1,12));call(q/'GenVerify.py',990,'int',549,0);call(q/'StrictInterval.py',990,2,507,*range(2,12));call(q/'StrictInterval.py',990,3,507,0,1)
    print('PASS: canonical 3^990 || N<=10^2400 odd perfect implies 5 divides N. No full exponent conclusion.')
