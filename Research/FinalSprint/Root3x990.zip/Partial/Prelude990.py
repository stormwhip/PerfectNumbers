"""Python-only frozen E0/E1/E2 and primitive-source replay for 1108; never writes frozen checkout. Arg: fixed repo root."""
from pathlib import Path
import sys,json,importlib.util
here=Path(__file__).resolve().parent;sys.path.insert(0,str(here));from Joint import ROOT,cert,small,BAN
import PrimitiveAudit

def cover():
    a=cert['cell10'];b=cert['cell11'];split=[17,23,29,37,41];allp=[r for r in small if 17<=r<=157 and r not in BAN]
    assert len(a)==12 and len(b)==30
    for mask in range(32):
        pos={r for j,r in enumerate(split) if mask>>j&1};neg={5}|(set(split)-pos);assert any(set(l['present'])<=pos and set(l['absent_extra'])<=neg for l in a)
    assert any(set(l['present'])=={5} and set(l['absent_extra'])==set(allp) for l in b)
    for i,r in enumerate(allp):assert any(set(l['present'])=={5,r} and set(l['absent_extra'])==set(allp[:i]) for l in b)

def main():
    assert __debug__;PrimitiveAudit.main();cover();script=ROOT/'Research/P3I00193Review/VerifyPartial.py';sp=importlib.util.spec_from_file_location('frozenpartial',script);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
    class Sink:
        def __truediv__(self,s):assert s=='PartialResults.json';return self
        def write_text(self,s,encoding):self.val=json.loads(s)
    sink=Sink();m.HERE=sink;m.EXPONENTS=(990,);m.run();assert sink.val['rows'][0]['e']==990;print('990 initial branches, b=0 and support cover: PASS')
if __name__=='__main__':main()
