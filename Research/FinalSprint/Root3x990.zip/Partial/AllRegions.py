"""Complete freeze of verified SUBDOMAINS as of this package. Does not claim e=990,970 or 856 globally. No search or SciPy. Fixed snapshot passed as arg1; requires named whole-Euler base bounds in README. Each subprocess uses a fresh model context."""
import sys,subprocess
from pathlib import Path
p=Path(__file__).resolve().parent;q=p/'Next/Lower';root=Path(sys.argv[1]).resolve()
def run(script,*rest):subprocess.run([sys.executable,'-I','-S','-B',str(script),str(root),*map(str,rest)],check=True)
if __name__=='__main__':
 assert __debug__;run(p/'VerifyPartial.py');run(q/'GenVerify.py',990,'int',549,0,12,31,32,34,40,41);run(q/'Gen4Verify.py',990,'int',549,27,29,30);run(q/'StrictInterval.py',990,3,507,0,1);run(q/'StrictInterval.py',990,2,507,2,5,6,7,8,33,35,36,37,38,39);print('PASS additional partial support certificates; NO additional actual exponents')
