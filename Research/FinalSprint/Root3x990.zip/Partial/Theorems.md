# Accepted implications and the remaining front

Under the canonical fixed-root assumptions, `σ(N)=2N`, N odd, N≤10^2400, 3^e||N, gcd(N,7·11·13·19·31)=1:

**No-five theorem, e=990.** Necessarily **5 divides N**. This is NOT the assertion that exponent 990 is excluded. The no-5 truth assignments are exactly the twelve numbered leaves 0…11 in `cell10` of the pinned JSON; `Prelude990.py` checks exhaustive coverage of all Boolean assignments on 17,23,29,37,41 and independently replays frozen E0/E1/E2 plus the primitive-source/b=0 theorem. In E3a use base >10^1893, with the full-range modulus checked separately. In E3b use the shared root/source lower base at least 4262210214887 nanonats. Each amount is charged once, without reuse of ordinary valuation supply.

For external leaf 0 the third generation LP names the same sources across all choices and creates 9800 possible composite source-overlap representatives. All except interval [97,98) are covered by verified integer source-cell duals. In particular this is not an argument from a near-complete list. The verifier computes the candidate at index 97 with the actual current support ordering: 5284152176857789149025639141509422879157026349918193094415193838259547412834660401. Its *complete* prime factorization is 5266228211 × 4217468380980037880092527701441161 × 237916085520023302947010376750220097331. Multiplication, the 64-bit or recursive elliptic prime certificates, and each of the three `nosource(t)` arithmetic proofs are verified, so this initial missing hypothesized source class is impossible. The no-overlap case (source divides no representative) entails no lower cost than any nonempty checked case, since removing a nonnegative residual charge only weakens a constraint and leaves all other costs unchanged.

## Reproduction

```
g++ -O3 -std=c++17 Base/Trial990.cpp -o /tmp/range990 && /tmp/range990
python -I -S -B NoFive990.py <fixed-repo>
```

Expected R=9092464640001, survivors=208105567, no divisor. No SciPy, PARI, third-party arithmetic, external RAM file, or network is required. The bounded-choice dual checks group minima by actual prime, never claiming a solver's infeasibility diagnosis as proof. `AllRegions.py` additionally validates the batch E3 subdomains for 990,970,856 as listed. To independently verify all *premises* of the extended unclosed cases, use `Base.py <fixed-repo>` for integer E3b envelopes and `Base/Trial970.cpp` plus `Base/External.py` (run its `run(970,1855)` after verifying the range); analogous 856 base is from `Base.py`. The external 990 necessary condition is stronger than a mere partial s-window and does not assign any ledger credit. The E3a/E3b union outside the no-5 class still has unresolved support leaves: in particular no all-s unconditional elimination is made when 5,17|N.
