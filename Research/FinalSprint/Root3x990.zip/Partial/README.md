# Additional 990 / 970 / 856 subdomains — NOT full actuals

**The no-five theorem at e=990 is now complete as an implication, not an exclusion of e=990.** See `Theorems.md`, `NoFive990.py`, `AllRegions.py` and `Result.json` for precise statements and the current complete lists.

The purpose of this bundle is to give **batch regional exclusions** using the common cross-source flow strengthening; no whole actual or ledger shard is claimed. Supply bounds for 990 and 970 are supplied as premises via the independent `Base.py` and parity `NextRange.py` + `Next.py`, not estimated logs. See `RowDual.md`, `BatchNotes.md` for the proof. Other root rows are not extrapolated. `856` requires inside-only source checking: since r|A in E3b, A%t!=0 suffices to exclude t=r. This does NOT assert that t is never an external source in E3a. The 128-bit+ prime certificates remain deterministic ECPP/Pocklington, not source probability heuristics.

From this dir, set REPO to unpacked fixed 2889e47f baseline; standard Python library only. Example:

```
python -I -S -B ./Next/Lower/CheckBatch.py $REPO 990 int 549 1 2 3 4 5 6 7 8 9 10 11 33 35 36 37 38 39
python -I -S -B ./Next/Lower/CoherentRobust.py $REPO 990 507 3 4 9 10 11
python -I -S -B ./Next/Lower/CheckBatch.py $REPO 970 int 549 2 3 4 5 6 7 8 9 10 11
python -I -S -B ./Next/Lower/CheckBatch.py $REPO 970 ext 507 10 11
python -I -S -B ./Next/Lower/InsideOnly.py $REPO 856 11
```

Every successful (s,i, support) row satisfies N>B by coupling only the independent base part with **one** whole auxiliary net bound. Prices in nanonats must be divided by 10^9; divide by the upper enclosure of ln(10) for a conservative decimal display. Constants E3a bases 990/970: 1893/1855 digits; E3b base integers 990/970/856: 4262210214887/4174321231820/3686537375611 nanonats. These are actual-specific mathematical premises. Integer dual trees use a fixed 549-digit target to search or check the auxiliary part, not automatically 549 digits of gross N. Sum exact value with target actual's corresponding base before accepting. Returning `null`, an uncovered source interval, or positive open_nodes does not certify an exclusion. Diagnostics and candidate timings are not final ledger changes.
