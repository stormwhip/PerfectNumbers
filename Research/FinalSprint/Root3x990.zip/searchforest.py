"""Discovery, not proof. Historical factor index and local GMP/FLINT are optional; final forest checker imports none of them."""
from forest5 import *
import argparse,hashlib,subprocess
sys.path[:0]=[str(D.parent/'lab'),str(D.parent/'local-math')]
import Forest as bank
bank.setup()
from flint import fmpz
from shutil import copyfile
from functools import cache
@cache
def cert(t):
 if prime(t):return True
 if t<2**64 or not fmpz(t).is_probable_prime():return False
 st=str(t);key=hashlib.sha256(st.encode()).hexdigest();path=D/'ec'/key
 for pd in ['lab/certs','low19-lab/certs']:
  for ext in ('.json','.json.gz'):
   f=D.parent/pd/(key[:24]+ext)
   if f.is_file():
    try:
     blob=f.read_bytes();x=json.loads(__import__('gzip').decompress(blob) if ext.endswith('gz') else blob)
     if ecprime(t,x,prime64):path.write_text(json.dumps(x,separators=(',',':')));prime.cache_clear();return True
    except Exception:pass
 try:
  if len(st)>450:return False
  res=subprocess.run([str(D.parent/'lab/GpWin.exe'),'-fq'],input=f'default(parisizemax,500000000);default(nbthreads,1);\nprint(primecert({t}));\n',capture_output=True,text=True,errors='replace',timeout=35)
  x=next(json.loads(s) for s in res.stdout.splitlines() if s.startswith('[['));assert ecprime(t,x,prime64);path.write_text(json.dumps(x,separators=(',',':')));prime.cache_clear();return True
 except Exception:return False

def run(d,m,depth=30):
 dest=D/'forests'/f'{d}-{m}.json';dest.parent.mkdir(exist_ok=True);roots=initial(d,m);best=0;owners={};baseval=base(d,m)
 if dest.exists():
  old=json.loads(dest.read_bytes());owners=dict(old['owners']);best=old['lb']
  if best>2400*hi(10):return
 visited=set();front=set();
 for n in range(depth):
  z,tr=evalforest(d,m,owners,roots,True);total=z+baseval
  if total>best:
   best=total;dest.write_text(json.dumps(dict(d=d,m=m,roots=roots,owners=sorted(owners.items()),lb=best),separators=(',',':')))
  if total>2400*hi(10):break
  new={}
  for p,h in tr:
   if (p,h) in visited:continue
   visited.add((p,h))
   for t in bank.factors(p,h):
    if t in roots or t in owners or t in (3,5) or t in BAN or A%t==0 or t>=2*3**813-1 or not m and not ak(t) or not cert(t):continue
    new.setdefault(t,p)
  if not new:break
  owners.update(new)
 print('branch',d,m,'floor',best//hi(10),'nodes',len(owners),'depth',n,flush=True)
if __name__=='__main__':
 m=int(sys.argv[1]);ds=list(map(int,sys.argv[2:])) or [r['d'] for r in json.loads((D/'first.json').read_bytes()) if r['EI'[m]]['floor']<2400]
 for d in ds:run(d,m)
