"""All-integer independent E3a/E3b threshold check for every d_actual>=d. Uses monotonicity and the h=i+2j reduction; no Decimal. Recompute each parameter from the fixed snapshot, no trust in optional cached results."""
from pathlib import Path
import sys,math,json
p=Path(__file__).resolve().parent;sys.path.insert(0,str(p.parent/'Partial'/'Next'));from Screen import *

def check(e,d):
 s0=setup(e);R=1+2*(e+1)*32768*140000;P=3**(e+1);pe=P//3;A=(P-1)//2;assert A%5 and math.isqrt(A)**2!=A and j.nosource(5);assert all(t in BAN or t%5!=1 for t in j.small if t<41) and 41**(5**5-1)>B
 assert R>41 and 41**4>81**2;Z=5**d;pu=[5**i for i in range(d+1)];p81=[81**i for i in range(e-s0+1)];p41=[41**(4*i) for i in range(d+1)];rpow=[R**(2*h) for h in range(152)];assert rpow[150]>B
 rejected=[True,True];example=[None,None];n=0
 for s in range(s0,e+1):
    y=3**s;D=P//y;U=e-s
    for u in range(d+1):
        q=2*y*pu[u]-1;b=min(4,d) if u==0 else 0;other=d-u-b;I=max(1,y*q//(max(q,P)*(3 if R>=2*D+1 else D+4)));E=2*q//3;mult=pe*q*Z
        for k in (0,1):
            if not rejected[k]:continue
            H=A*R if not k else A*max(R,I);F=1 if not k else max(E,I);cap=B//(mult*(E if not k else 1));
            if H>cap or F>cap:continue
            hi0=min(150,U+2*other);a=0;c=hi0+1
            while c-a>1:
                h=(c+a)//2
                if F*rpow[h]<=H:a=h
                else:c=h
            # For every h=i+2j and either parity, largest j is optimal. On intervals cut by 2*other and the last point F*R^(2h)<=H, the complete integer bound is geometric in h at step 2, hence endpoint suffices.
            hs={max(0,min(hi0,x+v)) for x in (0,2*other,hi0,a) for v in (-3,-2,-1,0,1,2,3)}
            for h in hs:
                j0=min(h//2,other);i=h-2*j0
                if i>U:continue
                n+=1
                if max(H,F*rpow[h])*p81[U-i]*p41[other-j0]<=cap:rejected[k]=False;example[k]=(s,u,b,i,j0);break
 return dict(e=e,d0=d,excluded=rejected,example=example,integer_checks=n)
if __name__=='__main__':
 assert __debug__
 for d in map(int,sys.argv[3:]):print(json.dumps(check(int(sys.argv[2]),d)),flush=True)
