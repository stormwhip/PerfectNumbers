"""Filter exact ordinary 5^d by the canonical bans; no Euler order premise used here. Prerequisite: positive even d≤244/370 from separate scripts."""
import json
BAN=(7,11,13,19,31)
if __name__=='__main__':
    assert __debug__;out={k:[d for d in range(2,m+1,2) if all(((5**(d+1)-1)//4)%t for t in BAN)] for k,m in [('E3a',244),('E3b',370)]};assert len(out['E3a'])==64 and len(out['E3b'])==98 and min(out['E3a'])==min(out['E3b'])==6;print(json.dumps(out,separators=(',',':')))
