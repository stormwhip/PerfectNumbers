"""Fast closed-form maximum outside/inside budget for d5. Parameters e,d threshold. Returns strict comparisons for all actual d5>=d by monotone allocation. Statement and proof in companion FiveBalance/Area5. Single 3-supply unit cost 4ln3; single outside 5-supply cost 4ln41. Integer directed logs, Lipschitz breakpoints for i and j. Re-evaluate using full loops for correctness. Closed optimization: let h=i+2j; for given h, minimize the sum -i*4ln3-j*4ln41 by maximizing j since 4ln41>8ln3. Thus j=min(n,floor(h/2)), i=h-2j; any larger i at same h increases the cost. Feasible h∈[0,U+2n]. Fix parity h mod2. Cost convex piecewise linear with slope breakpoints at h=2n and H=F(h). Min lies within one parity step of these finite breakpoints or endpoints. Evaluate inclusive neighbors ±3. This yields identical minima to enumerating all i,j, using only arithmetic of intervals. Useful to certify v5(N) upper self-consistency shell by shell for 990,970."""
import sys,math,json
from pathlib import Path
p=Path(__file__).resolve().parent;sys.path.insert(0,str(p));sys.path.insert(0,str(p.parent/'Partial'/'Next'));from Screen import *

def bounds(e,d):
 ss=setup(e);R=1+2*(e+1)*32768*140000;P=3**(e+1);pe=P//3;A=(P-1)//2;assert A%5 and math.isqrt(A)**2!=A and j.nosource(5) and 41**(5**5-1)>B;assert all(t in BAN or t%5!=1 for t in j.small if t<41)
 logR=lo(R);alpha=4*lo(3);beta=4*lo(41);assert beta>2*alpha;Alog=lo(A*R);rh=hi(R);pd=d*lo(5);top=[10**30,10**30];arg=[None,None];powers=[5**u for u in range(d+1)]
 for s in range(ss,e+1):
    y=3**s;delta=P//y;D=3 if R>=2*delta+1 else delta+4;U=e-s
    for u in range(d+1):
        q=2*y*powers[u]-1;b0=4 if u==0 else 0;b0=min(d-u,b0);n=d-u-b0;I=max(0,lo(y*q)-hi(max(P,q)*D));E=lo(2*q)-hi(3);raw=lo(pe*q)+pd;Hmax=U+2*n
        for k in (0,1):
            H=Alog+(max(0,I-rh) if k else 0);F=max(E,I) if k else 0;switch=(H-F)//(2*logR);hs={max(0,min(Hmax,x+dy)) for x in [0,2*n,Hmax,switch] for dy in (-3,-2,-1,0,1,2,3)}
            for h in hs:
                j0=min(n,h//2);i=h-2*j0
                if i>U:continue
                z=raw+max(H,F+2*h*logR)+(E if not k else 0)+(U-i)*alpha+(n-j0)*beta
                if z<top[k]:top[k]=z;arg[k]=(s,u,i,j0,b0)
 return dict(e=e,min_d=d,low_nanonats=top,minimum_floor=[z//hi(10) for z in top],case=arg,reject=[z>2400*hi(10) for z in top])
if __name__=='__main__':
    assert __debug__
    for d in map(int,sys.argv[3:]):print(json.dumps(bounds(int(sys.argv[2]),d)),flush=True)
