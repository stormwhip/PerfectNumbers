"""Proof of uniform upper bound for the true 5-exponent d in all surviving e=990 counterexamples. Exact integer monotonic relaxation: for d_actual>=d0 treat exactly d0 units by distributing free Euler/inside/source/outside units, decreasing if necessary; if actual u>0 keep u'=min(u,d0), b'=0. All source/inside/ordinary lower bounds are monotone in component valuations, and the actual 5^d is at least 5^d0. Exact checks for any requested d0 (few seconds)."""
import sys,json,math
from pathlib import Path
p=Path(__file__).resolve().parent;sys.path.insert(0,str(p.parent/'Partial'/'Next'));from Screen import *

def test(e,d):
 ss=setup(e);R=1+2*(e+1)*32768*140000;P=3**(e+1);pe=P//3;A=(P-1)//2;assert A%5 and math.isqrt(A)**2!=A and j.nosource(5) and 41**(5**5-1)>B
 assert all(t%5!=1 or t in BAN for t in j.small if t<41)
 # For fixed i and E or I, 5-supply inside j is bounded by AR crossover; one can compare min over *all* j with exact integer closed form.
 powR=[R**k for k in range(2*e+4*d+1)];pu=[5**i for i in range(d+1)];card=0;low=[B+1,B+1];loc=[None,None];Z=5**d
 # z capped only in output; use exact integer quantities to rule out all. For checking feasibility at B, largest possible j allowed by H or F is always <= floor log_R(B)~186; ignore j beyond if even F*R^(4j)>B.
 cheap=[41**(4*n) for n in range(d+1)];tar=[81**k for k in range(e-ss+1)]
 for s in range(ss,e+1):
    y=3**s;D=P//y;U=e-s
    for u in range(d+1):
        q=2*y*pu[u]-1;b=min(d,4) if u==0 else 0;n=d-u-b;I=max(1,y*q//(max(P,q)*(3 if R>=2*D+1 else D+4)));E=2*q//3
        for i in range(min(U,100)+1):
            k=U-i;fac=pe*q*Z*tar[k];
            # For every branch find last j where the observed pre-purchase is more expensive than the internal suppliers. min is at this index or the next one, as F*R^(4j)*cheap[n-j] increases with j.
            for a in (0,1):
                cap=(B//fac) if a else B//(fac*E);H=A*R if not a else max(A*R,A*I);F=powR[2*i]*(max(E,I) if a else 1)
                if max(H,F)>cap:continue
                lo0=0;hi0=min(n,100)+1
                while lo0+1<hi0:
                    mid=(lo0+hi0)//2
                    if F*powR[4*mid]<=H:lo0=mid
                    else:hi0=mid
                assert powR[200]>B # no possible i>100 or j>100
                for j0 in {lo0,min(n,hi0)}:
                    z=fac*max(H,F*powR[4*j0])*cheap[n-j0]*(E if not a else 1);card+=1
                    if z<low[a]:low[a]=z;loc[a]=(s,i,u,b,j0)
 return dict(e=e,threshold=d,excluded_above=[k>B for k in low],witness_loc=loc,minimum_or_saturated=[len(str(k))-1 for k in low],comparisons=card)
if __name__=='__main__':
 assert __debug__;print(json.dumps(test(int(sys.argv[2]),int(sys.argv[3]))),flush=True)
