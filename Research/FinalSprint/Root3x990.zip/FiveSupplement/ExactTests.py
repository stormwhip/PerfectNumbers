"""Fast fail-closed theorem wrapper for both exclusions (not oscillator tests)."""
from pathlib import Path
import sys,json
sys.path.insert(0,str(Path(__file__).resolve().parent));from ExactCap import check
if __name__=='__main__':
 assert __debug__;a=check(990,246);b=check(990,372);assert a['excluded'][0] and b['excluded'][1];print(json.dumps(dict(e=990,euler_external_max_even_d5=244,euler_internal_max_even_d5=370,with_NoFive990_theorem='d5 is positive even and at most 370',inputs=[a,b],accepted_actuals=[])))
